import java.text.SimpleDateFormat
import java.util.Date

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.afra.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.afra.assistant.v2"
        minSdk = 26
        targetSdk = 35
        // Every build gets a higher number automatically, so each one installs as an update of the last.
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "2.0." + SimpleDateFormat("yyMMdd.HHmm").format(Date())

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // One fixed signing key, so every future build installs OVER the previous one (no uninstall needed).
    signingConfigs {
        create("afra") {
            storeFile = file("afra-debug.keystore")
            storePassword = "afra123456"
            keyAlias = "afra"
            keyPassword = "afra123456"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("afra")
        }
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.11.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
