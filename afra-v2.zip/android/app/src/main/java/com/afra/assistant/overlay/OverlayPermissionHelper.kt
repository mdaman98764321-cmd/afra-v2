package com.afra.assistant.overlay

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

/**
 * Helper class for managing Android System Overlay (SYSTEM_ALERT_WINDOW),
 * Foreground Service notifications (POST_NOTIFICATIONS), and Audio Record permissions.
 */
object OverlayPermissionHelper {

    /**
     * Checks if the app has permission to draw on top of other apps.
     */
    fun canDrawOverlays(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    /**
     * Launches the system settings screen for the user to grant SYSTEM_ALERT_WINDOW.
     */
    fun requestOverlayPermission(activity: Activity, requestCode: Int = 5001) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + activity.packageName)
            )
            activity.startActivityForResult(intent, requestCode)
        }
    }

    /**
     * Checks if notification permission is granted on Android 13+ (API 33+).
     */
    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    /**
     * Checks if microphone permission is granted.
     */
    fun hasRecordAudioPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Starts the overlay service if permission is present.
     */
    fun startOverlayService(context: Context) {
        if (canDrawOverlays(context)) {
            val intent = Intent(context, AfraOverlayService::class.java).apply {
                action = AfraOverlayService.ACTION_START_OVERLAY
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    /**
     * Stops the overlay service.
     */
    fun stopOverlayService(context: Context) {
        val intent = Intent(context, AfraOverlayService::class.java).apply {
            action = AfraOverlayService.ACTION_STOP_OVERLAY
        }
        context.stopService(intent)
    }
}
