package com.afra.assistant.notify

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

data class AfraNotificationItem(
    val key: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long
)

/**
 * Keeps the most recent notifications in memory so AFRA can read them out when asked.
 * Needs the one-time "Notification access" permission from the user.
 */
class AfraNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            activeNotifications?.forEach { add(it) }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) add(sbn)
    }

    private fun add(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }

        synchronized(lock) {
            recent.removeAll { it.key == sbn.key }
            recent.add(0, AfraNotificationItem(sbn.key, label, title, text, sbn.postTime))
            while (recent.size > 30) recent.removeAt(recent.size - 1)
        }
    }

    companion object {
        private val lock = Any()
        private val recent = ArrayList<AfraNotificationItem>()

        fun snapshotJson(limit: Int): String {
            val arr = JSONArray()
            synchronized(lock) {
                recent.take(limit).forEach {
                    arr.put(
                        JSONObject()
                            .put("app", it.app)
                            .put("title", it.title)
                            .put("text", it.text)
                            .put("time", it.time)
                    )
                }
            }
            return arr.toString()
        }
    }
}
