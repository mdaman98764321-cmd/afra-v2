package com.afra.assistant.voice

import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Last-resort voice: Google Translate's read-aloud. One female voice, works without any key.
 */
object SimpleTts {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
    private val main = Handler(Looper.getMainLooper())
    private const val UA =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    private fun split(text: String, max: Int): List<String> {
        val out = ArrayList<String>()
        var cur = StringBuilder()
        for (word in text.trim().split(Regex("\\s+"))) {
            if (cur.isNotEmpty() && cur.length + 1 + word.length > max) {
                out.add(cur.toString())
                cur = StringBuilder()
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(word)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    fun synthesize(text: String, lang: String, done: (ByteArray?, String?) -> Unit) {
        Thread {
            try {
                val out = ByteArrayOutputStream()
                for (part in split(text, 170).take(4)) {
                    val url = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=" + lang +
                            "&q=" + URLEncoder.encode(part, "UTF-8")
                    val req = Request.Builder().url(url)
                        .header("User-Agent", UA)
                        .header("Referer", "https://translate.google.com/")
                        .build()
                    client.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) throw IOException("HTTP " + resp.code)
                        val bytes = resp.body?.bytes() ?: throw IOException("empty answer")
                        out.write(bytes)
                    }
                }
                val result = out.toByteArray()
                main.post { done(if (result.isNotEmpty()) result else null, if (result.isEmpty()) "no audio" else null) }
            } catch (e: Exception) {
                main.post { done(null, e.message ?: "failed") }
            }
        }.start()
    }
}
