package com.afra.assistant.voice

import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Free neural voices (no API key) used as a back-up when the Gemini voice allowance is used up.
 * This talks to an unofficial service, so it can stop working without notice.
 */
object EdgeTts {

    private const val TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
    private const val VERSION = "1-143.0.3650.75"
    private const val URL = "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1"
    private const val ORIGIN = "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold"
    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0"

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var skewSeconds = 0L

    private fun secMsGec(): String {
        val ticks = (System.currentTimeMillis() / 1000 + skewSeconds) + 11644473600L
        val floored = ticks - (ticks % 300L)
        val intervals = floored * 10000000L
        val digest = MessageDigest.getInstance("SHA-256")
            .digest((intervals.toString() + TOKEN).toByteArray(Charsets.US_ASCII))
        val sb = StringBuilder()
        for (b in digest) sb.append(String.format("%02X", b))
        return sb.toString()
    }

    private fun timestamp(): String {
        val f = SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(System.currentTimeMillis() + skewSeconds * 1000) + " GMT+0000 (Coordinated Universal Time)"
    }

    private fun xmlEscape(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace("\"", "&quot;").replace("'", "&apos;")

    /** Calls back on the main thread with the MP3 bytes, or an error text. */
    fun synthesize(text: String, voice: String, rate: String, done: (ByteArray?, String?) -> Unit) {
        attempt(text, voice, rate, true, done)
    }

    private fun attempt(
        text: String, voice: String, rate: String, allowRetry: Boolean,
        done: (ByteArray?, String?) -> Unit
    ) {
        val finished = AtomicBoolean(false)
        val audio = ByteArrayOutputStream()
        var socket: WebSocket? = null

        fun finish(bytes: ByteArray?, err: String?) {
            if (finished.compareAndSet(false, true)) {
                main.post { done(bytes, err) }
                try {
                    socket?.close(1000, null)
                } catch (e: Exception) {
                    /* ignore */
                }
            }
        }

        val url = URL + "?TrustedClientToken=" + TOKEN +
                "&Sec-MS-GEC=" + secMsGec() +
                "&Sec-MS-GEC-Version=" + VERSION +
                "&ConnectionId=" + UUID.randomUUID().toString().replace("-", "")

        val request = Request.Builder()
            .url(url)
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .header("Origin", ORIGIN)
            .header("User-Agent", UA)
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("Cookie", "muid=" + UUID.randomUUID().toString().replace("-", "").uppercase() + ";")
            .build()

        val timeout = Runnable { finish(null, "Free voice timed out.") }
        main.postDelayed(timeout, 25000)

        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val config = "X-Timestamp:" + timestamp() + "\r\n" +
                        "Content-Type:application/json; charset=utf-8\r\n" +
                        "Path:speech.config\r\n\r\n" +
                        "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":" +
                        "{\"sentenceBoundaryEnabled\":\"false\",\"wordBoundaryEnabled\":\"false\"}," +
                        "\"outputFormat\":\"audio-24khz-48kbitrate-mono-mp3\"}}}}\r\n"
                webSocket.send(config)

                val ssml = "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>" +
                        "<voice name='" + voice + "'><prosody pitch='+0Hz' rate='" + rate + "' volume='+0%'>" +
                        xmlEscape(text) + "</prosody></voice></speak>"
                val msg = "X-RequestId:" + UUID.randomUUID().toString().replace("-", "") + "\r\n" +
                        "Content-Type:application/ssml+xml\r\n" +
                        "X-Timestamp:" + timestamp() + "Z\r\n" +
                        "Path:ssml\r\n\r\n" + ssml
                webSocket.send(msg)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.contains("Path:turn.end")) {
                    main.removeCallbacks(timeout)
                    val bytes = audio.toByteArray()
                    if (bytes.isNotEmpty()) finish(bytes, null) else finish(null, "Free voice returned no audio.")
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                if (bytes.size < 2) return
                val headerLen = ((bytes[0].toInt() and 0xFF) shl 8) or (bytes[1].toInt() and 0xFF)
                if (bytes.size < 2 + headerLen) return
                val header = bytes.substring(2, 2 + headerLen).utf8()
                if (header.contains("Path:audio")) {
                    audio.write(bytes.substring(2 + headerLen).toByteArray())
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                main.removeCallbacks(timeout)
                // A wrong phone clock makes the service refuse us: learn the real time and try once more.
                if (response?.code == 403 && allowRetry && !finished.get()) {
                    try {
                        val date = response.header("Date")
                        if (date != null) {
                            val f = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
                            val server = f.parse(date)?.time ?: 0L
                            if (server > 0L) {
                                skewSeconds = (server - System.currentTimeMillis()) / 1000
                                if (finished.compareAndSet(false, true)) {
                                    attempt(text, voice, rate, false, done)
                                }
                                return
                            }
                        }
                    } catch (e: Exception) {
                        /* fall through */
                    }
                }
                finish(null, "Free voice failed (" + (response?.code?.toString() ?: "no reply") + "): " + (t.message ?: "unknown error"))
            }
        })
    }
}
