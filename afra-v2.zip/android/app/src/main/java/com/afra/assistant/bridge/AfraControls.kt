package com.afra.assistant.bridge

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationManagerCompat
import com.afra.assistant.MainActivity
import com.afra.assistant.notify.AfraNotificationListener
import com.afra.assistant.overlay.AfraOverlayService
import com.afra.assistant.overlay.OverlayPermissionHelper
import com.afra.assistant.wake.AfraWakeService
import org.json.JSONArray

/**
 * Everything the web app can ask the phone to do. Available in JavaScript as window.AfraNative.
 */
class AfraControls(private val activity: MainActivity) {

    private val ctx: Context = activity.applicationContext

    /* ---------------- floating avatar ---------------- */

    @JavascriptInterface
    fun hasOverlayPermission(): Boolean = OverlayPermissionHelper.canDrawOverlays(ctx)

    @JavascriptInterface
    fun requestOverlayPermission() {
        activity.runOnUiThread {
            try {
                activity.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun isOverlayRunning(): Boolean = AfraOverlayService.isRunning

    @JavascriptInterface
    fun startOverlay() {
        activity.runOnUiThread {
            activity.askNotificationPermission()
            OverlayPermissionHelper.startOverlayService(ctx)
        }
    }

    @JavascriptInterface
    fun stopOverlay() {
        activity.runOnUiThread {
            try {
                ctx.startService(
                    Intent(ctx, AfraOverlayService::class.java).apply { action = AfraOverlayService.ACTION_STOP_OVERLAY }
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /* ---------------- "Hey AFRA" background listening ---------------- */

    @JavascriptInterface
    fun isWakeRunning(): Boolean = AfraWakeService.running

    @JavascriptInterface
    fun startWake() {
        activity.runOnUiThread { activity.startWakeFlow() }
    }

    @JavascriptInterface
    fun stopWake() {
        activity.runOnUiThread {
            try {
                ctx.stopService(Intent(ctx, AfraWakeService::class.java))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun setWakePhrases(json: String) {
        try {
            JSONArray(json) // validate
            ctx.getSharedPreferences(AfraWakeService.PREFS, Context.MODE_PRIVATE)
                .edit().putString(AfraWakeService.KEY_PHRASES, json).apply()
            AfraWakeService.instance?.reload()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JavascriptInterface
    fun setWakeLanguage(lang: String) {
        ctx.getSharedPreferences(AfraWakeService.PREFS, Context.MODE_PRIVATE)
            .edit().putString(AfraWakeService.KEY_LANG, lang).apply()
        AfraWakeService.instance?.reload()
    }

    @JavascriptInterface
    fun requestBatteryUnrestricted() {
        activity.runOnUiThread {
            try {
                activity.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
                )
            } catch (e: Exception) {
                try {
                    activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e2: Exception) {
                    e2.printStackTrace()
                }
            }
        }
    }

    /* ---------------- notifications ---------------- */

    @JavascriptInterface
    fun hasNotificationAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    @JavascriptInterface
    fun openNotificationAccessSettings() {
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun getNotifications(): String = AfraNotificationListener.snapshotJson(10)

    /* ---------------- open any app by name ---------------- */

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            val type = Character.getType(ch)
            if (Character.isLetterOrDigit(ch) ||
                type == Character.NON_SPACING_MARK.toInt() ||
                type == Character.COMBINING_SPACING_MARK.toInt()
            ) {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    // Bangla spoken names -> the name the app usually has on the phone
    private val aliases: List<Pair<String, String>> = listOf(
        "ফেসবুকলাইট" to "facebooklite",
        "ফেসবুক" to "facebook",
        "ম্যাসেঞ্জার" to "messenger",
        "মেসেঞ্জার" to "messenger",
        "হোয়াটসঅ্যাপ" to "whatsapp",
        "হোয়াটসএপ" to "whatsapp",
        "হোয়াটস" to "whatsapp",
        "ইউটিউব" to "youtube",
        "ইউটিউভ" to "youtube",
        "ইনস্টাগ্রাম" to "instagram",
        "টিকটক" to "tiktok",
        "টেলিগ্রাম" to "telegram",
        "জিমেইল" to "gmail",
        "গুগলম্যাপ" to "maps",
        "ম্যাপ" to "maps",
        "গুগল" to "google",
        "ক্রোম" to "chrome",
        "ক্যামেরা" to "camera",
        "গ্যালারি" to "gallery",
        "ছবি" to "photos",
        "সেটিংস" to "settings",
        "সেটিং" to "settings",
        "ক্যালকুলেটর" to "calculator",
        "ঘড়ি" to "clock",
        "ক্যালেন্ডার" to "calendar",
        "প্লেস্টোর" to "playstore",
        "ফোন" to "phone",
        "ডায়লার" to "phone",
        "কন্টাক্ট" to "contacts",
        "মেসেজ" to "messages",
        "ইমো" to "imo",
        "বিকাশ" to "bkash",
        "নগদ" to "nagad",
        "স্পটিফাই" to "spotify",
        "নেটফ্লিক্স" to "netflix",
        "টুইটার" to "twitter",
        "লিংকডইন" to "linkedin",
        "স্ন্যাপচ্যাট" to "snapchat",
        "ফাইল" to "files"
    )

    @JavascriptInterface
    fun openApp(spoken: String): String {
        val q0 = norm(spoken)
        if (q0.isEmpty()) return ""

        // If a Bangla alias is part of what was said, search for its English name too.
        var target = q0
        for ((bn, en) in aliases) {
            if (q0.contains(norm(bn))) {
                target = en
                break
            }
        }

        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)

        var bestScore = 0
        var bestPkg: String? = null
        var bestLabel = ""
        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            val label = ri.loadLabel(pm).toString()
            val ln = norm(label)
            if (ln.isEmpty()) continue
            val pk = pkg.lowercase()
            var score = 0
            when {
                ln == target || ln == q0 -> score = 100
                ln.contains(target) || ln.contains(q0) ->
                    score = 70 - minOf(40, ln.length - minOf(ln.length, target.length))
                ln.length >= 3 && (target.contains(ln) || q0.contains(ln)) -> score = 50
                pk.contains(target) -> score = 35
            }
            if (score > bestScore) {
                bestScore = score
                bestPkg = pkg
                bestLabel = label
            }
        }

        val pkg = bestPkg ?: return ""
        val intent = pm.getLaunchIntentForPackage(pkg) ?: return ""
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.runOnUiThread {
            try {
                activity.startActivity(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return bestLabel
    }
}
