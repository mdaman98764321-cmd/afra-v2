package com.afra.assistant.bridge

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import java.io.File
import android.provider.Settings
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationManagerCompat
import com.afra.assistant.MainActivity
import com.afra.assistant.notify.AfraNotificationListener
import com.afra.assistant.overlay.AfraOverlayService
import com.afra.assistant.overlay.OverlayPermissionHelper
import com.afra.assistant.wake.AfraWakeService
import com.afra.assistant.voice.EdgeTts
import com.afra.assistant.voice.SimpleTts
import org.json.JSONArray
import org.json.JSONObject

/**
 * Everything the web app can ask the phone to do. Available in JavaScript as window.AfraNative.
 */
class AfraControls(private val activity: MainActivity) {

    private val ctx: Context = activity.applicationContext

    /* ---------------- free back-up voice ---------------- */

    @JavascriptInterface
    fun edgeTts(requestId: String, text: String, voice: String, rate: String) {
        activity.runOnUiThread {
            EdgeTts.synthesize(text, voice, rate) { bytes, err ->
                val id = JSONObject.quote(requestId)
                val js = if (bytes != null) {
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    "window.__afraEdgeResult&&window.__afraEdgeResult($id,${JSONObject.quote(b64)},'');"
                } else {
                    "window.__afraEdgeResult&&window.__afraEdgeResult($id,'',${JSONObject.quote(err ?: "failed")});"
                }
                activity.runJs(js)
            }
        }
    }

    @JavascriptInterface
    fun simpleTts(requestId: String, text: String, lang: String) {
        activity.runOnUiThread {
            SimpleTts.synthesize(text, lang) { bytes, err ->
                val id = JSONObject.quote(requestId)
                val js = if (bytes != null) {
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    "window.__afraEdgeResult&&window.__afraEdgeResult($id,${JSONObject.quote(b64)},'');"
                } else {
                    "window.__afraEdgeResult&&window.__afraEdgeResult($id,'',${JSONObject.quote(err ?: "failed")});"
                }
                activity.runJs(js)
            }
        }
    }

    /* ---------------- floating avatar ---------------- */

    @JavascriptInterface
    fun hasOverlayPermission(): Boolean = OverlayPermissionHelper.canDrawOverlays(ctx)

    @JavascriptInterface
    fun requestOverlayPermission() {
        activity.runOnUiThread {
            try {
                activity.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun isOverlayRunning(): Boolean = AfraOverlayService.isRunning

    @JavascriptInterface
    fun startOverlay() {
        activity.runOnUiThread {
            activity.askNotificationPermission()
            OverlayPermissionHelper.startOverlayService(ctx)
        }
    }

    @JavascriptInterface
    fun stopOverlay() {
        activity.runOnUiThread {
            try {
                ctx.startService(
                    Intent(ctx, AfraOverlayService::class.java).apply { action = AfraOverlayService.ACTION_STOP_OVERLAY }
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun setOverlayAvatar(base64Png: String) {
        try {
            val bytes = Base64.decode(base64Png, Base64.DEFAULT)
            File(ctx.filesDir, AfraOverlayService.AVATAR_FILE).writeBytes(bytes)
            ctx.getSharedPreferences(AfraOverlayService.PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putString("character", "photo").apply()
            reloadOverlayAvatar()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JavascriptInterface
    fun clearOverlayAvatar() {
        try {
            val f = File(ctx.filesDir, AfraOverlayService.AVATAR_FILE)
            if (f.exists()) {
                f.delete()
                val prefs = ctx.getSharedPreferences(AfraOverlayService.PREFS_NAME, Context.MODE_PRIVATE)
                if (prefs.getString("character", "afra") == "photo") prefs.edit().putString("character", "afra").apply()
                reloadOverlayAvatar()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun reloadOverlayAvatar() {
        if (!AfraOverlayService.isRunning) return
        try {
            ctx.startService(
                Intent(ctx, AfraOverlayService::class.java).apply { action = AfraOverlayService.ACTION_RELOAD_AVATAR }
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /* ---------------- "Hey AFRA" background listening ---------------- */

    @JavascriptInterface
    fun isWakeRunning(): Boolean = AfraWakeService.running

    @JavascriptInterface
    fun startWake() {
        activity.runOnUiThread { activity.startWakeFlow() }
    }

    @JavascriptInterface
    fun stopWake() {
        activity.runOnUiThread {
            try {
                ctx.stopService(Intent(ctx, AfraWakeService::class.java))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun setWakePhrases(json: String) {
        try {
            JSONArray(json) // validate
            ctx.getSharedPreferences(AfraWakeService.PREFS, Context.MODE_PRIVATE)
                .edit().putString(AfraWakeService.KEY_PHRASES, json).apply()
            AfraWakeService.instance?.reload()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JavascriptInterface
    fun setWakeLanguage(lang: String) {
        ctx.getSharedPreferences(AfraWakeService.PREFS, Context.MODE_PRIVATE)
            .edit().putString(AfraWakeService.KEY_LANG, lang).apply()
        AfraWakeService.instance?.reload()
    }

    @JavascriptInterface
    fun requestBatteryUnrestricted() {
        activity.runOnUiThread {
            try {
                activity.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
                )
            } catch (e: Exception) {
                try {
                    activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e2: Exception) {
                    e2.printStackTrace()
                }
            }
        }
    }

    /* ---------------- notifications ---------------- */

    @JavascriptInterface
    fun hasNotificationAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    @JavascriptInterface
    fun openNotificationAccessSettings() {
        activity.runOnUiThread {
            try {
                activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun getNotifications(): String = AfraNotificationListener.snapshotJson(10)

    /* ---------------- open any app by name ---------------- */

    @JavascriptInterface
    fun openApp(spoken: String): String {
        val found = AppLauncher.find(ctx, spoken) ?: return ""
        activity.runOnUiThread {
            try {
                activity.startActivity(found.second)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return found.first
    }
}
