package com.afra.assistant.bridge

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.afra.assistant.overlay.AfraOverlayService
import com.afra.assistant.overlay.OverlayPermissionHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject

enum class AvatarState { IDLE, LISTENING, THINKING, SPEAKING, HAPPY, ERROR }

/**
 * JavaScript Bridge for bidirectional communication between the AFRA Web Engine
 * and Native Android OS capabilities (Overlay Service, WindowManager, Keystore).
 */
class AfraNativeBridge(
    private val activity: Activity,
    private val webView: WebView
) {
    private val _avatarState = MutableStateFlow(AvatarState.IDLE)
    val avatarState: StateFlow<AvatarState> = _avatarState

    private val _audioAmplitude = MutableStateFlow(0f)
    val audioAmplitude: StateFlow<Float> = _audioAmplitude

    @JavascriptInterface
    fun isOverlayPermissionGranted(): Boolean {
        return OverlayPermissionHelper.canDrawOverlays(activity)
    }

    @JavascriptInterface
    fun requestOverlayPermission() {
        activity.runOnUiThread {
            OverlayPermissionHelper.requestOverlayPermission(activity)
        }
    }

    @JavascriptInterface
    fun startOverlayService() {
        activity.runOnUiThread {
            OverlayPermissionHelper.startOverlayService(activity)
        }
    }

    @JavascriptInterface
    fun stopOverlayService() {
        activity.runOnUiThread {
            OverlayPermissionHelper.stopOverlayService(activity)
        }
    }

    @JavascriptInterface
    fun setOverlayAvatarState(state: String, audioLevel: Float) {
        val intent = Intent(activity, AfraOverlayService::class.java).apply {
            action = AfraOverlayService.ACTION_SET_STATE
            putExtra(AfraOverlayService.EXTRA_STATE, state)
            putExtra(AfraOverlayService.EXTRA_AUDIO_LEVEL, audioLevel)
        }
        activity.startService(intent)
    }

    @JavascriptInterface
    fun onStateChange(jsonPayload: String) {
        try {
            val json = JSONObject(jsonPayload)
            val stateStr = json.optString("state", "idle").uppercase()
            val state = AvatarState.valueOf(stateStr)
            _avatarState.value = state

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JavascriptInterface
    fun onSpeechRecognized(transcript: String, isFinal: Boolean) {
        val script = "window.AfraBridge?.onSpeechRecognized?.(${JSONObject.quote(transcript)}, $isFinal);"
        webView.post { webView.evaluateJavascript(script, null) }
    }

    // Call into Web Avatar Engine from Native Android UI
    fun sendAvatarState(state: AvatarState, audioLevel: Float) {
        val script = "window.postMessage({ state: '${state.name.lowercase()}', audioLevel: $audioLevel }, '*');"
        webView.post {
            webView.evaluateJavascript(script, null)
        }
    }
}
