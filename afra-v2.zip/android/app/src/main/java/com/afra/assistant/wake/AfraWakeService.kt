package com.afra.assistant.wake

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import com.afra.assistant.MainActivity
import org.json.JSONArray

/**
 * Listens in the background for the wake name ("Hello AFRA" or any name the user added).
 * When heard, it brings AFRA to the front in voice mode.
 */
class AfraWakeService : Service() {

    companion object {
        const val PREFS = "afra_wake_prefs"
        const val KEY_PHRASES = "phrases"
        const val KEY_LANG = "lang"
        const val ACTION_START = "com.afra.assistant.wake.START"
        const val ACTION_STOP = "com.afra.assistant.wake.STOP"
        private const val CHANNEL_ID = "afra_wake_channel"
        private const val ALERT_CHANNEL_ID = "afra_wake_alert_channel"
        private const val NOTIF_ID = 4042
        private const val ALERT_ID = 4043

        @Volatile
        var running = false

        @Volatile
        var instance: AfraWakeService? = null

        val defaultPhrases = listOf("হ্যালো আফরা", "hello afra", "hey afra")
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null

    @Volatile
    private var suspended = false
    private var errorCount = 0
    private var lastTrigger = 0L
    private var phrases: List<String> = defaultPhrases
    private var lang = "bn-BD"

    private val restartTask = Runnable { startListening() }
    private val resumeCheck = Runnable {
        if (running && !MainActivity.visible) setSuspended(false)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            try {
                createChannels()
                val n = buildNotification()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
                } else {
                    startForeground(NOTIF_ID, n)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                stopSelf()
                return START_NOT_STICKY
            }
            running = true
            instance = this
            suspended = MainActivity.visible
            reload()
            if (!suspended) startListening()
        }
        return START_STICKY
    }

    /** Re-reads the wake names and language the user saved. */
    fun reload() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        lang = prefs.getString(KEY_LANG, "bn-BD") ?: "bn-BD"
        val json = prefs.getString(KEY_PHRASES, null)
        val list = ArrayList<String>()
        if (json != null) {
            try {
                val arr = JSONArray(json)
                for (i in 0 until arr.length()) {
                    val s = arr.optString(i).trim()
                    if (s.isNotEmpty()) list.add(s)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        phrases = if (list.isEmpty()) defaultPhrases else list
    }

    /** Pause while AFRA itself is on screen (it uses the microphone), resume afterwards. */
    fun setSuspended(value: Boolean) {
        handler.post {
            suspended = value
            if (value) {
                handler.removeCallbacks(restartTask)
                destroyRecognizer()
            } else if (running) {
                restart(400)
            }
        }
    }

    private fun restart(delayMs: Long) {
        handler.removeCallbacks(restartTask)
        handler.postDelayed(restartTask, delayMs)
    }

    private fun startListening() {
        if (!running || suspended) return
        try {
            destroyRecognizer()
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                stopSelf()
                return
            }
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(listener)
            recognizer = r
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
            )
        } catch (e: Exception) {
            e.printStackTrace()
            restart(2500)
        }
    }

    private fun destroyRecognizer() {
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        recognizer = null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            errorCount = 0
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            checkWake(partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION))
        }

        override fun onResults(results: Bundle?) {
            if (!checkWake(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION))) {
                restart(150)
            }
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(250)
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restart(1200)
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> stopSelf()
                else -> {
                    errorCount++
                    restart(minOf(6000L, 800L * errorCount))
                }
            }
        }
    }

    private fun checkWake(list: List<String>?): Boolean {
        if (list == null) return false
        for (t in list) {
            if (matches(t)) {
                trigger()
                return true
            }
        }
        return false
    }

    private fun trigger() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastTrigger < 4000) return
        lastTrigger = now

        suspended = true
        handler.removeCallbacks(restartTask)
        destroyRecognizer()

        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            )
            putExtra("afra_action", "start_voice")
        }
        try {
            if (Settings.canDrawOverlays(this)) startActivity(intent) else notifyTap(intent)
        } catch (e: Exception) {
            notifyTap(intent)
        }
        // Safety net: if AFRA could not come to the front, start listening again later.
        handler.removeCallbacks(resumeCheck)
        handler.postDelayed(resumeCheck, 10000)
    }

    private fun notifyTap(intent: Intent) {
        val pi = PendingIntent.getActivity(
            this, 2, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, ALERT_CHANNEL_ID)
            .setContentTitle("AFRA")
            .setContentText("আমি শুনেছি! কথা বলতে এখানে ট্যাপ করুন")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(ALERT_ID, n)
    }

    /* ---------- name matching (forgiving of small speech-recognition mistakes) ---------- */

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            val type = Character.getType(ch)
            if (Character.isLetterOrDigit(ch) ||
                type == Character.NON_SPACING_MARK.toInt() ||
                type == Character.COMBINING_SPACING_MARK.toInt()
            ) {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    private fun matches(text: String): Boolean {
        val t = norm(text)
        if (t.isEmpty()) return false
        for (p in phrases) {
            val pn = norm(p)
            if (pn.length < 3) continue
            if (t.contains(pn)) return true
            val tol = maxOf(1, pn.length / 4)
            val minL = maxOf(1, pn.length - tol)
            val maxL = pn.length + tol
            for (len in minL..maxL) {
                if (len > t.length) break
                var i = 0
                while (i + len <= t.length) {
                    if (lev(t.substring(i, i + len), pn) <= tol) return true
                    i++
                }
            }
        }
        return false
    }

    /* ---------- notification ---------- */

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "AFRA listening", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Shows that AFRA is waiting to hear its name"
                    setShowBadge(false)
                }
            )
            nm.createNotificationChannel(
                NotificationChannel(ALERT_CHANNEL_ID, "AFRA wake alert", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, AfraWakeService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AFRA শুনছে")
            .setContentText("আপনার ডাকের অপেক্ষায় আছি")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "বন্ধ করুন", stop)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        running = false
        instance = null
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        super.onDestroy()
    }
}
