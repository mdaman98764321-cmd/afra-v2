package com.afra.assistant.bridge

import android.content.Context
import android.content.Intent

/** Finds an installed app from a spoken name and prepares the intent to open it. */
object AppLauncher {

    private val openWords = listOf(
        "open", "launch", "start", "run",
        "খোলো", "খুলো", "খোল", "খুলুন", "খুলে দাও", "খুলে দিন", "ওপেন", "চালু করো", "চালু কর", "চালু করুন", "চালাও", "চালান"
    )
    private val fillers = listOf(
        "the", "app", "please", "plz", "my", "for", "me", "to", "now",
        "অ্যাপ", "এ্যাপ", "অ্যাপটি", "এপ", "এপটা", "অ্যাপটা", "টা", "টি", "দাও", "দিন", "করো", "কর", "করুন", "প্লিজ", "একটু", "এখন",
        "আফরা", "আফ্রা", "আফরার", "হ্যালো", "হেই", "হেয়", "হে", "হ্যাঁ", "hey", "hello", "afra"
    )

    private val aliases: List<Pair<String, String>> = listOf(
        "ফেসবুকলাইট" to "facebooklite",
        "ফেসবুক" to "facebook",
        "ফেইসবুক" to "facebook",
        "ফেজবুক" to "facebook",
        "ম্যাসেঞ্জার" to "messenger",
        "মেসেঞ্জার" to "messenger",
        "মেসেনজার" to "messenger",
        "হোয়াটসঅ্যাপ" to "whatsapp",
        "হোয়াটসএপ" to "whatsapp",
        "হোয়াটস" to "whatsapp",
        "হোয়াটসঅ্যাপ" to "whatsapp",
        "ইউটিউব" to "youtube",
        "ইউটিউভ" to "youtube",
        "ইউটিউব" to "youtube",
        "ইনস্টাগ্রাম" to "instagram",
        "ইন্সটাগ্রাম" to "instagram",
        "টিকটক" to "tiktok",
        "টেলিগ্রাম" to "telegram",
        "জিমেইল" to "gmail",
        "গুগলম্যাপ" to "maps",
        "ম্যাপ" to "maps",
        "গুগল" to "google",
        "ক্রোম" to "chrome",
        "ক্যামেরা" to "camera",
        "গ্যালারি" to "gallery",
        "ছবি" to "photos",
        "সেটিংস" to "settings",
        "সেটিং" to "settings",
        "ক্যালকুলেটর" to "calculator",
        "ঘড়ি" to "clock",
        "ক্যালেন্ডার" to "calendar",
        "প্লেস্টোর" to "playstore",
        "ফোন" to "phone",
        "ডায়লার" to "phone",
        "কন্টাক্ট" to "contacts",
        "মেসেজ" to "messages",
        "ইমো" to "imo",
        "বিকাশ" to "bkash",
        "নগদ" to "nagad",
        "স্পটিফাই" to "spotify",
        "নেটফ্লিক্স" to "netflix",
        "টুইটার" to "twitter",
        "লিংকডইন" to "linkedin",
        "স্ন্যাপচ্যাট" to "snapchat",
        "ফাইল" to "files"
    )

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            val type = Character.getType(ch)
            if (Character.isLetterOrDigit(ch) ||
                type == Character.NON_SPACING_MARK.toInt() ||
                type == Character.COMBINING_SPACING_MARK.toInt()
            ) {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    /** "hello afra open facebook" -> "facebook". Returns null if this is not an "open an app" command. */
    fun parseOpenCommand(text: String, extraWords: List<String> = emptyList()): String? {
        val lower = " " + text.lowercase().replace(Regex("[.,!?।\"']"), " ") + " "
        val hasOpen = openWords.any { lower.contains(" $it ") }
        if (!hasOpen) return null
        var out = lower
        for (w in (openWords + fillers + extraWords).sortedByDescending { it.length }) {
            out = out.replace(" $w ", "  ").replace(" $w ", "  ")
        }
        val name = out.trim().replace(Regex("\\s+"), " ")
        val words = text.trim().split(Regex("\\s+")).size
        return if (words <= 8 && name.length >= 2) name else null
    }

    /** Returns (app name, intent to open it) or null if no app matches. */
    fun find(ctx: Context, spoken: String): Pair<String, Intent>? {
        val q0 = norm(spoken)
        if (q0.isEmpty()) return null

        var target = q0
        for ((bn, en) in aliases) {
            if (q0.contains(norm(bn))) {
                target = en
                break
            }
        }

        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)

        var bestScore = 0
        var bestPkg: String? = null
        var bestLabel = ""
        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            val label = ri.loadLabel(pm).toString()
            val ln = norm(label)
            if (ln.isEmpty()) continue
            val pk = pkg.lowercase()
            var score = 0
            if (ln == target || ln == q0) {
                score = 100
            } else if (ln.contains(target) || ln.contains(q0)) {
                score = 70 - minOf(40, ln.length - minOf(ln.length, target.length))
            } else if (ln.length >= 3 && (target.contains(ln) || q0.contains(ln))) {
                score = 50
            } else if (pk.contains(target)) {
                score = 35
            } else if (target.length >= 4 && ln.length >= 4 && lev(ln, target) <= maxOf(1, target.length / 4)) {
                score = 45
            }
            if (score > bestScore) {
                bestScore = score
                bestPkg = pkg
                bestLabel = label
            }
        }

        val pkg = bestPkg ?: return null
        val intent = pm.getLaunchIntentForPackage(pkg) ?: return null
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return Pair(bestLabel, intent)
    }
}
