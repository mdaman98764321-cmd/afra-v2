package com.afra.assistant.voice

import android.os.Handler
import android.os.Looper
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Simple internet request made by the phone itself (used for voice services). */
object NativeHttp {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .build()
    private val main = Handler(Looper.getMainLooper())

    fun request(
        method: String, url: String, headersJson: String, body: String?,
        done: (Int, ByteArray?, String?) -> Unit
    ) {
        Thread {
            try {
                val rb = Request.Builder().url(url)
                val h = JSONObject(headersJson)
                val keys = h.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    rb.header(k, h.getString(k))
                }
                if (method.uppercase() == "POST") {
                    rb.post((body ?: "").toRequestBody("application/json".toMediaType()))
                } else {
                    rb.get()
                }
                client.newCall(rb.build()).execute().use { r ->
                    val bytes = r.body?.bytes() ?: ByteArray(0)
                    val code = r.code
                    main.post { done(code, bytes, null) }
                }
            } catch (e: Exception) {
                main.post { done(0, null, e.message ?: "request failed") }
            }
        }.start()
    }
}
