package com.afra.assistant.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat

/**
 * Custom Android View for the 56dp Floating Avatar Overlay with hardware-accelerated
 * Canvas drawing, state glow animations, and explicit microphone status indicator.
 */
class AfraOverlayView(context: Context) : View(context) {

    private var currentState = "idle"
    private var audioAmplitude = 0f
    private var isPressedScale = false
    private var showMicIndicator = false

    // Color definitions
    private val colorViolet = Color.parseColor("#8B5CF6")
    private val colorCyan = Color.parseColor("#06B6D4")
    private val colorEmerald = Color.parseColor("#10B981")
    private val colorRose = Color.parseColor("#F43F5E")
    private val colorBgDark = Color.parseColor("#0B0D10")
    private val colorBorder = Color.parseColor("#334155")

    // Cute-face paints
    private val earPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#7C3AED") }
    private val earInnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#F9A8D4") }
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val pupilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#1E1B4B") }
    private val blushPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#FB7185"); alpha = 110 }
    private val mouthLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2f * resources.displayMetrics.density
    }
    private val mouthFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#4C1D95") }
    private val facePath = Path()
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var avatarBitmap: Bitmap? = null

    private var character: String = "afra"

    init {
        reloadAvatar()
    }

    /** Re-reads which character the user picked (and their own picture, if they chose it). */
    fun reloadAvatar() {
        val prefs = context.getSharedPreferences(AfraOverlayService.PREFS_NAME, Context.MODE_PRIVATE)
        character = prefs.getString("character", "afra") ?: "afra"
        avatarBitmap = null
        if (character == "photo") {
            avatarBitmap = try {
                val f = File(context.filesDir, AfraOverlayService.AVATAR_FILE)
                if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
            } catch (e: Exception) {
                null
            }
            if (avatarBitmap == null) character = "afra"
        }
        invalidate()
    }

    // Paints
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * resources.displayMetrics.density
        color = colorBorder
    }

    private val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
        color = colorViolet
    }

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = colorBgDark
    }

    private val micBadgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = colorCyan
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = 14f * resources.displayMetrics.density
    }

    // Animators
    private var orbitAngle = 0f
    private var breathFraction = 0f
    private val orbitAnimator: ValueAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 1600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            orbitAngle = it.animatedValue as Float
            invalidate()
        }
    }

    private val breathAnimator: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener {
            breathFraction = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        breathAnimator.start()
    }

    fun setAnimationState(state: String, level: Float = 0f) {
        currentState = state.lowercase()
        audioAmplitude = level

        if (currentState == "thinking" && !orbitAnimator.isRunning) {
            orbitAnimator.start()
        } else if (currentState != "thinking" && orbitAnimator.isRunning) {
            orbitAnimator.cancel()
        }

        invalidate()
    }

    fun setPressedScale(pressed: Boolean) {
        isPressedScale = pressed
        invalidate()
    }

    fun showMicrophoneIndicator(show: Boolean) {
        showMicIndicator = show
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (character == "cat" || character == "girl" || character == "ghost") {
            drawStyled(canvas)
            return
        }
        super.onDraw(canvas)

        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = (width.coerceAtMost(height) / 2f) - (8f * resources.displayMetrics.density)

        // Scale factor for press/speech feedback
        val scale = when {
            isPressedScale -> 0.92f
            currentState == "speaking" -> 1f + (audioAmplitude * 0.12f)
            currentState == "happy" -> 1.06f
            else -> 1f + (breathFraction * 0.03f)
        }

        canvas.save()
        canvas.scale(scale, scale, cx, cy)

        // 1. Draw dynamic state glow halo
        val glowColor = when (currentState) {
            "listening" -> colorCyan
            "thinking" -> colorViolet
            "speaking" -> colorCyan
            "happy" -> colorEmerald
            "error" -> colorRose
            else -> colorViolet
        }

        val glowRadius = baseRadius + (6f * resources.displayMetrics.density) + (audioAmplitude * 10f)
        haloPaint.shader = RadialGradient(
            cx, cy, glowRadius,
            glowColor,
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        haloPaint.alpha = when (currentState) {
            "listening" -> 160
            "speaking" -> 180
            "thinking" -> 140
            "happy" -> 150
            "error" -> 170
            else -> 90
        }
        canvas.drawCircle(cx, cy, glowRadius, haloPaint)

        when (character) {
            else -> {
        // 1b. Little cat ears (only for the default character)
        if (avatarBitmap == null) drawEars(canvas, cx, cy, baseRadius)

        // 2. Draw core avatar circle (soft purple ball)
        corePaint.shader = RadialGradient(
            cx, cy - baseRadius * 0.35f, baseRadius * 1.4f,
            Color.parseColor("#C4B5FD"), Color.parseColor("#6D28D9"),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, baseRadius, corePaint)

        // 2b. The user's own picture, cropped round
        val bmp = avatarBitmap
        if (bmp != null) {
            facePath.reset()
            facePath.addCircle(cx, cy, baseRadius - 2f, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(facePath)
            canvas.drawBitmap(
                bmp,
                Rect(0, 0, bmp.width, bmp.height),
                RectF(cx - baseRadius, cy - baseRadius, cx + baseRadius, cy + baseRadius),
                bitmapPaint
            )
            canvas.restore()
        }

            }
        }

        // 3. Draw state specific animations
        when (currentState) {
            "thinking" -> {
                // Orbiting ring
                val orbitRadius = baseRadius + (3f * resources.displayMetrics.density)
                val rect = RectF(
                    cx - orbitRadius, cy - orbitRadius,
                    cx + orbitRadius, cy + orbitRadius
                )
                canvas.drawArc(rect, orbitAngle, 100f, false, orbitPaint)
            }
            "listening" -> {
                // Sound wave ring
                val pulseRadius = baseRadius + (audioAmplitude * 8f * resources.displayMetrics.density)
                borderPaint.color = colorCyan
                canvas.drawCircle(cx, cy, pulseRadius, borderPaint)
            }
        }

        // 4. Central Monogram / Avatar Graphic
        borderPaint.color = when (currentState) {
            "listening" -> colorCyan
            "speaking" -> colorViolet
            "happy" -> colorEmerald
            "error" -> colorRose
            else -> colorBorder
        }
        val roundCharacter = character == "afra" || character == "photo"
        if (roundCharacter || currentState == "listening" || currentState == "speaking" ||
            currentState == "happy" || currentState == "error"
        ) {
            canvas.drawCircle(cx, cy, baseRadius, borderPaint)
        }

        if (character == "afra" && avatarBitmap == null) drawFace(canvas, cx, cy, baseRadius)

        // 5. Microphone Privacy Badge (Top Right)
        if (showMicIndicator || currentState == "listening") {
            val badgeRadius = 5f * resources.displayMetrics.density
            val badgeX = cx + (baseRadius * 0.7f)
            val badgeY = cy - (baseRadius * 0.7f)
            canvas.drawCircle(badgeX, badgeY, badgeRadius, micBadgePaint)
        }

        canvas.restore()
    }

    /* ---------- small helpers for the extra characters ---------- */
    private val pp = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun hex(h: String): Int = Color.parseColor(h)

    private fun fillP(color: Int): Paint {
        pp.reset()
        pp.isAntiAlias = true
        pp.style = Paint.Style.FILL
        pp.color = color
        return pp
    }

    private fun strokeP(color: Int, widthDp: Float): Paint {
        pp.reset()
        pp.isAntiAlias = true
        pp.style = Paint.Style.STROKE
        pp.strokeCap = Paint.Cap.ROUND
        pp.color = color
        pp.strokeWidth = widthDp * resources.displayMetrics.density
        return pp
    }

    private fun blinkNow(): Boolean = (System.currentTimeMillis() % 3400L) < 150L

    private fun drawMouth(canvas: Canvas, cx: Float, my: Float, r: Float, lineColor: Int, fillColor: Int) {
        when (currentState) {
            "speaking" -> {
                val open = r * (0.08f + 0.28f * audioAmplitude.coerceIn(0f, 1f))
                canvas.drawOval(RectF(cx - r * 0.15f, my - open * 0.4f, cx + r * 0.15f, my + open), fillP(fillColor))
            }
            "listening" -> {
                canvas.drawOval(RectF(cx - r * 0.09f, my - r * 0.02f, cx + r * 0.09f, my + r * 0.15f), fillP(fillColor))
            }
            "error" -> {
                canvas.drawArc(RectF(cx - r * 0.15f, my, cx + r * 0.15f, my + r * 0.2f), 200f, 140f, false, strokeP(lineColor, 1.8f))
            }
            "happy" -> {
                canvas.drawArc(RectF(cx - r * 0.22f, my - r * 0.12f, cx + r * 0.22f, my + r * 0.18f), 20f, 140f, false, strokeP(lineColor, 1.8f))
            }
            else -> {
                canvas.drawArc(RectF(cx - r * 0.15f, my - r * 0.08f, cx + r * 0.15f, my + r * 0.1f), 25f, 130f, false, strokeP(lineColor, 1.8f))
            }
        }
    }

    /* ================== full-body characters (drawn in a 100 x 100 design space) ================== */

    private val piF = Math.PI.toFloat()

    private fun col(h: String, a: Int = 255): Int {
        val c = Color.parseColor(h)
        return Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    }

    private fun strokeD(color: Int, w: Float): Paint {
        pp.reset()
        pp.isAntiAlias = true
        pp.style = Paint.Style.STROKE
        pp.strokeCap = Paint.Cap.ROUND
        pp.color = color
        pp.strokeWidth = w
        return pp
    }

    private fun dOval(cv: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int) {
        cv.drawOval(RectF(l, t, r, b), fillP(color))
    }

    private fun dCircle(cv: Canvas, x: Float, y: Float, r: Float, color: Int) {
        cv.drawCircle(x, y, r, fillP(color))
    }

    private fun dLine(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, color: Int, w: Float) {
        cv.drawLine(x1, y1, x2, y2, strokeD(color, w))
    }

    private fun dArc(cv: Canvas, l: Float, t: Float, r: Float, b: Float, start: Float, sweep: Float, color: Int, w: Float) {
        cv.drawArc(RectF(l, t, r, b), start, sweep, false, strokeD(color, w))
    }

    private fun dPoly(cv: Canvas, color: Int, vararg p: Float) {
        facePath.reset()
        facePath.moveTo(p[0], p[1])
        var i = 2
        while (i + 1 < p.size) {
            facePath.lineTo(p[i], p[i + 1])
            i += 2
        }
        facePath.close()
        cv.drawPath(facePath, fillP(color))
    }

    private fun dPolyList(cv: Canvas, color: Int, p: List<Float>) {
        facePath.reset()
        facePath.moveTo(p[0], p[1])
        var i = 2
        while (i + 1 < p.size) {
            facePath.lineTo(p[i], p[i + 1])
            i += 2
        }
        facePath.close()
        cv.drawPath(facePath, fillP(color))
    }

    private fun lin(x0: Float, y0: Float, x1: Float, y1: Float, c0: Int, c1: Int): Shader =
        LinearGradient(x0, y0, x1, y1, c0, c1, Shader.TileMode.CLAMP)

    private fun rad(cx: Float, cy: Float, r: Float, c0: Int, c1: Int): Shader =
        RadialGradient(cx, cy, r, c0, c1, Shader.TileMode.CLAMP)

    private fun gOval(cv: Canvas, l: Float, t: Float, r: Float, b: Float, shader: Shader) {
        val p = fillP(Color.WHITE)
        p.shader = shader
        cv.drawOval(RectF(l, t, r, b), p)
    }

    private fun gPoly(cv: Canvas, shader: Shader, vararg p: Float) {
        facePath.reset()
        facePath.moveTo(p[0], p[1])
        var i = 2
        while (i + 1 < p.size) {
            facePath.lineTo(p[i], p[i + 1])
            i += 2
        }
        facePath.close()
        val paint = fillP(Color.WHITE)
        paint.shader = shader
        cv.drawPath(facePath, paint)
    }

    private fun gPolyList(cv: Canvas, shader: Shader, p: List<Float>) {
        facePath.reset()
        facePath.moveTo(p[0], p[1])
        var i = 2
        while (i + 1 < p.size) {
            facePath.lineTo(p[i], p[i + 1])
            i += 2
        }
        facePath.close()
        val paint = fillP(Color.WHITE)
        paint.shader = shader
        cv.drawPath(facePath, paint)
    }

    private var tapStart = 0L
    private var tapP = -1f

    /** Called when the avatar is tapped: plays a short reaction animation. */
    fun playTap() {
        tapStart = System.currentTimeMillis()
        invalidate()
    }

    private fun tSec(): Float = ((System.currentTimeMillis() % 100000L) / 1000f)

    private fun drawStyled(canvas: Canvas) {
        val size = minOf(width, height).toFloat()
        val u = size / 100f
        val t = tSec()
        val elapsed = System.currentTimeMillis() - tapStart
        tapP = if (tapStart > 0L && elapsed < 1300L) elapsed / 1300f else -1f
        canvas.save()
        canvas.translate((width - size) / 2f, (height - size) / 2f)
        canvas.scale(u, u)
        when (character) {
            "cat" -> drawCatFull(canvas, t, currentState, audioAmplitude.coerceIn(0f, 1f))
            "girl" -> drawGirlFull(canvas, t, currentState, audioAmplitude.coerceIn(0f, 1f))
            "ghost" -> drawGhostFull(canvas, t, currentState, audioAmplitude.coerceIn(0f, 1f))
        }
        if (tapP >= 0f) drawBurst(canvas, tapP, 34f)
        canvas.restore()
        postInvalidateOnAnimation()
    }

    /** Outline of an almond-shaped anime eye; the outer corner tilts up a little (looks confident). */
    private fun almondPts(cx: Float, cy: Float, rx: Float, rt: Float, rb: Float, sgn: Float, tilt: Float, n: Int): FloatArray {
        val out = FloatArray(n * 2)
        for (k in 0 until n) {
            val th = 2f * piF * k / n
            val x = rx * cos(th)
            val y0 = (if (sin(th) < 0f) rt else rb) * sin(th)
            out[k * 2] = cx + x
            out[k * 2 + 1] = cy + y0 - x * sgn * tilt
        }
        return out
    }

    /** Big, glossy golden anime eye with a soft upper lash line and a small flick at the outer corner. */
    private fun drawGirlEye(cv: Canvas, ex: Float, ey: Float, sg: Float, gaze: Float) {
        val rx = 6.9f
        val rt = 7.2f
        val rb = 6.4f
        val lash = col("#2A0A12")
        val pts = almondPts(ex, ey, rx, rt, rb, sg, 0.18f, 48)
        dPolyList(cv, col("#FFFFFF"), pts.toList())
        val ix = ex + sg * 0.3f + gaze
        val iy = ey + 0.6f
        gOval(cv, ix - 5.2f, iy - 6.4f, ix + 5.2f, iy + 6.0f, lin(ix, iy - 6.4f, ix, iy + 6.0f, col("#B45309"), col("#FCD34D")))
        gOval(cv, ix - 4.2f, iy - 4.6f, ix + 4.2f, iy + 5.4f, rad(ix, iy + 1.8f, 5.0f, col("#FDE68A"), col("#F59E0B")))
        dOval(cv, ix - 1.9f, iy - 2.6f, ix + 1.9f, iy + 2.8f, lash)
        dCircle(cv, ix - 2.1f, iy - 2.8f, 1.9f, col("#FFFFFF"))
        dCircle(cv, ix + 2.0f, iy + 2.6f, 0.95f, col("#FFFFFF", 230))
        dArc(cv, ix - 4.2f, iy - 3.6f, ix + 4.2f, iy + 5.6f, 35f, 110f, col("#FFF7D6", 150), 0.9f)
        for (i in 24..47) {
            val j = if (i == 47) 0 else i + 1
            dLine(cv, pts[i * 2], pts[i * 2 + 1], pts[j * 2], pts[j * 2 + 1], lash, 1.9f)
        }
        val oi = if (sg > 0f) 0 else 24
        dLine(cv, pts[oi * 2], pts[oi * 2 + 1], pts[oi * 2] + sg * 2.6f, pts[oi * 2 + 1] - 2.2f, lash, 1.5f)
    }

    /** Confident red-haired girl in a black suit (chibi: big head, small body), lit and shaded for depth */
    private fun drawGirlFull(cv: Canvas, t: Float, state: String, amp: Float) {
        val tp = tapP
        val tap = tp >= 0f
        val st = if (tap) "happy" else state
        val spk = st == "speaking"
        val lis = st == "listening"
        val hap = st == "happy"
        val sway = sin(t * 2.4f) + (if (tap) sin(tp * piF * 3f) * 1.8f else 0f)
        val bob = sin(t * (if (spk) 7.5f else 2.4f)) * (if (spk) 1.2f else 0.8f)
        val jump = if (tap) sin(tp * piF) * 8f else 0f
        var bY = bob - jump
        if (hap && !tap) bY = bob - abs(sin(t * 6f)) * 3f
        val turn = sin(t * 0.8f) * 1.3f
        val tilt = -2.5f + sin(t * 1.5f) * 1.5f + (if (lis) 6f + sin(t * 3f) * 1.2f else 0f)

        val skinL = col("#FFF1E6")
        val skinD = col("#F0BFA6")
        val skin = col("#FFE6D5")
        val hairL = col("#EA2F4B")
        val hairM = col("#C8102E")
        val hairD = col("#7E0A21")
        val jac0 = col("#2E3446")
        val jac1 = col("#10131A")

        // ground shadow shrinks while she jumps
        val sh = 1f - jump / 18f
        dOval(cv, 50f - 20f * sh, 93.5f, 50f + 20f * sh, 99f, col("#000000", 60))

        // legs + shoes
        val step = sin(t * (if (spk) 8f else 3.2f)) * (if (spk || hap) 2.2f else 0.7f)
        for (i in 0..1) {
            val x = if (i == 0) 43.5f else 56.5f
            val off = (if (i == 0) step else -step) - jump * 0.25f
            gPoly(
                cv, lin(x - 3f, 80f, x + 3f, 80f, col("#2A3040"), col("#10131A")),
                x - 3.2f, 80f + bY * 0.4f, x + 3.2f, 80f + bY * 0.4f,
                x + 3.2f + off * 0.2f, 90.5f - jump * 0.5f, x - 3.2f + off * 0.2f, 90.5f - jump * 0.5f
            )
            dOval(cv, x + off * 0.2f - 4.8f, 89.2f - jump * 0.5f, x + off * 0.2f + 4.8f, 94f - jump * 0.5f, col("#0E1016"))
            dOval(cv, x + off * 0.2f - 2.6f, 89.6f - jump * 0.5f, x + off * 0.2f + 1.0f, 90.8f - jump * 0.5f, col("#FFFFFF", 60))
        }

        // pencil skirt, neck, blazer, shirt, lapels, tie, pin
        gPoly(cv, lin(36f, 75f, 64f, 85f, jac0, jac1), 38f, 75f + bY, 62f, 75f + bY, 64f, 85f + bY * 0.5f, 36f, 85f + bY * 0.5f)
        gPoly(cv, lin(44f, 55f, 56f, 62f, skinL, skinD), 44.2f, 55f + bY * 0.6f, 55.8f, 55f + bY * 0.6f, 55f, 62f + bY, 45f, 62f + bY)
        gOval(cv, 35f, 58.5f + bY, 65f, 79f + bY, lin(35f, 58f, 65f, 79f, jac0, jac1))
        gPoly(cv, lin(50f, 59f, 50f, 76f, col("#FFFFFF"), col("#D5DDEA")), 44f, 59.5f + bY, 56f, 59.5f + bY, 50f, 76f + bY)
        dPoly(cv, col("#383F54"), 44f, 59f + bY, 38.5f, 64f + bY, 46.5f, 70f + bY, 46.8f, 62.5f + bY)
        dPoly(cv, col("#383F54"), 56f, 59f + bY, 61.5f, 64f + bY, 53.5f, 70f + bY, 53.2f, 62.5f + bY)
        dPoly(
            cv, col("#0B0E14"),
            50f, 62f + bY, 52.1f, 65f + bY, 51.2f, 74f + bY, 50f, 76.5f + bY, 48.8f, 74f + bY, 47.9f, 65f + bY
        )
        dCircle(cv, 41.5f, 66.5f + bY, 1.1f, col("#FACC15"))

        // left arm: hand on her hip
        val elX = 30.2f + sway * 0.4f
        val elY = 70.5f + bY
        val hdX = 37.8f
        val hdY = 76.2f + bY
        dLine(cv, 37.5f, 63.5f + bY, elX, elY, col("#232938"), 5.4f)
        dLine(cv, elX, elY, hdX, hdY, col("#232938"), 5.0f)
        dCircle(cv, hdX, hdY, 2.6f, skin)

        // braid
        for (i in 0..9) {
            val u = i / 9f
            val x = 64.5f + 5.5f * u + sway * 5.5f * u * u
            val y = 52f + bY + i * 3.55f
            val r = 4.3f - 2.2f * u
            dCircle(cv, x, y, r, if (i % 2 == 0) hairM else hairD)
            dCircle(cv, x - r * 0.3f, y - r * 0.3f, r * 0.35f, col("#EA2F4B", 120))
        }
        dCircle(cv, 64.5f + 5.5f + sway * 5.5f, 52f + bY + 9 * 3.55f + 2.4f, 2.4f, col("#0B0E14"))

        // right arm (waves when she talks, and a lot when tapped)
        val shRx = 62.5f
        val shRy = 63.5f + bY
        val angDeg = if (spk || hap || tap) {
            -24f + sin(t * (if (tap) 14f else 10f)) * (if (tap) 30f else 24f)
        } else {
            78f + sin(t * 2.4f) * 4f
        }
        val ang = angDeg * piF / 180f
        val ex = shRx + 13.5f * cos(ang)
        val ey = shRy + 13.5f * sin(ang)
        dLine(cv, shRx, shRy, ex, ey, col("#232938"), 5.4f)
        dCircle(cv, ex, ey, 2.7f, skin)
        dCircle(cv, shRx + 10.6f * cos(ang), shRy + 10.6f * sin(ang), 2.0f, col("#FFFFFF"))

        // ---- head ----
        cv.save()
        cv.rotate(tilt, 50f, 62f + bY)
        val hy = bY * 0.6f
        gOval(cv, 21.5f - turn * 0.4f, 8.5f + hy, 78.5f - turn * 0.4f, 63f + hy, lin(50f, 8f, 50f, 63f, hairM, hairD))
        gOval(cv, 24.5f + turn * 0.3f, 12f + hy, 75.5f + turn * 0.3f, 64f + hy, rad(45f + turn, 34f + hy, 42f, skinL, skin))
        gOval(
            cv, 33f + turn * 0.3f, 49f + hy, 67f + turn * 0.3f, 63.5f + hy,
            lin(50f, 49f, 50f, 63.5f, col("#F0BFA6", 0), col("#E7A890", 120))
        )
        val sl = sway * 1.4f
        gPoly(cv, lin(24f, 22f, 31f, 60f, hairL, hairD), 23.5f, 33f + hy, 31f, 22f + hy, 33.5f, 48f + hy, 30f + sl * 0.5f, 60f + hy, 24.5f + sl, 54f + hy)
        gPoly(cv, lin(76f, 22f, 69f, 60f, hairL, hairD), 76.5f, 33f + hy, 69f, 22f + hy, 66.5f, 48f + hy, 70f + sl * 0.5f, 60f + hy, 75.5f + sl, 54f + hy)

        // fringe
        val pts = ArrayList<Float>()
        for (k in 0..20) {
            val a = piF + piF * k / 20f
            pts.add(50f + 27.5f * cos(a))
            pts.add(37f + hy + 26.5f * sin(a))
        }
        val edge = floatArrayOf(
            77f, 38f, 73f, 47f, 68f, 34f, 62.5f, 44.5f, 56f, 29.5f, 50f, 26f,
            44f, 30f, 37.5f, 44.5f, 32f, 35f, 27f, 47f, 23f, 38f
        )
        var e = 0
        while (e + 1 < edge.size) {
            pts.add(edge[e])
            pts.add(edge[e + 1] + hy)
            e += 2
        }
        gPolyList(cv, lin(36f, 10f, 60f, 44f, hairL, hairD), pts)
        dOval(cv, 31f, 13.5f + hy, 53f, 19.5f + hy, col("#FF8FA0", 120))
        dOval(cv, 55f, 16f + hy, 66f, 19f + hy, col("#FF8FA0", 80))
        dLine(cv, 50f, 13f + hy, 54f + sway * 1.5f, 5.5f + hy, hairM, 2.2f)

        // eyes: calm half-lidded golden eyes
        val bl = blinkNow()
        val wink = tap && tp > 0.15f && tp < 0.65f
        for (sgn in intArrayOf(-1, 1)) {
            val sg = sgn.toFloat()
            val exx = 50f + sg * 10.5f + turn * 0.7f
            val eyy = 44.5f + hy
            val closed = bl || (wink && sgn == -1) || (hap && !tap)
            if (closed) {
                dArc(cv, exx - 6.2f, eyy - 4f, exx + 6.2f, eyy + 5f, 200f, 140f, col("#2A0A12"), 1.9f)
            } else {
                drawGirlEye(cv, exx, eyy, sg, turn * 0.4f)
            }
            // soft thin brows, the left one a little raised
            if (sgn == -1) {
                dLine(cv, exx - 4.8f, eyy - 9.6f, exx + 4.6f, eyy - 11.4f, col("#7E0A21", 200), 1.0f)
            } else {
                dLine(cv, exx - 4.6f, eyy - 10.4f, exx + 4.8f, eyy - 10.0f, col("#7E0A21", 200), 1.0f)
            }
        }

        // cheeks, nose, mouth
        dCircle(cv, 35.5f + turn * 0.5f, 54.8f + hy, 3.2f, col("#FB7185", 100))
        dCircle(cv, 64.5f + turn * 0.5f, 54.8f + hy, 3.2f, col("#FB7185", 100))
        dCircle(cv, 50f + turn * 0.6f, 51.4f + hy, 0.7f, col("#D4A08C"))
        val my = 57f + hy
        val mx = 50f + turn * 0.6f
        if (spk) {
            val o = 1.2f + 3.2f * amp
            dOval(cv, mx - 3.6f, my - o * 0.4f, mx + 3.6f, my + o, col("#8A1530"))
            dOval(cv, mx - 2.2f, my + o * 0.2f, mx + 2.2f, my + o * 0.95f, col("#FB7185"))
        } else if (lis) {
            dOval(cv, mx - 1.8f, my - 0.4f, mx + 1.8f, my + 2.8f, col("#8A1530"))
        } else if (hap) {
            dArc(cv, mx - 5.5f, my - 3.8f, mx + 5.5f, my + 3.4f, 15f, 150f, col("#8A1530"), 1.6f)
        } else {
            // confident smirk: one corner higher
            dLine(cv, mx - 4.2f, my + 0.8f, mx, my + 1.9f, col("#8A1530"), 1.4f)
            dLine(cv, mx, my + 1.9f, mx + 4.6f, my - 0.9f, col("#8A1530"), 1.4f)
            dLine(cv, mx + 4.6f, my - 0.9f, mx + 5.4f, my - 1.7f, col("#8A1530"), 1.1f)
        }

        // soft blue rim light on the right edge (gives a 3D feel)
        dArc(cv, 23f, 10f + hy, 77f, 64f + hy, -70f, 70f, col("#7DD3FC", 110), 1.3f)
        cv.restore()

        if (lis) {
            val sx = floatArrayOf(20f, 82f, 86f)
            val sy = floatArrayOf(24f, 20f, 36f)
            for (i in 0..2) {
                val a = (120 + 110 * (0.5f + 0.5f * sin(t * 5f + i * 2f))).toInt().coerceIn(0, 255)
                dCircle(cv, sx[i], sy[i], 1.8f, col("#22D3EE", a))
            }
        }
    }

    /** Burst of stars shown when the avatar is tapped */
    private fun drawBurst(cv: Canvas, tp: Float, cy: Float) {
        for (k in 0..6) {
            val ang = (k * 51f + tp * 60f) * piF / 180f
            val r = 26f + 30f * tp
            val x = 50f + r * cos(ang)
            val y = cy + r * sin(ang) * 0.8f
            val a = (255 * (1f - tp)).toInt().coerceIn(0, 255)
            val s = 2.0f + 1.6f * (1f - tp)
            dPoly(
                cv, col("#FDE68A", a),
                x, y - s * 1.7f, x + s * 0.5f, y - s * 0.5f, x + s * 1.7f, y, x + s * 0.5f, y + s * 0.5f,
                x, y + s * 1.7f, x - s * 0.5f, y + s * 0.5f, x - s * 1.7f, y, x - s * 0.5f, y - s * 0.5f
            )
        }
    }

    /** Sitting orange kitten with body, tail, paws, collar and bell */
    private fun drawCatFull(cv: Canvas, t: Float, state: String, amp: Float) {
        val tapNow = tapP >= 0f
        val st = if (tapNow) "happy" else state
        val spk = st == "speaking"
        val lis = st == "listening"
        val hap = st == "happy"
        var bob = sin(t * (if (spk) 8f else 2.2f)) * (if (spk) 1.2f else 0.9f)
        if (hap) bob = -abs(sin(t * 6f)) * 3.5f
        if (tapNow) bob = -sin(tapP * piF) * 8f
        val tail = sin(t * (if (hap || spk) 6f else 2.0f))
        val org = col("#F59E0B")
        val orgL = col("#FDBA74")
        val orgD = col("#D97706")
        val cream = col("#FFF3DC")
        val dk = col("#1F2937")

        dOval(cv, 26f, 93.5f, 74f, 99f, col("#000000", 55))

        // tail
        val n = 12
        for (i in 0..n) {
            val u = i / n.toFloat()
            val x = 68f + 17f * sin(u * 1.7f) + tail * 6.5f * u * u
            val y = 82f - 30f * u
            dCircle(cv, x, y, 4.2f - 1.5f * u, if (i < n) org else cream)
        }

        // hind feet, body, belly, stripes
        dOval(cv, 26f, 83f, 44f, 92f, org)
        dOval(cv, 56f, 83f, 74f, 92f, org)
        dOval(cv, 31f, 60f + bob, 69f, 89f + bob * 0.5f, org)
        dOval(cv, 38.5f, 68f + bob, 61.5f, 89f + bob * 0.5f, cream)
        for (dy in floatArrayOf(0f, 5f, 10f)) {
            dLine(cv, 32.5f, 66f + dy + bob, 37f, 67.2f + dy + bob, orgD, 1.8f)
            dLine(cv, 67.5f, 66f + dy + bob, 63f, 67.2f + dy + bob, orgD, 1.8f)
        }

        // front legs and paws
        val pw = if (spk || hap) sin(t * 9f) * 2.2f else 0f
        dOval(cv, 36.5f, 78f + bob, 46.5f, 92f, org)
        dOval(cv, 53.5f, 78f + bob, 63.5f, 92f, org)
        dOval(cv, 35.5f, 88f, 47.5f, 94f, cream)
        dOval(cv, 52.5f, 88f - pw * 0.4f, 64.5f, 94f - pw * 0.4f, cream)
        dLine(cv, 39.5f, 90.2f, 39.5f, 92.6f, orgL, 0.8f)
        dLine(cv, 43.5f, 90.2f, 43.5f, 92.6f, orgL, 0.8f)
        dLine(cv, 56.5f, 90.2f - pw * 0.4f, 56.5f, 92.6f - pw * 0.4f, orgL, 0.8f)
        dLine(cv, 60.5f, 90.2f - pw * 0.4f, 60.5f, 92.6f - pw * 0.4f, orgL, 0.8f)

        // head
        val hy = bob * 0.7f
        val tw = maxOf(0f, sin(t * 1.3f)) * 2.2f
        for (sgn in intArrayOf(-1, 1)) {
            val sg = sgn.toFloat()
            val twS = if (sgn == 1) tw else 0f
            dPoly(cv, org, 50f + sg * 26f, 34f + hy, 50f + sg * (24f + twS), 9f + hy + twS * 0.6f, 50f + sg * 9f, 22f + hy)
            dPoly(cv, col("#FBB6CE"), 50f + sg * 22f, 29f + hy, 50f + sg * 21f, 14.5f + hy, 50f + sg * 12f, 23f + hy)
        }
        dOval(cv, 23f, 19f + hy, 77f, 63f + hy, org)
        dOval(cv, 28f, 22f + hy, 60f, 40f + hy, col("#FFFFFF", 35))
        dLine(cv, 50f, 20f + hy, 50f, 29f + hy, orgD, 1.7f)
        dLine(cv, 44f, 21f + hy, 44.6f, 28f + hy, orgD, 1.7f)
        dLine(cv, 56f, 21f + hy, 55.4f, 28f + hy, orgD, 1.7f)
        dOval(cv, 38f, 40f + hy, 62f, 62f + hy, cream)

        val bl = blinkNow()
        for (sgn in intArrayOf(-1, 1)) {
            val sg = sgn.toFloat()
            val ex = 50f + sg * 14.2f
            val ey = 42f + hy
            if (bl || hap) {
                dArc(cv, ex - 5.2f, ey - 3.6f, ex + 5.2f, ey + 4.4f, 200f, 140f, dk, 1.8f)
            } else {
                dOval(cv, ex - 4.9f, ey - 6.0f, ex + 4.9f, ey + 6.0f, dk)
                dCircle(cv, ex - 1.6f, ey - 2.4f, 1.9f, col("#FFFFFF"))
                dCircle(cv, ex + 1.4f, ey + 2.2f, 0.95f, col("#FFFFFF"))
            }
        }
        dCircle(cv, 31f, 51.5f + hy, 3.5f, col("#FB7185", 125))
        dCircle(cv, 69f, 51.5f + hy, 3.5f, col("#FB7185", 125))
        dPoly(cv, col("#FB7185"), 47.8f, 47f + hy, 52.2f, 47f + hy, 50f, 50.2f + hy)
        val my = 51.5f + hy
        if (spk) {
            val o = 1.2f + 3.2f * amp
            dOval(cv, 46.6f, my, 53.4f, my + o + 1.2f, col("#9F1239"))
        } else if (lis) {
            dOval(cv, 48.6f, my + 0.4f, 51.4f, my + 3.2f, col("#9F1239"))
        } else {
            dArc(cv, 44.6f, my - 1.5f, 50f, my + 2.6f, 10f, 150f, col("#7C2D12"), 1.2f)
            dArc(cv, 50f, my - 1.5f, 55.4f, my + 2.6f, 20f, 150f, col("#7C2D12"), 1.2f)
        }
        val wh = col("#FFFFFF", 230)
        for (sgn in intArrayOf(-1, 1)) {
            val sg = sgn.toFloat()
            dLine(cv, 50f + sg * 18f, 49f + hy, 50f + sg * 34.5f, 45f + hy, wh, 0.9f)
            dLine(cv, 50f + sg * 18f, 52f + hy, 50f + sg * 34.5f, 52f + hy, wh, 0.9f)
            dLine(cv, 50f + sg * 18f, 55f + hy, 50f + sg * 34.5f, 59f + hy, wh, 0.9f)
        }
        dLine(cv, 37f, 62.2f + hy, 63f, 62.2f + hy, col("#EF4444"), 3.4f)
        dCircle(cv, 50f, 65.8f + hy, 2.7f, col("#FACC15"))
        dCircle(cv, 49.2f, 65f + hy, 0.8f, col("#FEF3C7"))
    }

    /** Chubby white ghost with a pink bow, rosy cheeks and little waving arms */
    private fun drawGhostFull(cv: Canvas, t: Float, state: String, amp: Float) {
        val tapNow = tapP >= 0f
        val st = if (tapNow) "happy" else state
        val spk = st == "speaking"
        val lis = st == "listening"
        val hap = st == "happy"
        var fl = sin(t * (if (spk) 5f else 2.0f)) * (if (spk) 2.4f else 2.8f)
        if (hap) fl = -abs(sin(t * 6f)) * 5f
        if (tapNow) fl = -sin(tapP * piF) * 9f

        dOval(cv, 50f - (14f - fl * 0.5f), 93f, 50f + (14f - fl * 0.5f), 98.5f, col("#000000", 50))

        for (pass in 0..1) {
            val grow = if (pass == 0) 1.6f else 0f
            val color = if (pass == 0) col("#D8D0FF") else col("#FFFFFF")
            val cy = 44f + fl
            val pts = ArrayList<Float>()
            for (k in 0..24) {
                val a = piF + piF * k / 24f
                pts.add(50f + (28f + grow) * cos(a))
                pts.add(cy + (30f + grow) * sin(a))
            }
            pts.add(78f + grow); pts.add(cy)
            pts.add(77.5f + grow); pts.add(74f + fl)
            for (i in 0..32) {
                val u = i / 32f
                pts.add(77.5f - 55f * u)
                pts.add(79f + fl + 5.2f * abs(sin(u * 4f * piF)) + grow + sin(t * 3f + u * 8f) * 0.8f)
            }
            pts.add(22.5f - grow); pts.add(74f + fl)
            pts.add(22f - grow); pts.add(cy)
            dPolyList(cv, color, pts)
        }
        dOval(cv, 26f, 62f + fl, 74f, 86f + fl, col("#E6E0FF", 120))

        // arms
        val wv = sin(t * (if (spk || hap) 9f else 2.6f)) * (if (spk || hap) 22f else 9f)
        cv.save()
        cv.rotate(-25f - wv * 0.6f, 24f, 56f + fl)
        dOval(cv, 13f, 52.6f + fl, 24f, 59.4f + fl, col("#FFFFFF"))
        cv.restore()
        cv.save()
        cv.rotate(25f + wv, 76f, 56f + fl)
        dOval(cv, 76f, 52.6f + fl, 87f, 59.4f + fl, col("#FFFFFF"))
        cv.restore()

        // bow
        cv.save()
        cv.rotate(-18f, 36f, 18f + fl)
        dPoly(cv, col("#FB7185"), 36f, 18f + fl, 26.5f, 12f + fl, 26.5f, 24f + fl)
        dPoly(cv, col("#FB7185"), 36f, 18f + fl, 45.5f, 12f + fl, 45.5f, 24f + fl)
        dCircle(cv, 36f, 18f + fl, 3f, col("#E11D48"))
        cv.restore()

        val bl = blinkNow()
        for (sgn in intArrayOf(-1, 1)) {
            val sg = sgn.toFloat()
            val ex = 50f + sg * 11.5f
            val ey = 44f + fl
            if (bl || hap) {
                dArc(cv, ex - 5.4f, ey - 3.8f, ex + 5.4f, ey + 4.6f, 200f, 140f, col("#1F2937"), 1.8f)
            } else {
                dOval(cv, ex - 5.0f, ey - 6.6f, ex + 5.0f, ey + 6.6f, col("#1F2937"))
                dCircle(cv, ex - 1.7f, ey - 2.6f, 2.1f, col("#FFFFFF"))
                dCircle(cv, ex + 1.6f, ey + 2.6f, 1.0f, col("#FFFFFF"))
            }
        }
        dOval(cv, 26.5f, 51f + fl, 36.5f, 56.5f + fl, col("#FB7185", 150))
        dOval(cv, 63.5f, 51f + fl, 73.5f, 56.5f + fl, col("#FB7185", 150))
        val my = 54.5f + fl
        if (spk) {
            val o = 1.2f + 3.4f * amp
            dOval(cv, 46.2f, my - o * 0.3f, 53.8f, my + o, col("#4B1D3F"))
            dOval(cv, 47.8f, my + o * 0.35f, 52.2f, my + o * 0.95f, col("#FB7185"))
        } else if (lis) {
            dOval(cv, 48.3f, my, 51.7f, my + 3.2f, col("#4B1D3F"))
        } else if (hap) {
            dArc(cv, 45.5f, my - 3.5f, 54.5f, my + 3.2f, 20f, 140f, col("#4B1D3F"), 1.5f)
        } else {
            dArc(cv, 46.5f, my - 2.5f, 53.5f, my + 2f, 25f, 130f, col("#4B1D3F"), 1.4f)
        }

        // twinkling sparkles
        val gx = floatArrayOf(14f, 86f, 80f)
        val gy = floatArrayOf(26f, 32f, 10f)
        for (i in 0..2) {
            val a = (90 + 160 * (0.5f + 0.5f * sin(t * 3f + i * 2f))).toInt().coerceIn(0, 255)
            val r = 2.4f + 0.9f * sin(t * 3f + i * 2f)
            val x = gx[i]
            val y = gy[i]
            dPoly(
                cv, col("#FDE68A", a),
                x, y - r * 1.7f, x + r * 0.5f, y - r * 0.5f, x + r * 1.7f, y, x + r * 0.5f, y + r * 0.5f,
                x, y + r * 1.7f, x - r * 0.5f, y + r * 0.5f, x - r * 1.7f, y, x - r * 0.5f, y - r * 0.5f
            )
        }
    }

    private fun drawEars(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        for (side in intArrayOf(-1, 1)) {
            val s = side.toFloat()
            facePath.reset()
            facePath.moveTo(cx + s * r * 0.82f, cy - r * 0.30f)
            facePath.lineTo(cx + s * r * 0.66f, cy - r * 1.12f)
            facePath.lineTo(cx + s * r * 0.15f, cy - r * 0.86f)
            facePath.close()
            canvas.drawPath(facePath, earPaint)

            facePath.reset()
            facePath.moveTo(cx + s * r * 0.68f, cy - r * 0.50f)
            facePath.lineTo(cx + s * r * 0.60f, cy - r * 0.92f)
            facePath.lineTo(cx + s * r * 0.30f, cy - r * 0.76f)
            facePath.close()
            canvas.drawPath(facePath, earInnerPaint)
        }
    }

    private fun drawFace(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        val now = System.currentTimeMillis()
        val blinking = (now % 3400L) < 150L
        val eyeDx = r * 0.36f
        val eyeY = cy - r * 0.08f
        val eyeW = r * 0.17f
        var eyeH = r * 0.24f
        if (currentState == "happy") eyeH = r * 0.16f
        if (blinking) eyeH = r * 0.04f

        // Eyes look up a bit while thinking
        val lookY = if (currentState == "thinking") -r * 0.06f else 0f
        val lookX = if (currentState == "thinking") r * 0.04f else 0f

        for (side in intArrayOf(-1, 1)) {
            val ex = cx + side * eyeDx
            canvas.drawOval(RectF(ex - eyeW, eyeY - eyeH, ex + eyeW, eyeY + eyeH), eyePaint)
            if (!blinking) {
                canvas.drawCircle(ex + lookX, eyeY + lookY + eyeH * 0.1f, eyeW * 0.55f, pupilPaint)
                canvas.drawCircle(ex + lookX - eyeW * 0.2f, eyeY + lookY - eyeH * 0.15f, eyeW * 0.2f, eyePaint)
            }
        }

        // Blush
        canvas.drawCircle(cx - r * 0.62f, cy + r * 0.24f, r * 0.14f, blushPaint)
        canvas.drawCircle(cx + r * 0.62f, cy + r * 0.24f, r * 0.14f, blushPaint)

        // Mouth
        val my = cy + r * 0.38f
        when (currentState) {
            "speaking" -> {
                val open = r * (0.08f + 0.30f * audioAmplitude.coerceIn(0f, 1f))
                canvas.drawOval(RectF(cx - r * 0.16f, my - open * 0.4f, cx + r * 0.16f, my + open), mouthFillPaint)
            }
            "listening" -> {
                canvas.drawOval(RectF(cx - r * 0.09f, my - r * 0.02f, cx + r * 0.09f, my + r * 0.16f), mouthFillPaint)
            }
            "error" -> {
                val rect = RectF(cx - r * 0.16f, my, cx + r * 0.16f, my + r * 0.22f)
                canvas.drawArc(rect, 200f, 140f, false, mouthLinePaint)
            }
            "happy" -> {
                val rect = RectF(cx - r * 0.24f, my - r * 0.14f, cx + r * 0.24f, my + r * 0.20f)
                canvas.drawArc(rect, 20f, 140f, false, mouthLinePaint)
            }
            else -> {
                val rect = RectF(cx - r * 0.17f, my - r * 0.10f, cx + r * 0.17f, my + r * 0.12f)
                canvas.drawArc(rect, 25f, 130f, false, mouthLinePaint)
            }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        orbitAnimator.cancel()
        breathAnimator.cancel()
    }
}
