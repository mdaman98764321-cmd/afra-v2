package com.afra.assistant.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import java.io.File
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat

/**
 * Custom Android View for the 56dp Floating Avatar Overlay with hardware-accelerated
 * Canvas drawing, state glow animations, and explicit microphone status indicator.
 */
class AfraOverlayView(context: Context) : View(context) {

    private var currentState = "idle"
    private var audioAmplitude = 0f
    private var isPressedScale = false
    private var showMicIndicator = false

    // Color definitions
    private val colorViolet = Color.parseColor("#8B5CF6")
    private val colorCyan = Color.parseColor("#06B6D4")
    private val colorEmerald = Color.parseColor("#10B981")
    private val colorRose = Color.parseColor("#F43F5E")
    private val colorBgDark = Color.parseColor("#0B0D10")
    private val colorBorder = Color.parseColor("#334155")

    // Cute-face paints
    private val earPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#7C3AED") }
    private val earInnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#F9A8D4") }
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val pupilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#1E1B4B") }
    private val blushPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#FB7185"); alpha = 110 }
    private val mouthLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2f * resources.displayMetrics.density
    }
    private val mouthFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#4C1D95") }
    private val facePath = Path()
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var avatarBitmap: Bitmap? = null

    init {
        reloadAvatar()
    }

    /** Loads the picture the user chose in the app (if any). */
    fun reloadAvatar() {
        avatarBitmap = try {
            val f = File(context.filesDir, AfraOverlayService.AVATAR_FILE)
            if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
        } catch (e: Exception) {
            null
        }
        invalidate()
    }

    // Paints
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * resources.displayMetrics.density
        color = colorBorder
    }

    private val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
        color = colorViolet
    }

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = colorBgDark
    }

    private val micBadgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = colorCyan
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = 14f * resources.displayMetrics.density
    }

    // Animators
    private var orbitAngle = 0f
    private var breathFraction = 0f
    private val orbitAnimator: ValueAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 1600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            orbitAngle = it.animatedValue as Float
            invalidate()
        }
    }

    private val breathAnimator: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener {
            breathFraction = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        breathAnimator.start()
    }

    fun setAnimationState(state: String, level: Float = 0f) {
        currentState = state.lowercase()
        audioAmplitude = level

        if (currentState == "thinking" && !orbitAnimator.isRunning) {
            orbitAnimator.start()
        } else if (currentState != "thinking" && orbitAnimator.isRunning) {
            orbitAnimator.cancel()
        }

        invalidate()
    }

    fun setPressedScale(pressed: Boolean) {
        isPressedScale = pressed
        invalidate()
    }

    fun showMicrophoneIndicator(show: Boolean) {
        showMicIndicator = show
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = (width.coerceAtMost(height) / 2f) - (8f * resources.displayMetrics.density)

        // Scale factor for press/speech feedback
        val scale = when {
            isPressedScale -> 0.92f
            currentState == "speaking" -> 1f + (audioAmplitude * 0.12f)
            currentState == "happy" -> 1.06f
            else -> 1f + (breathFraction * 0.03f)
        }

        canvas.save()
        canvas.scale(scale, scale, cx, cy)

        // 1. Draw dynamic state glow halo
        val glowColor = when (currentState) {
            "listening" -> colorCyan
            "thinking" -> colorViolet
            "speaking" -> colorCyan
            "happy" -> colorEmerald
            "error" -> colorRose
            else -> colorViolet
        }

        val glowRadius = baseRadius + (6f * resources.displayMetrics.density) + (audioAmplitude * 10f)
        haloPaint.shader = RadialGradient(
            cx, cy, glowRadius,
            glowColor,
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        haloPaint.alpha = when (currentState) {
            "listening" -> 160
            "speaking" -> 180
            "thinking" -> 140
            "happy" -> 150
            "error" -> 170
            else -> 90
        }
        canvas.drawCircle(cx, cy, glowRadius, haloPaint)

        // 1b. Little cat ears (only for the default character)
        if (avatarBitmap == null) drawEars(canvas, cx, cy, baseRadius)

        // 2. Draw core avatar circle (soft purple ball)
        corePaint.shader = RadialGradient(
            cx, cy - baseRadius * 0.35f, baseRadius * 1.4f,
            Color.parseColor("#C4B5FD"), Color.parseColor("#6D28D9"),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, baseRadius, corePaint)

        // 2b. The user's own picture, cropped round
        val bmp = avatarBitmap
        if (bmp != null) {
            facePath.reset()
            facePath.addCircle(cx, cy, baseRadius - 2f, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(facePath)
            canvas.drawBitmap(
                bmp,
                Rect(0, 0, bmp.width, bmp.height),
                RectF(cx - baseRadius, cy - baseRadius, cx + baseRadius, cy + baseRadius),
                bitmapPaint
            )
            canvas.restore()
        }

        // 3. Draw state specific animations
        when (currentState) {
            "thinking" -> {
                // Orbiting ring
                val orbitRadius = baseRadius + (3f * resources.displayMetrics.density)
                val rect = RectF(
                    cx - orbitRadius, cy - orbitRadius,
                    cx + orbitRadius, cy + orbitRadius
                )
                canvas.drawArc(rect, orbitAngle, 100f, false, orbitPaint)
            }
            "listening" -> {
                // Sound wave ring
                val pulseRadius = baseRadius + (audioAmplitude * 8f * resources.displayMetrics.density)
                borderPaint.color = colorCyan
                canvas.drawCircle(cx, cy, pulseRadius, borderPaint)
            }
        }

        // 4. Central Monogram / Avatar Graphic
        borderPaint.color = when (currentState) {
            "listening" -> colorCyan
            "speaking" -> colorViolet
            "happy" -> colorEmerald
            "error" -> colorRose
            else -> colorBorder
        }
        canvas.drawCircle(cx, cy, baseRadius, borderPaint)

        if (avatarBitmap == null) drawFace(canvas, cx, cy, baseRadius)

        // 5. Microphone Privacy Badge (Top Right)
        if (showMicIndicator || currentState == "listening") {
            val badgeRadius = 5f * resources.displayMetrics.density
            val badgeX = cx + (baseRadius * 0.7f)
            val badgeY = cy - (baseRadius * 0.7f)
            canvas.drawCircle(badgeX, badgeY, badgeRadius, micBadgePaint)
        }

        canvas.restore()
    }

    private fun drawEars(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        for (side in intArrayOf(-1, 1)) {
            val s = side.toFloat()
            facePath.reset()
            facePath.moveTo(cx + s * r * 0.82f, cy - r * 0.30f)
            facePath.lineTo(cx + s * r * 0.66f, cy - r * 1.12f)
            facePath.lineTo(cx + s * r * 0.15f, cy - r * 0.86f)
            facePath.close()
            canvas.drawPath(facePath, earPaint)

            facePath.reset()
            facePath.moveTo(cx + s * r * 0.68f, cy - r * 0.50f)
            facePath.lineTo(cx + s * r * 0.60f, cy - r * 0.92f)
            facePath.lineTo(cx + s * r * 0.30f, cy - r * 0.76f)
            facePath.close()
            canvas.drawPath(facePath, earInnerPaint)
        }
    }

    private fun drawFace(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        val now = System.currentTimeMillis()
        val blinking = (now % 3400L) < 150L
        val eyeDx = r * 0.36f
        val eyeY = cy - r * 0.08f
        val eyeW = r * 0.17f
        var eyeH = r * 0.24f
        if (currentState == "happy") eyeH = r * 0.16f
        if (blinking) eyeH = r * 0.04f

        // Eyes look up a bit while thinking
        val lookY = if (currentState == "thinking") -r * 0.06f else 0f
        val lookX = if (currentState == "thinking") r * 0.04f else 0f

        for (side in intArrayOf(-1, 1)) {
            val ex = cx + side * eyeDx
            canvas.drawOval(RectF(ex - eyeW, eyeY - eyeH, ex + eyeW, eyeY + eyeH), eyePaint)
            if (!blinking) {
                canvas.drawCircle(ex + lookX, eyeY + lookY + eyeH * 0.1f, eyeW * 0.55f, pupilPaint)
                canvas.drawCircle(ex + lookX - eyeW * 0.2f, eyeY + lookY - eyeH * 0.15f, eyeW * 0.2f, eyePaint)
            }
        }

        // Blush
        canvas.drawCircle(cx - r * 0.62f, cy + r * 0.24f, r * 0.14f, blushPaint)
        canvas.drawCircle(cx + r * 0.62f, cy + r * 0.24f, r * 0.14f, blushPaint)

        // Mouth
        val my = cy + r * 0.38f
        when (currentState) {
            "speaking" -> {
                val open = r * (0.08f + 0.30f * audioAmplitude.coerceIn(0f, 1f))
                canvas.drawOval(RectF(cx - r * 0.16f, my - open * 0.4f, cx + r * 0.16f, my + open), mouthFillPaint)
            }
            "listening" -> {
                canvas.drawOval(RectF(cx - r * 0.09f, my - r * 0.02f, cx + r * 0.09f, my + r * 0.16f), mouthFillPaint)
            }
            "error" -> {
                val rect = RectF(cx - r * 0.16f, my, cx + r * 0.16f, my + r * 0.22f)
                canvas.drawArc(rect, 200f, 140f, false, mouthLinePaint)
            }
            "happy" -> {
                val rect = RectF(cx - r * 0.24f, my - r * 0.14f, cx + r * 0.24f, my + r * 0.20f)
                canvas.drawArc(rect, 20f, 140f, false, mouthLinePaint)
            }
            else -> {
                val rect = RectF(cx - r * 0.17f, my - r * 0.10f, cx + r * 0.17f, my + r * 0.12f)
                canvas.drawArc(rect, 25f, 130f, false, mouthLinePaint)
            }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        orbitAnimator.cancel()
        breathAnimator.cancel()
    }
}
