package com.afra.assistant.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat

/**
 * Custom Android View for the 56dp Floating Avatar Overlay with hardware-accelerated
 * Canvas drawing, state glow animations, and explicit microphone status indicator.
 */
class AfraOverlayView(context: Context) : View(context) {

    private var currentState = "idle"
    private var audioAmplitude = 0f
    private var isPressedScale = false
    private var showMicIndicator = false

    // Color definitions
    private val colorViolet = Color.parseColor("#8B5CF6")
    private val colorCyan = Color.parseColor("#06B6D4")
    private val colorEmerald = Color.parseColor("#10B981")
    private val colorRose = Color.parseColor("#F43F5E")
    private val colorBgDark = Color.parseColor("#0B0D10")
    private val colorBorder = Color.parseColor("#334155")

    // Cute-face paints
    private val earPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#7C3AED") }
    private val earInnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#F9A8D4") }
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val pupilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#1E1B4B") }
    private val blushPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#FB7185"); alpha = 110 }
    private val mouthLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2f * resources.displayMetrics.density
    }
    private val mouthFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#4C1D95") }
    private val facePath = Path()
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var avatarBitmap: Bitmap? = null

    private var character: String = "afra"

    init {
        reloadAvatar()
    }

    /** Re-reads which character the user picked (and their own picture, if they chose it). */
    fun reloadAvatar() {
        val prefs = context.getSharedPreferences(AfraOverlayService.PREFS_NAME, Context.MODE_PRIVATE)
        character = prefs.getString("character", "afra") ?: "afra"
        avatarBitmap = null
        if (character == "photo") {
            avatarBitmap = try {
                val f = File(context.filesDir, AfraOverlayService.AVATAR_FILE)
                if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
            } catch (e: Exception) {
                null
            }
            if (avatarBitmap == null) character = "afra"
        }
        invalidate()
    }

    // Paints
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * resources.displayMetrics.density
        color = colorBorder
    }

    private val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
        color = colorViolet
    }

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = colorBgDark
    }

    private val micBadgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = colorCyan
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = 14f * resources.displayMetrics.density
    }

    // Animators
    private var orbitAngle = 0f
    private var breathFraction = 0f
    private val orbitAnimator: ValueAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 1600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            orbitAngle = it.animatedValue as Float
            invalidate()
        }
    }

    private val breathAnimator: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener {
            breathFraction = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        breathAnimator.start()
    }

    fun setAnimationState(state: String, level: Float = 0f) {
        currentState = state.lowercase()
        audioAmplitude = level

        if (currentState == "thinking" && !orbitAnimator.isRunning) {
            orbitAnimator.start()
        } else if (currentState != "thinking" && orbitAnimator.isRunning) {
            orbitAnimator.cancel()
        }

        invalidate()
    }

    fun setPressedScale(pressed: Boolean) {
        isPressedScale = pressed
        invalidate()
    }

    fun showMicrophoneIndicator(show: Boolean) {
        showMicIndicator = show
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (character == "cat" || character == "girl" || character == "ghost") {
            drawStyled(canvas)
            return
        }
        super.onDraw(canvas)

        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = (width.coerceAtMost(height) / 2f) - (8f * resources.displayMetrics.density)

        // Scale factor for press/speech feedback
        val scale = when {
            isPressedScale -> 0.92f
            currentState == "speaking" -> 1f + (audioAmplitude * 0.12f)
            currentState == "happy" -> 1.06f
            else -> 1f + (breathFraction * 0.03f)
        }

        canvas.save()
        canvas.scale(scale, scale, cx, cy)

        // 1. Draw dynamic state glow halo
        val glowColor = when (currentState) {
            "listening" -> colorCyan
            "thinking" -> colorViolet
            "speaking" -> colorCyan
            "happy" -> colorEmerald
            "error" -> colorRose
            else -> colorViolet
        }

        val glowRadius = baseRadius + (6f * resources.displayMetrics.density) + (audioAmplitude * 10f)
        haloPaint.shader = RadialGradient(
            cx, cy, glowRadius,
            glowColor,
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        haloPaint.alpha = when (currentState) {
            "listening" -> 160
            "speaking" -> 180
            "thinking" -> 140
            "happy" -> 150
            "error" -> 170
            else -> 90
        }
        canvas.drawCircle(cx, cy, glowRadius, haloPaint)

        when (character) {
            else -> {
        // 1b. Little cat ears (only for the default character)
        if (avatarBitmap == null) drawEars(canvas, cx, cy, baseRadius)

        // 2. Draw core avatar circle (soft purple ball)
        corePaint.shader = RadialGradient(
            cx, cy - baseRadius * 0.35f, baseRadius * 1.4f,
            Color.parseColor("#C4B5FD"), Color.parseColor("#6D28D9"),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, baseRadius, corePaint)

        // 2b. The user's own picture, cropped round
        val bmp = avatarBitmap
        if (bmp != null) {
            facePath.reset()
            facePath.addCircle(cx, cy, baseRadius - 2f, Path.Direction.CW)
            canvas.save()
            canvas.clipPath(facePath)
            canvas.drawBitmap(
                bmp,
                Rect(0, 0, bmp.width, bmp.height),
                RectF(cx - baseRadius, cy - baseRadius, cx + baseRadius, cy + baseRadius),
                bitmapPaint
            )
            canvas.restore()
        }

            }
        }

        // 3. Draw state specific animations
        when (currentState) {
            "thinking" -> {
                // Orbiting ring
                val orbitRadius = baseRadius + (3f * resources.displayMetrics.density)
                val rect = RectF(
                    cx - orbitRadius, cy - orbitRadius,
                    cx + orbitRadius, cy + orbitRadius
                )
                canvas.drawArc(rect, orbitAngle, 100f, false, orbitPaint)
            }
            "listening" -> {
                // Sound wave ring
                val pulseRadius = baseRadius + (audioAmplitude * 8f * resources.displayMetrics.density)
                borderPaint.color = colorCyan
                canvas.drawCircle(cx, cy, pulseRadius, borderPaint)
            }
        }

        // 4. Central Monogram / Avatar Graphic
        borderPaint.color = when (currentState) {
            "listening" -> colorCyan
            "speaking" -> colorViolet
            "happy" -> colorEmerald
            "error" -> colorRose
            else -> colorBorder
        }
        val roundCharacter = character == "afra" || character == "photo"
        if (roundCharacter || currentState == "listening" || currentState == "speaking" ||
            currentState == "happy" || currentState == "error"
        ) {
            canvas.drawCircle(cx, cy, baseRadius, borderPaint)
        }

        if (character == "afra" && avatarBitmap == null) drawFace(canvas, cx, cy, baseRadius)

        // 5. Microphone Privacy Badge (Top Right)
        if (showMicIndicator || currentState == "listening") {
            val badgeRadius = 5f * resources.displayMetrics.density
            val badgeX = cx + (baseRadius * 0.7f)
            val badgeY = cy - (baseRadius * 0.7f)
            canvas.drawCircle(badgeX, badgeY, badgeRadius, micBadgePaint)
        }

        canvas.restore()
    }

    /* ---------- small helpers for the extra characters ---------- */
    private val pp = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun hex(h: String): Int = Color.parseColor(h)

    private fun fillP(color: Int): Paint {
        pp.reset()
        pp.isAntiAlias = true
        pp.style = Paint.Style.FILL
        pp.color = color
        return pp
    }

    private fun strokeP(color: Int, widthDp: Float): Paint {
        pp.reset()
        pp.isAntiAlias = true
        pp.style = Paint.Style.STROKE
        pp.strokeCap = Paint.Cap.ROUND
        pp.color = color
        pp.strokeWidth = widthDp * resources.displayMetrics.density
        return pp
    }

    private fun blinkNow(): Boolean = (System.currentTimeMillis() % 3400L) < 150L

    private fun drawMouth(canvas: Canvas, cx: Float, my: Float, r: Float, lineColor: Int, fillColor: Int) {
        when (currentState) {
            "speaking" -> {
                val open = r * (0.08f + 0.28f * audioAmplitude.coerceIn(0f, 1f))
                canvas.drawOval(RectF(cx - r * 0.15f, my - open * 0.4f, cx + r * 0.15f, my + open), fillP(fillColor))
            }
            "listening" -> {
                canvas.drawOval(RectF(cx - r * 0.09f, my - r * 0.02f, cx + r * 0.09f, my + r * 0.15f), fillP(fillColor))
            }
            "error" -> {
                canvas.drawArc(RectF(cx - r * 0.15f, my, cx + r * 0.15f, my + r * 0.2f), 200f, 140f, false, strokeP(lineColor, 1.8f))
            }
            "happy" -> {
                canvas.drawArc(RectF(cx - r * 0.22f, my - r * 0.12f, cx + r * 0.22f, my + r * 0.18f), 20f, 140f, false, strokeP(lineColor, 1.8f))
            }
            else -> {
                canvas.drawArc(RectF(cx - r * 0.15f, my - r * 0.08f, cx + r * 0.15f, my + r * 0.1f), 25f, 130f, false, strokeP(lineColor, 1.8f))
            }
        }
    }

    /* ================== full-body characters (drawn in a 100 x 100 design space) ================== */

    private val piF = Math.PI.toFloat()

    private fun col(h: String, a: Int = 255): Int {
        val c = Color.parseColor(h)
        return Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    }

    private fun strokeD(color: Int, w: Float): Paint {
        pp.reset()
        pp.isAntiAlias = true
        pp.style = Paint.Style.STROKE
        pp.strokeCap = Paint.Cap.ROUND
        pp.color = color
        pp.strokeWidth = w
        return pp
    }

    private fun dOval(cv: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int) {
        cv.drawOval(RectF(l, t, r, b), fillP(color))
    }

    private fun dCircle(cv: Canvas, x: Float, y: Float, r: Float, color: Int) {
        cv.drawCircle(x, y, r, fillP(color))
    }

    private fun dLine(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, color: Int, w: Float) {
        cv.drawLine(x1, y1, x2, y2, strokeD(color, w))
    }

    private fun dArc(cv: Canvas, l: Float, t: Float, r: Float, b: Float, start: Float, sweep: Float, color: Int, w: Float) {
        cv.drawArc(RectF(l, t, r, b), start, sweep, false, strokeD(color, w))
    }

    private fun dPoly(cv: Canvas, color: Int, vararg p: Float) {
        facePath.reset()
        facePath.moveTo(p[0], p[1])
        var i = 2
        while (i + 1 < p.size) {
            facePath.lineTo(p[i], p[i + 1])
            i += 2
        }
        facePath.close()
        cv.drawPath(facePath, fillP(color))
    }

    private fun dPolyList(cv: Canvas, color: Int, p: List<Float>) {
        facePath.reset()
        facePath.moveTo(p[0], p[1])
        var i = 2
        while (i + 1 < p.size) {
            facePath.lineTo(p[i], p[i + 1])
            i += 2
        }
        facePath.close()
        cv.drawPath(facePath, fillP(color))
    }

    private fun tSec(): Float = ((System.currentTimeMillis() % 100000L) / 1000f)

    private fun drawStyled(canvas: Canvas) {
        val size = minOf(width, height).toFloat()
        val u = size / 100f
        val t = tSec()
        canvas.save()
        canvas.translate((width - size) / 2f, (height - size) / 2f)
        canvas.scale(u, u)
        when (character) {
            "cat" -> drawCatFull(canvas, t, currentState, audioAmplitude.coerceIn(0f, 1f))
            "girl" -> drawGirlFull(canvas, t, currentState, audioAmplitude.coerceIn(0f, 1f))
            "ghost" -> drawGhostFull(canvas, t, currentState, audioAmplitude.coerceIn(0f, 1f))
        }
        canvas.restore()
        postInvalidateOnAnimation()
    }

    /** Red-haired little office girl (chibi: big head, small body) */
    private fun drawGirlFull(cv: Canvas, t: Float, state: String, amp: Float) {
        val spk = state == "speaking"
        val lis = state == "listening"
        val hap = state == "happy"
        val sway = sin(t * 2.4f)
        var bobY = sin(t * (if (spk) 7.5f else 2.6f)) * (if (spk) 1.3f else 0.9f)
        if (hap) bobY = -abs(sin(t * 6f)) * 4f
        val tilt = sin(t * 1.7f) * 2f + (if (lis) 7f + sin(t * 3f) * 1.5f else 0f)
        val skin = col("#FFE6D5")
        val hair = col("#C8102E")
        val hairD = col("#9B0C24")
        val dark = col("#1F2430")

        dOval(cv, 30f, 93.5f, 70f, 99f, col("#000000", 55))

        // legs
        val step = sin(t * (if (spk) 8f else 3.2f)) * (if (spk || hap) 2.4f else 0.9f)
        for (i in 0..1) {
            val x = if (i == 0) 43.5f else 56.5f
            val off = if (i == 0) step else -step
            dLine(cv, x, 80f + bobY * 0.4f, x + off * 0.4f, 90.5f, dark, 6.0f)
            dOval(cv, x + off * 0.4f - 4.6f, 89.4f, x + off * 0.4f + 4.6f, 94.2f, col("#12151C"))
        }

        // skirt, shirt, collar, tie
        dPoly(cv, dark, 37.5f, 75f + bobY, 62.5f, 75f + bobY, 65.5f, 84f + bobY * 0.5f, 34.5f, 84f + bobY * 0.5f)
        dOval(cv, 36.5f, 58f + bobY, 63.5f, 78f + bobY, col("#F8FAFC"))
        dOval(cv, 38f, 72f + bobY, 62f, 80f + bobY, col("#EEF2F7"))
        dPoly(cv, col("#E5E7EB"), 44.2f, 59.5f + bobY, 50f, 65f + bobY, 45.5f, 67f + bobY)
        dPoly(cv, col("#E5E7EB"), 55.8f, 59.5f + bobY, 50f, 65f + bobY, 54.5f, 67f + bobY)
        dPoly(
            cv, col("#111827"),
            50f, 62.5f + bobY, 52.3f, 65.5f + bobY, 51.4f, 75f + bobY, 50f, 77.5f + bobY, 48.6f, 75f + bobY, 47.7f, 65.5f + bobY
        )

        // arms (the right one waves when she talks or is happy)
        val aL = (106f + sin(t * (if (spk) 7f else 2.4f) + 1f) * (if (spk) 14f else 5f)) * piF / 180f
        var aRdeg = 74f + sin(t * 2.4f) * 5f
        if (spk || hap) aRdeg = -22f + sin(t * 10f) * 26f
        val aR = aRdeg * piF / 180f
        val shLx = 37.5f
        val shRx = 62.5f
        val shY = 63.5f + bobY
        val lx = shLx + 13.5f * cos(aL)
        val ly = shY + 13.5f * sin(aL)
        dLine(cv, shLx, shY, lx, ly, col("#F8FAFC"), 5.8f)
        dCircle(cv, lx, ly, 2.9f, skin)

        // braid swings behind
        for (i in 0..9) {
            val u = i / 9f
            val x = 64.5f + 5.5f * u + sway * 5.5f * u * u
            val y = 52f + bobY + i * 3.55f
            val r = 4.3f - 2.2f * u
            dCircle(cv, x, y, r, if (i % 2 == 0) hair else hairD)
        }
        dCircle(cv, 64.5f + 5.5f + sway * 5.5f, 52f + bobY + 9 * 3.55f + 2.4f, 2.4f, col("#111827"))

        val rx = shRx + 13.5f * cos(aR)
        val ry = shY + 13.5f * sin(aR)
        dLine(cv, shRx, shY, rx, ry, col("#F8FAFC"), 5.8f)
        dCircle(cv, rx, ry, 2.9f, skin)

        // head (tilts)
        cv.save()
        cv.rotate(tilt, 50f, 62f + bobY)
        val hy = bobY * 0.6f
        dOval(cv, 21.5f, 8.5f + hy, 78.5f, 63f + hy, hairD)
        dOval(cv, 24.5f, 12f + hy, 75.5f, 64f + hy, skin)
        val sl = sway * 1.4f
        dPoly(cv, hair, 23.5f, 33f + hy, 31f, 22f + hy, 33.5f, 48f + hy, 30f + sl * 0.5f, 60f + hy, 24.5f + sl, 54f + hy)
        dPoly(cv, hair, 76.5f, 33f + hy, 69f, 22f + hy, 66.5f, 48f + hy, 70f + sl * 0.5f, 60f + hy, 75.5f + sl, 54f + hy)

        // fringe
        val pts = ArrayList<Float>()
        for (k in 0..20) {
            val a = piF + piF * k / 20f
            pts.add(50f + 27.5f * cos(a))
            pts.add(37f + hy + 26.5f * sin(a))
        }
        val edge = floatArrayOf(
            77f, 38f, 73f, 46f, 68f, 35f, 63f, 43.5f, 56f, 30f, 50f, 26.5f,
            44f, 30f, 37f, 43.5f, 32f, 35f, 27f, 46f, 23f, 38f
        )
        var e = 0
        while (e + 1 < edge.size) {
            pts.add(edge[e])
            pts.add(edge[e + 1] + hy)
            e += 2
        }
        dPolyList(cv, hair, pts)
        dOval(cv, 33f, 13.5f + hy, 52f, 19f + hy, col("#F2546A", 110))
        dLine(cv, 50f, 13f + hy, 53f + sway * 1.5f, 6.5f + hy, hair, 2.2f)

        // eyes (golden ringed eyes)
        val bl = blinkNow()
        for (sgn in intArrayOf(-1, 1)) {
            val sg = sgn.toFloat()
            val ex = 50f + sg * 10.5f
            val ey = 44f + hy
            if (bl || hap) {
                dArc(cv, ex - 6.2f, ey - 4f, ex + 6.2f, ey + 5f, 200f, 140f, col("#3B0A14"), 1.7f)
            } else {
                dOval(cv, ex - 6.4f, ey - 7.4f, ex + 6.4f, ey + 7.4f, col("#FFFFFF"))
                dCircle(cv, ex, ey + 0.8f, 5.4f, col("#FACC15"))
                dCircle(cv, ex, ey + 0.8f, 4.0f, col("#F59E0B"))
                dCircle(cv, ex, ey + 0.8f, 3.1f, col("#FACC15"))
                dCircle(cv, ex, ey + 0.8f, 1.8f, col("#3B0A14"))
                dCircle(cv, ex - 1.9f, ey - 2.4f, 1.7f, col("#FFFFFF"))
                dCircle(cv, ex + 1.8f, ey + 3.2f, 0.9f, col("#FFFFFF"))
                dLine(cv, ex + sg * 5.6f, ey - 5.2f, ex + sg * 8.2f, ey - 7.2f, col("#3B0A14"), 1.3f)
            }
            dLine(cv, ex - 4.5f, ey - 10.5f, ex + 4.5f, ey - 10.2f, hairD, 1.3f)
        }

        // cheeks, nose, mouth
        dCircle(cv, 35.5f, 54.5f + hy, 3.4f, col("#FB7185", 120))
        dCircle(cv, 64.5f, 54.5f + hy, 3.4f, col("#FB7185", 120))
        dCircle(cv, 50f, 51f + hy, 0.7f, col("#D4A08C"))
        val my = 56.5f + hy
        if (spk) {
            val o = 1.2f + 3.4f * amp
            dOval(cv, 46.3f, my - o * 0.4f, 53.7f, my + o, col("#8A1530"))
            dOval(cv, 47.8f, my + o * 0.2f, 52.2f, my + o * 0.95f, col("#FB7185"))
        } else if (lis) {
            dOval(cv, 48.2f, my - 0.4f, 51.8f, my + 2.8f, col("#8A1530"))
        } else if (hap) {
            dArc(cv, 45f, my - 3.5f, 55f, my + 3f, 20f, 140f, col("#8A1530"), 1.5f)
        } else {
            dArc(cv, 46f, my - 2.5f, 54f, my + 2f, 25f, 130f, col("#8A1530"), 1.4f)
        }
        cv.restore()

        if (lis) {
            val sx = floatArrayOf(20f, 82f, 86f)
            val sy = floatArrayOf(24f, 20f, 36f)
            for (i in 0..2) {
                val a = (120 + 110 * (0.5f + 0.5f * sin(t * 5f + i * 2f))).toInt().coerceIn(0, 255)
                dCircle(cv, sx[i], sy[i], 1.8f, col("#22D3EE", a))
            }
        }
    }

    /** Sitting orange kitten with body, tail, paws, collar and bell */
    private fun drawCatFull(cv: Canvas, t: Float, state: String, amp: Float) {
        val spk = state == "speaking"
        val lis = state == "listening"
        val hap = state == "happy"
        var bob = sin(t * (if (spk) 8f else 2.2f)) * (if (spk) 1.2f else 0.9f)
        if (hap) bob = -abs(sin(t * 6f)) * 3.5f
        val tail = sin(t * (if (hap || spk) 6f else 2.0f))
        val org = col("#F59E0B")
        val orgL = col("#FDBA74")
        val orgD = col("#D97706")
        val cream = col("#FFF3DC")
        val dk = col("#1F2937")

        dOval(cv, 26f, 93.5f, 74f, 99f, col("#000000", 55))

        // tail
        val n = 12
        for (i in 0..n) {
            val u = i / n.toFloat()
            val x = 68f + 17f * sin(u * 1.7f) + tail * 6.5f * u * u
            val y = 82f - 30f * u
            dCircle(cv, x, y, 4.2f - 1.5f * u, if (i < n) org else cream)
        }

        // hind feet, body, belly, stripes
        dOval(cv, 26f, 83f, 44f, 92f, org)
        dOval(cv, 56f, 83f, 74f, 92f, org)
        dOval(cv, 31f, 60f + bob, 69f, 89f + bob * 0.5f, org)
        dOval(cv, 38.5f, 68f + bob, 61.5f, 89f + bob * 0.5f, cream)
        for (dy in floatArrayOf(0f, 5f, 10f)) {
            dLine(cv, 32.5f, 66f + dy + bob, 37f, 67.2f + dy + bob, orgD, 1.8f)
            dLine(cv, 67.5f, 66f + dy + bob, 63f, 67.2f + dy + bob, orgD, 1.8f)
        }

        // front legs and paws
        val pw = if (spk || hap) sin(t * 9f) * 2.2f else 0f
        dOval(cv, 36.5f, 78f + bob, 46.5f, 92f, org)
        dOval(cv, 53.5f, 78f + bob, 63.5f, 92f, org)
        dOval(cv, 35.5f, 88f, 47.5f, 94f, cream)
        dOval(cv, 52.5f, 88f - pw * 0.4f, 64.5f, 94f - pw * 0.4f, cream)
        dLine(cv, 39.5f, 90.2f, 39.5f, 92.6f, orgL, 0.8f)
        dLine(cv, 43.5f, 90.2f, 43.5f, 92.6f, orgL, 0.8f)
        dLine(cv, 56.5f, 90.2f - pw * 0.4f, 56.5f, 92.6f - pw * 0.4f, orgL, 0.8f)
        dLine(cv, 60.5f, 90.2f - pw * 0.4f, 60.5f, 92.6f - pw * 0.4f, orgL, 0.8f)

        // head
        val hy = bob * 0.7f
        val tw = maxOf(0f, sin(t * 1.3f)) * 2.2f
        for (sgn in intArrayOf(-1, 1)) {
            val sg = sgn.toFloat()
            val twS = if (sgn == 1) tw else 0f
            dPoly(cv, org, 50f + sg * 26f, 34f + hy, 50f + sg * (24f + twS), 9f + hy + twS * 0.6f, 50f + sg * 9f, 22f + hy)
            dPoly(cv, col("#FBB6CE"), 50f + sg * 22f, 29f + hy, 50f + sg * 21f, 14.5f + hy, 50f + sg * 12f, 23f + hy)
        }
        dOval(cv, 23f, 19f + hy, 77f, 63f + hy, org)
        dOval(cv, 28f, 22f + hy, 60f, 40f + hy, col("#FFFFFF", 35))
        dLine(cv, 50f, 20f + hy, 50f, 29f + hy, orgD, 1.7f)
        dLine(cv, 44f, 21f + hy, 44.6f, 28f + hy, orgD, 1.7f)
        dLine(cv, 56f, 21f + hy, 55.4f, 28f + hy, orgD, 1.7f)
        dOval(cv, 38f, 40f + hy, 62f, 62f + hy, cream)

        val bl = blinkNow()
        for (sgn in intArrayOf(-1, 1)) {
            val sg = sgn.toFloat()
            val ex = 50f + sg * 14.2f
            val ey = 42f + hy
            if (bl || hap) {
                dArc(cv, ex - 5.2f, ey - 3.6f, ex + 5.2f, ey + 4.4f, 200f, 140f, dk, 1.8f)
            } else {
                dOval(cv, ex - 4.9f, ey - 6.0f, ex + 4.9f, ey + 6.0f, dk)
                dCircle(cv, ex - 1.6f, ey - 2.4f, 1.9f, col("#FFFFFF"))
                dCircle(cv, ex + 1.4f, ey + 2.2f, 0.95f, col("#FFFFFF"))
            }
        }
        dCircle(cv, 31f, 51.5f + hy, 3.5f, col("#FB7185", 125))
        dCircle(cv, 69f, 51.5f + hy, 3.5f, col("#FB7185", 125))
        dPoly(cv, col("#FB7185"), 47.8f, 47f + hy, 52.2f, 47f + hy, 50f, 50.2f + hy)
        val my = 51.5f + hy
        if (spk) {
            val o = 1.2f + 3.2f * amp
            dOval(cv, 46.6f, my, 53.4f, my + o + 1.2f, col("#9F1239"))
        } else if (lis) {
            dOval(cv, 48.6f, my + 0.4f, 51.4f, my + 3.2f, col("#9F1239"))
        } else {
            dArc(cv, 44.6f, my - 1.5f, 50f, my + 2.6f, 10f, 150f, col("#7C2D12"), 1.2f)
            dArc(cv, 50f, my - 1.5f, 55.4f, my + 2.6f, 20f, 150f, col("#7C2D12"), 1.2f)
        }
        val wh = col("#FFFFFF", 230)
        for (sgn in intArrayOf(-1, 1)) {
            val sg = sgn.toFloat()
            dLine(cv, 50f + sg * 18f, 49f + hy, 50f + sg * 34.5f, 45f + hy, wh, 0.9f)
            dLine(cv, 50f + sg * 18f, 52f + hy, 50f + sg * 34.5f, 52f + hy, wh, 0.9f)
            dLine(cv, 50f + sg * 18f, 55f + hy, 50f + sg * 34.5f, 59f + hy, wh, 0.9f)
        }
        dLine(cv, 37f, 62.2f + hy, 63f, 62.2f + hy, col("#EF4444"), 3.4f)
        dCircle(cv, 50f, 65.8f + hy, 2.7f, col("#FACC15"))
        dCircle(cv, 49.2f, 65f + hy, 0.8f, col("#FEF3C7"))
    }

    /** Chubby white ghost with a pink bow, rosy cheeks and little waving arms */
    private fun drawGhostFull(cv: Canvas, t: Float, state: String, amp: Float) {
        val spk = state == "speaking"
        val lis = state == "listening"
        val hap = state == "happy"
        var fl = sin(t * (if (spk) 5f else 2.0f)) * (if (spk) 2.4f else 2.8f)
        if (hap) fl = -abs(sin(t * 6f)) * 5f

        dOval(cv, 50f - (14f - fl * 0.5f), 93f, 50f + (14f - fl * 0.5f), 98.5f, col("#000000", 50))

        for (pass in 0..1) {
            val grow = if (pass == 0) 1.6f else 0f
            val color = if (pass == 0) col("#D8D0FF") else col("#FFFFFF")
            val cy = 44f + fl
            val pts = ArrayList<Float>()
            for (k in 0..24) {
                val a = piF + piF * k / 24f
                pts.add(50f + (28f + grow) * cos(a))
                pts.add(cy + (30f + grow) * sin(a))
            }
            pts.add(78f + grow); pts.add(cy)
            pts.add(77.5f + grow); pts.add(74f + fl)
            for (i in 0..32) {
                val u = i / 32f
                pts.add(77.5f - 55f * u)
                pts.add(79f + fl + 5.2f * abs(sin(u * 4f * piF)) + grow + sin(t * 3f + u * 8f) * 0.8f)
            }
            pts.add(22.5f - grow); pts.add(74f + fl)
            pts.add(22f - grow); pts.add(cy)
            dPolyList(cv, color, pts)
        }
        dOval(cv, 26f, 62f + fl, 74f, 86f + fl, col("#E6E0FF", 120))

        // arms
        val wv = sin(t * (if (spk || hap) 9f else 2.6f)) * (if (spk || hap) 22f else 9f)
        cv.save()
        cv.rotate(-25f - wv * 0.6f, 24f, 56f + fl)
        dOval(cv, 13f, 52.6f + fl, 24f, 59.4f + fl, col("#FFFFFF"))
        cv.restore()
        cv.save()
        cv.rotate(25f + wv, 76f, 56f + fl)
        dOval(cv, 76f, 52.6f + fl, 87f, 59.4f + fl, col("#FFFFFF"))
        cv.restore()

        // bow
        cv.save()
        cv.rotate(-18f, 36f, 18f + fl)
        dPoly(cv, col("#FB7185"), 36f, 18f + fl, 26.5f, 12f + fl, 26.5f, 24f + fl)
        dPoly(cv, col("#FB7185"), 36f, 18f + fl, 45.5f, 12f + fl, 45.5f, 24f + fl)
        dCircle(cv, 36f, 18f + fl, 3f, col("#E11D48"))
        cv.restore()

        val bl = blinkNow()
        for (sgn in intArrayOf(-1, 1)) {
            val sg = sgn.toFloat()
            val ex = 50f + sg * 11.5f
            val ey = 44f + fl
            if (bl || hap) {
                dArc(cv, ex - 5.4f, ey - 3.8f, ex + 5.4f, ey + 4.6f, 200f, 140f, col("#1F2937"), 1.8f)
            } else {
                dOval(cv, ex - 5.0f, ey - 6.6f, ex + 5.0f, ey + 6.6f, col("#1F2937"))
                dCircle(cv, ex - 1.7f, ey - 2.6f, 2.1f, col("#FFFFFF"))
                dCircle(cv, ex + 1.6f, ey + 2.6f, 1.0f, col("#FFFFFF"))
            }
        }
        dOval(cv, 26.5f, 51f + fl, 36.5f, 56.5f + fl, col("#FB7185", 150))
        dOval(cv, 63.5f, 51f + fl, 73.5f, 56.5f + fl, col("#FB7185", 150))
        val my = 54.5f + fl
        if (spk) {
            val o = 1.2f + 3.4f * amp
            dOval(cv, 46.2f, my - o * 0.3f, 53.8f, my + o, col("#4B1D3F"))
            dOval(cv, 47.8f, my + o * 0.35f, 52.2f, my + o * 0.95f, col("#FB7185"))
        } else if (lis) {
            dOval(cv, 48.3f, my, 51.7f, my + 3.2f, col("#4B1D3F"))
        } else if (hap) {
            dArc(cv, 45.5f, my - 3.5f, 54.5f, my + 3.2f, 20f, 140f, col("#4B1D3F"), 1.5f)
        } else {
            dArc(cv, 46.5f, my - 2.5f, 53.5f, my + 2f, 25f, 130f, col("#4B1D3F"), 1.4f)
        }

        // twinkling sparkles
        val gx = floatArrayOf(14f, 86f, 80f)
        val gy = floatArrayOf(26f, 32f, 10f)
        for (i in 0..2) {
            val a = (90 + 160 * (0.5f + 0.5f * sin(t * 3f + i * 2f))).toInt().coerceIn(0, 255)
            val r = 2.4f + 0.9f * sin(t * 3f + i * 2f)
            val x = gx[i]
            val y = gy[i]
            dPoly(
                cv, col("#FDE68A", a),
                x, y - r * 1.7f, x + r * 0.5f, y - r * 0.5f, x + r * 1.7f, y, x + r * 0.5f, y + r * 0.5f,
                x, y + r * 1.7f, x - r * 0.5f, y + r * 0.5f, x - r * 1.7f, y, x - r * 0.5f, y - r * 0.5f
            )
        }
    }

    private fun drawEars(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        for (side in intArrayOf(-1, 1)) {
            val s = side.toFloat()
            facePath.reset()
            facePath.moveTo(cx + s * r * 0.82f, cy - r * 0.30f)
            facePath.lineTo(cx + s * r * 0.66f, cy - r * 1.12f)
            facePath.lineTo(cx + s * r * 0.15f, cy - r * 0.86f)
            facePath.close()
            canvas.drawPath(facePath, earPaint)

            facePath.reset()
            facePath.moveTo(cx + s * r * 0.68f, cy - r * 0.50f)
            facePath.lineTo(cx + s * r * 0.60f, cy - r * 0.92f)
            facePath.lineTo(cx + s * r * 0.30f, cy - r * 0.76f)
            facePath.close()
            canvas.drawPath(facePath, earInnerPaint)
        }
    }

    private fun drawFace(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        val now = System.currentTimeMillis()
        val blinking = (now % 3400L) < 150L
        val eyeDx = r * 0.36f
        val eyeY = cy - r * 0.08f
        val eyeW = r * 0.17f
        var eyeH = r * 0.24f
        if (currentState == "happy") eyeH = r * 0.16f
        if (blinking) eyeH = r * 0.04f

        // Eyes look up a bit while thinking
        val lookY = if (currentState == "thinking") -r * 0.06f else 0f
        val lookX = if (currentState == "thinking") r * 0.04f else 0f

        for (side in intArrayOf(-1, 1)) {
            val ex = cx + side * eyeDx
            canvas.drawOval(RectF(ex - eyeW, eyeY - eyeH, ex + eyeW, eyeY + eyeH), eyePaint)
            if (!blinking) {
                canvas.drawCircle(ex + lookX, eyeY + lookY + eyeH * 0.1f, eyeW * 0.55f, pupilPaint)
                canvas.drawCircle(ex + lookX - eyeW * 0.2f, eyeY + lookY - eyeH * 0.15f, eyeW * 0.2f, eyePaint)
            }
        }

        // Blush
        canvas.drawCircle(cx - r * 0.62f, cy + r * 0.24f, r * 0.14f, blushPaint)
        canvas.drawCircle(cx + r * 0.62f, cy + r * 0.24f, r * 0.14f, blushPaint)

        // Mouth
        val my = cy + r * 0.38f
        when (currentState) {
            "speaking" -> {
                val open = r * (0.08f + 0.30f * audioAmplitude.coerceIn(0f, 1f))
                canvas.drawOval(RectF(cx - r * 0.16f, my - open * 0.4f, cx + r * 0.16f, my + open), mouthFillPaint)
            }
            "listening" -> {
                canvas.drawOval(RectF(cx - r * 0.09f, my - r * 0.02f, cx + r * 0.09f, my + r * 0.16f), mouthFillPaint)
            }
            "error" -> {
                val rect = RectF(cx - r * 0.16f, my, cx + r * 0.16f, my + r * 0.22f)
                canvas.drawArc(rect, 200f, 140f, false, mouthLinePaint)
            }
            "happy" -> {
                val rect = RectF(cx - r * 0.24f, my - r * 0.14f, cx + r * 0.24f, my + r * 0.20f)
                canvas.drawArc(rect, 20f, 140f, false, mouthLinePaint)
            }
            else -> {
                val rect = RectF(cx - r * 0.17f, my - r * 0.10f, cx + r * 0.17f, my + r * 0.12f)
                canvas.drawArc(rect, 25f, 130f, false, mouthLinePaint)
            }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        orbitAnimator.cancel()
        breathAnimator.cancel()
    }
}
