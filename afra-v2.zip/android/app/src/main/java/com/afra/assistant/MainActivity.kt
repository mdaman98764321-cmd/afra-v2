package com.afra.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.net.Uri
import android.view.KeyEvent
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import com.afra.assistant.bridge.AfraControls
import com.afra.assistant.bridge.AfraNativeBridge
import com.afra.assistant.wake.AfraWakeService
import org.json.JSONObject

/**
 * Hosts the AFRA web app inside a WebView.
 * - Loads the packaged app from a secure virtual https address (so storage and audio work properly).
 * - Provides native speech recognition (Android WebView has no built-in Web Speech API).
 */
class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader

    private var recognizer: SpeechRecognizer? = null
    private var wantListening = false
    private var listenLang = "bn-BD"
    private val handler = Handler(Looper.getMainLooper())
    private var pendingAction: String? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        fileCallback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
        fileCallback = null
    }
    private var pageReady = false
    private var pendingWebPermission: PermissionRequest? = null
    private var lastLevelAt = 0L

    companion object {
        private const val HOME_URL = "https://appassets.androidplatform.net/assets/index.html"
        private const val REQ_MIC = 7001
        private const val REQ_WAKE = 7002
        private const val REQ_WEB_MIC = 7004

        @Volatile
        var visible = false

        // Makes the web app's speech code use the phone's native recognizer.
        private const val SPEECH_POLYFILL = """
(function(){
  if (window.__afraSRInstalled) return;
  window.__afraSRInstalled = true;
  var active = null;
  function SR(){ this.continuous=false; this.interimResults=false; this.lang='bn-BD';
    this.onresult=null; this.onerror=null; this.onend=null; this.onstart=null; }
  SR.prototype.start=function(){ active=this; window.AfraSpeech.start(this.lang||'bn-BD'); if(this.onstart) this.onstart({}); };
  SR.prototype.stop=function(){ window.AfraSpeech.stop(); };
  SR.prototype.abort=function(){ window.AfraSpeech.stop(); };
  window.__afraSR = {
    result:function(t,f){ if(!active||!active.onresult) return;
      var res=[{transcript:t,confidence:0.9}]; res.isFinal=f;
      active.onresult({resultIndex:0,results:[res]}); },
    error:function(c,n){ if(active&&active.onerror) active.onerror({error:c,code:n}); },
    level:function(v){ if(window.__afraLevelCb) window.__afraLevelCb(v); },
    end:function(){ if(active&&active.onend) active.onend({}); }
  };
  window.SpeechRecognition=SR; window.webkitSpeechRecognition=SR;
})();
"""
    }

    inner class SpeechJsBridge {
        @JavascriptInterface
        fun start(lang: String) {
            runOnUiThread { beginListening(lang) }
        }

        @JavascriptInterface
        fun stop() {
            runOnUiThread { endListening(true) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0B0D10"))

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                loadsImagesAutomatically = true
                mediaPlaybackRequiresUserGesture = false
                cacheMode = WebSettings.LOAD_DEFAULT
                setSupportZoom(false)
                builtInZoomControls = false
                allowFileAccess = false
                allowContentAccess = false
            }

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest
                ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

                override fun onPageFinished(view: WebView?, url: String?) {
                    view?.evaluateJavascript(SPEECH_POLYFILL, null)
                    pageReady = true
                    deliverAction()
                }
            }

            // The microphone is used by the native speech recognizer, so the page itself
            // is not given direct microphone access (two apps parts can't share it at once).
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest?) {
                    if (request == null) return
                    val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (!wantsAudio) {
                        request.deny()
                        return
                    }
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED
                    ) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    } else {
                        pendingWebPermission = request
                        ActivityCompat.requestPermissions(
                            this@MainActivity, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_WEB_MIC
                        )
                    }
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = filePathCallback
                    return try {
                        pickImage.launch("image/*")
                        true
                    } catch (e: Exception) {
                        fileCallback?.onReceiveValue(null)
                        fileCallback = null
                        false
                    }
                }
            }
        }

        webView.addJavascriptInterface(AfraNativeBridge(this, webView), "AndroidAfraBridge")
        webView.addJavascriptInterface(SpeechJsBridge(), "AfraSpeech")
        webView.addJavascriptInterface(AfraControls(this), "AfraNative")
        pendingAction = intent?.getStringExtra("afra_action")

        // Keep content clear of status bar, navigation bar and keyboard.
        ViewCompat.setOnApplyWindowInsetsListener(webView) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        setContentView(webView)

        if (savedInstanceState == null) {
            webView.loadUrl(HOME_URL)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    /* ---------------- wake word / actions from the background ---------------- */

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingAction = intent.getStringExtra("afra_action")
        deliverAction()
    }

    private fun deliverAction() {
        val action = pendingAction ?: return
        if (!pageReady) return
        pendingAction = null
        val q = JSONObject.quote(action)
        handler.postDelayed({
            webView.evaluateJavascript(
                "window.__afraPendingAction=$q;window.dispatchEvent(new CustomEvent('afra-native-action',{detail:$q}));",
                null
            )
        }, 700)
    }

    fun runJs(js: String) {
        webView.post { webView.evaluateJavascript(js, null) }
    }

    fun askNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7003)
        }
    }

    fun startWakeFlow() {
        val needs = ArrayList<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needs.add(Manifest.permission.RECORD_AUDIO)
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needs.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needs.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needs.toTypedArray(), REQ_WAKE)
        } else {
            launchWakeService()
        }
    }

    private fun launchWakeService() {
        try {
            ContextCompat.startForegroundService(
                this,
                Intent(this, AfraWakeService::class.java).apply { action = AfraWakeService.ACTION_START }
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /* ---------------- native speech recognition ---------------- */

    private fun emit(js: String) {
        webView.post { webView.evaluateJavascript(js, null) }
    }

    private fun beginListening(lang: String) {
        listenLang = lang
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            emit("window.__afraSR && window.__afraSR.error('service-not-allowed');")
            return
        }
        wantListening = true
        startRecognizer()
    }

    private fun startRecognizer() {
        try {
            recognizer?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastLevelAt > 80) {
                        lastLevelAt = now
                        val v = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                        emit("window.__afraSR && window.__afraSR.level && window.__afraSR.level($v);")
                    }
                }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onPartialResults(partialResults: Bundle?) {
                    val t = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!t.isNullOrBlank()) {
                        emit("window.__afraSR && window.__afraSR.result(${JSONObject.quote(t)}, false);")
                    }
                }

                override fun onResults(results: Bundle?) {
                    val t = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (!t.isNullOrBlank()) {
                        emit("window.__afraSR && window.__afraSR.result(${JSONObject.quote(t)}, true);")
                    }
                    restartIfWanted(200)
                }

                override fun onError(error: Int) {
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restartIfWanted(300)
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restartIfWanted(800)
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> fail("not-allowed")
                        SpeechRecognizer.ERROR_NETWORK,
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER -> fail("network", error)
                        12, 13 -> fail("language-not-supported", error)
                        else -> fail("audio-capture", error)
                    }
                }
            })
            recognizer = r
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, listenLang)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
            )
        } catch (e: Exception) {
            fail("audio-capture")
        }
    }

    private fun restartIfWanted(delayMs: Long) {
        if (!wantListening) return
        handler.postDelayed({ if (wantListening) startRecognizer() }, delayMs)
    }

    private fun fail(code: String, n: Int = 0) {
        endListening(false)
        emit("window.__afraSR && window.__afraSR.error(${JSONObject.quote(code)}, $n);")
        emit("window.__afraSR && window.__afraSR.end();")
    }

    private fun endListening(notify: Boolean) {
        wantListening = false
        handler.removeCallbacksAndMessages(null)
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        recognizer = null
        if (notify) emit("window.__afraSR && window.__afraSR.end();")
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_WEB_MIC) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            val req = pendingWebPermission
            pendingWebPermission = null
            if (granted) req?.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else req?.deny()
            return
        }
        if (requestCode == REQ_WAKE) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                launchWakeService()
            }
            return
        }
        if (requestCode == REQ_MIC) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                beginListening(listenLang)
            } else {
                emit("window.__afraSR && window.__afraSR.error('not-allowed');")
                emit("window.__afraSR && window.__afraSR.end();")
            }
        }
    }

    /* ---------------- lifecycle ---------------- */

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        visible = true
        AfraWakeService.instance?.setSuspended(true)
        webView.onResume()
        webView.resumeTimers()
    }

    override fun onPause() {
        visible = false
        AfraWakeService.instance?.setSuspended(false)
        endListening(false)
        webView.onPause()
        webView.pauseTimers()
        super.onPause()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        endListening(false)
        try {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.stopLoading()
            webView.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }
}
