package com.afra.assistant.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.afra.assistant.MainActivity
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Production-grade Android Foreground Service managing the AFRA Floating Avatar Overlay.
 *
 * Uses WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY on Android 8.0+ (API 26+)
 * with touch-drag tracking, edge snapping, screen rotation safety, and a persistent
 * foreground notification respecting Android 12+ background limits & Android 13+ POST_NOTIFICATIONS.
 */
class AfraOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var preferences: SharedPreferences
    private var overlayView: AfraOverlayView? = null
    private var quickActionMenu: QuickActionMenu? = null
    private lateinit var layoutParams: WindowManager.LayoutParams

    private var screenWidth = 0
    private var screenHeight = 0
    private var avatarSizePx = 0

    // Touch physics & drag state tracking
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var touchStartTime = 0L
    private var isDragging = false

    // Active assistant state
    private var currentState = "idle"
    private var isMicrophoneActive = false

    companion object {
        const val CHANNEL_ID = "afra_floating_overlay_channel"
        const val NOTIFICATION_ID = 4041
        const val PREFS_NAME = "afra_overlay_prefs"
        const val KEY_POS_X = "overlay_x"
        const val KEY_POS_Y = "overlay_y"

        const val ACTION_START_OVERLAY = "com.afra.assistant.action.START_OVERLAY"
        const val ACTION_STOP_OVERLAY = "com.afra.assistant.action.STOP_OVERLAY"
        const val ACTION_SET_STATE = "com.afra.assistant.action.SET_STATE"
        const val ACTION_START_VOICE = "com.afra.assistant.action.START_VOICE"
        const val ACTION_STOP_VOICE = "com.afra.assistant.action.STOP_VOICE"
        const val ACTION_RELOAD_AVATAR = "com.afra.assistant.action.RELOAD_AVATAR"
        const val AVATAR_FILE = "overlay_avatar.png"
        const val EXTRA_STATE = "extra_state"
        const val EXTRA_AUDIO_LEVEL = "extra_audio_level"

        @Volatile
        var isRunning = false
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        preferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        updateScreenDimensions()
        val density = resources.displayMetrics.density
        avatarSizePx = (80 * density).toInt()

        createNotificationChannel()
        startForegroundWithNotification()

        initOverlayView()
        initQuickActionMenu()
        isRunning = true
    }

    private fun updateScreenDimensions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowMetrics = windowManager.currentWindowMetrics
            val insets = windowMetrics.windowInsets.getInsetsIgnoringVisibility(
                android.view.WindowInsets.Type.systemBars()
            )
            screenWidth = windowMetrics.bounds.width() - insets.left - insets.right
            screenHeight = windowMetrics.bounds.height() - insets.top - insets.bottom
        } else {
            val display = windowManager.defaultDisplay
            val size = Point()
            display.getSize(size)
            screenWidth = size.x
            screenHeight = size.y
        }
    }

    private fun initOverlayView() {
        if (!OverlayPermissionHelper.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // Restore last known position from SharedPreferences, default to right edge
        val savedX = preferences.getInt(KEY_POS_X, screenWidth - avatarSizePx - 24)
        val savedY = preferences.getInt(KEY_POS_Y, (screenHeight * 0.35f).toInt())

        layoutParams = WindowManager.LayoutParams(
            avatarSizePx,
            avatarSizePx,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = clampX(savedX)
            y = clampY(savedY)
        }

        overlayView = AfraOverlayView(this).apply {
            setOnTouchListener(createTouchListener())
        }

        try {
            windowManager.addView(overlayView, layoutParams)
        } catch (e: Exception) {
            e.printStackTrace()
            stopSelf()
        }
    }

    private fun initQuickActionMenu() {
        quickActionMenu = QuickActionMenu(
            context = this,
            windowManager = windowManager,
            onOpenChat = {
                quickActionMenu?.dismiss()
                launchAppWithAction("open_chat")
            },
            onStartVoice = {
                quickActionMenu?.dismiss()
                launchAppWithAction("start_voice")
            },
            onQuickMessage = {
                quickActionMenu?.showQuickInputModal(
                    onSend = { query ->
                        handleQuickQuery(query)
                    }
                )
            },
            onReturnToApp = {
                quickActionMenu?.dismiss()
                launchAppWithAction("return_app")
            },
            onHide = {
                quickActionMenu?.dismiss()
                overlayView?.visibility = View.GONE
            },
            onClose = {
                quickActionMenu?.dismiss()
                stopSelf()
            }
        )
    }

    private fun createTouchListener(): View.OnTouchListener {
        val clickThresholdPx = 10 * resources.displayMetrics.density

        return View.OnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    touchStartTime = System.currentTimeMillis()
                    isDragging = false
                    overlayView?.setPressedScale(true)
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val deltaX = event.rawX - initialTouchX
                    val deltaY = event.rawY - initialTouchY

                    if (abs(deltaX) > clickThresholdPx || abs(deltaY) > clickThresholdPx) {
                        isDragging = true
                        quickActionMenu?.dismiss()
                    }

                    if (isDragging) {
                        layoutParams.x = clampX((initialX + deltaX).toInt())
                        layoutParams.y = clampY((initialY + deltaY).toInt())
                        windowManager.updateViewLayout(overlayView, layoutParams)
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    overlayView?.setPressedScale(false)
                    val duration = System.currentTimeMillis() - touchStartTime

                    if (!isDragging && duration < 300) {
                        // Tapped: toggle Quick Action Menu adjacent to avatar
                        toggleQuickActionMenu()
                    } else if (isDragging) {
                        // Drag completed: snap to nearest screen edge (left or right)
                        snapToNearestEdge()
                    }
                    true
                }

                else -> false
            }
        }
    }

    private fun snapToNearestEdge() {
        val centerX = layoutParams.x + (avatarSizePx / 2)
        val targetX = if (centerX < screenWidth / 2) {
            16 // Snap to left edge with padding
        } else {
            screenWidth - avatarSizePx - 16 // Snap to right edge with padding
        }

        layoutParams.x = targetX
        layoutParams.y = clampY(layoutParams.y)
        windowManager.updateViewLayout(overlayView, layoutParams)

        // Save position for persistence across app sessions
        preferences.edit()
            .putInt(KEY_POS_X, layoutParams.x)
            .putInt(KEY_POS_Y, layoutParams.y)
            .apply()
    }

    private fun toggleQuickActionMenu() {
        if (quickActionMenu?.isShowing() == true) {
            quickActionMenu?.dismiss()
        } else {
            val posX = layoutParams.x
            val posY = layoutParams.y
            val showOnLeft = posX > (screenWidth / 2)
            quickActionMenu?.show(posX, posY, showOnLeft)
        }
    }

    private fun clampX(x: Int): Int = max(0, min(x, screenWidth - avatarSizePx))
    private fun clampY(y: Int): Int = max(48, min(y, screenHeight - avatarSizePx - 80))

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateScreenDimensions()
        snapToNearestEdge()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_OVERLAY -> {
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_SET_STATE -> {
                val state = intent.getStringExtra(EXTRA_STATE) ?: "idle"
                val level = intent.getFloatExtra(EXTRA_AUDIO_LEVEL, 0f)
                setAvatarAnimationState(state, level)
            }

            ACTION_RELOAD_AVATAR -> {
                overlayView?.reloadAvatar()
            }

            ACTION_START_VOICE -> {
                startVoiceSession()
            }

            ACTION_STOP_VOICE -> {
                stopVoiceSession()
            }
        }

        return START_STICKY
    }

    fun setAvatarAnimationState(state: String, audioLevel: Float = 0f) {
        currentState = state
        overlayView?.setAnimationState(state, audioLevel)
    }

    private fun startVoiceSession() {
        isMicrophoneActive = true
        setAvatarAnimationState("listening")
        updateNotification()
        // Connect to speech engine with mic safety indicator
        overlayView?.showMicrophoneIndicator(true)
    }

    private fun stopVoiceSession() {
        isMicrophoneActive = false
        setAvatarAnimationState("idle")
        updateNotification()
        overlayView?.showMicrophoneIndicator(false)
    }

    private fun handleQuickQuery(query: String) {
        setAvatarAnimationState("thinking")
        // Post query into bridge / backend
        val intent = Intent("com.afra.assistant.QUICK_QUERY").apply {
            putExtra("query", query)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun launchAppWithAction(action: String) {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("afra_action", action)
        }
        startActivity(launchIntent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AFRA Floating Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controls and status for AFRA Floating Avatar Overlay"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE)
        }

        val stopIntent = Intent(this, AfraOverlayService::class.java).apply {
            action = ACTION_STOP_OVERLAY
        }.let {
            PendingIntent.getService(this, 1, it, PendingIntent.FLAG_IMMUTABLE)
        }

        val contentText = if (isMicrophoneActive) {
            "Voice Mode Active • Listening (Mic On)"
        } else {
            "AFRA is floating above other apps • Tap to interact"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AFRA Floating Assistant")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Close Overlay", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun startForegroundWithNotification() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        quickActionMenu?.dismiss()
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        overlayView = null
    }
}
