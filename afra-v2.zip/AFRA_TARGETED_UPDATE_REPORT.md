# Afra targeted avatar update

## Implemented in this package
- Added a new built-in avatar option: `Afra Red Chibi` (`afra-red-chibi`). Existing built-in avatars remain in the default avatar list.
- Added twelve transparent PNG frame assets extracted from the three supplied four-pose contact sheets (four frames each for idle, drag and tap).
- Normalized frame canvases to 384x820 RGBA to reduce character scale/position jitter between frames.
- Updated `AvatarRenderer` to animate the new avatar's idle, drag and tap frame sequences. Pointer movement under 9px is treated as a tap; larger movement is treated as drag.
- Added a legacy-default migration: installations still using the untouched `afra-core` default now select the new red chibi; explicitly selected other avatars are preserved.

## Files changed
- `src/services/defaultAvatars.ts`
- `src/services/storage.ts`
- `src/components/avatar/AvatarRenderer.tsx`
- `src/assets/images/afra_red_chibi_idle_1.png` through `_4.png`
- `src/assets/images/afra_red_chibi_drag_1.png` through `_4.png`
- `src/assets/images/afra_red_chibi_tap_1.png` through `_4.png`

## Not completed / not verified
- Native Android `AfraOverlayView.kt` has its own bitmap renderer and was not yet wired to these PNG frames. The animation changes in this update apply to React-rendered avatar surfaces (gallery, chat/voice renderer and web floating preview where AvatarRenderer is used), not the independent native Android overlay service.
- Voice-call behavior and theme customization were not modified in this avatar-focused correction.
- A Vite/TypeScript build and on-device Android test were not run because dependencies/build environment are not installed in this workspace.
