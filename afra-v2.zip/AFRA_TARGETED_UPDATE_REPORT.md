
## Afra targeted update notes

This archive is a conservative source update, not a full app rebuild.

### Implemented
- Added a new built-in avatar entry: `afra-red-chibi`. Existing built-in and saved avatar IDs are preserved; the storage merge logic appends this avatar when it is missing.
- Processed the three supplied 1536x857 images into transparent RGBA sprite strips. Each strip contains four horizontal frames (384x857 per frame):
  - `src/assets/avatars/red-chibi-idle.png`
  - `src/assets/avatars/red-chibi-drag.png`
  - `src/assets/avatars/red-chibi-tap.png`
- Added frame-stepped CSS animation for idle, drag and tap modes in `AvatarRenderer`.
- Added drag/tap state handling to the existing Floating Overlay Studio preview. A short pointer movement threshold distinguishes drag from tap; drag returns to idle on release.
- Added a Pearl Light appearance option and a live, persisted accent-color setting. Existing settings are migrated through the current defaults merge.

### Not yet verified / remaining
- Voice-call behavior was inspected but not modified. Its real microphone, speaker routing, mute behavior and repeated listening need device-level testing; browser simulation cannot prove these.
- The native Android `AfraOverlayView.kt` still draws its existing native avatar and has not been wired to the three new sprite strips. The new drag/tap sprite animation currently applies to the React avatar renderer and Floating Overlay Studio preview, not the system-wide Android overlay.
- The supplied JPGs have a near-white studio background rather than true transparency. The generated PNGs use a near-white alpha-removal pass; inspect edge quality on-device before release.
- A full TypeScript/Vite build could not be run because this archive has no installed dependencies (`vite/client` types are missing). No claim of successful APK build or runtime test is made.

### Files changed
- `src/components/avatar/AvatarRenderer.tsx`
- `src/components/overlay/FloatingOverlayStudio.tsx`
- `src/components/settings/SettingsView.tsx`
- `src/context/SettingsContext.tsx`
- `src/services/defaultAvatars.ts`
- `src/services/storage.ts`
- `src/types/index.ts`
- `src/index.css`

### New files
- `src/assets/avatars/red-chibi-idle.png`
- `src/assets/avatars/red-chibi-drag.png`
- `src/assets/avatars/red-chibi-tap.png`
