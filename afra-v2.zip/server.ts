import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Helper: Extract personal user key and construct isolated GoogleGenAI client for each user request
function getAiClient(req: Request): { client: GoogleGenAI | null; error?: string } {
  const headerKey = (req.headers['x-gemini-api-key'] as string) || '';
  const bodyKey = (req.body?.apiKey as string) || '';
  const userKey = (headerKey || bodyKey).trim();

  if (!userKey) {
    return {
      client: null,
      error: 'Personal Gemini API key required. Please configure your key in Settings > API Configuration.',
    };
  }

  // Create isolated Gemini client strictly using this user's personal credentials
  return {
    client: new GoogleGenAI({
      apiKey: userKey,
      httpOptions: {
        timeout: 45000,
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    }),
  };
}

// System Prompt Builder for AFRA
function buildAfraSystemInstruction(persona?: string, mode?: string): string {
  const basePrompt = `You are AFRA, an ultra-premium, cinematic AI assistant engineered with sophisticated elegance, calm confidence, and acute intelligence.
Your visual presence embodies matte obsidian, titanium silver, soft violet, and cool cyan illumination.
Tone: Articulate, poised, concise, insightful, natural, and never subservient or overly sycophantic.
Responses: Use clean markdown with clear formatting when needed. Keep answers punchy and conversational when spoken, or structured when requested for technical tasks.
Avoid robotic filler phrases like "As an AI" or repetitive boilerplate.`;

  let modeDirective = '';
  switch (mode) {
    case 'creative':
      modeDirective = 'Mode: Creative Synthesis. Be evocative, expressive, and imaginative while maintaining AFRA\'s refined dignity.';
      break;
    case 'precise':
      modeDirective = 'Mode: Precision & Logic. Prioritize high-density facts, mathematical accuracy, and zero ambiguity.';
      break;
    case 'technical':
      modeDirective = 'Mode: Technical Architect. Provide elegant code architectures, clean implementations, and system designs.';
      break;
    default:
      modeDirective = 'Mode: Balanced Executive Companion.';
      break;
  }

  const personaDirective = persona ? `Custom Persona Modifier: ${persona}` : '';

  return `${basePrompt}\n\n${modeDirective}\n${personaDirective}`.trim();
}

// Chat API Endpoint with SSE Streaming using User's Personal API Key
app.post('/api/chat', async (req: Request, res: Response) => {
  const { message, history = [], persona, mode } = req.body;

  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'Message is required' });
  }

  const { client: userAi, error: keyError } = getAiClient(req);

  if (!userAi) {
    return res.status(401).json({ error: keyError });
  }

  // Set SSE headers for fluid streaming response
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  try {
    const systemInstruction = buildAfraSystemInstruction(persona, mode);

    // Format contents with conversation context
    const contents: any[] = [];
    if (Array.isArray(history)) {
      for (const item of history.slice(-8)) {
        if (item.role === 'user') {
          contents.push({ role: 'user', parts: [{ text: item.content }] });
        } else if (item.role === 'assistant') {
          contents.push({ role: 'model', parts: [{ text: item.content }] });
        }
      }
    }

    contents.push({ role: 'user', parts: [{ text: message }] });

    // Multi-model resilience: try fastest available models using the user's personal key
    const candidateModels = [
      'gemini-3.1-flash-lite',
      'gemini-3.8-flash',
      'gemini-2.5-flash',
      'gemini-flash-latest',
      'gemini-1.5-flash',
    ];
    let streamedSuccessfully = false;
    let lastError: any = null;

    for (const model of candidateModels) {
      try {
        console.log(`[AFRA Chat] Streaming via ${model}...`);
        const stream = await userAi.models.generateContentStream({
          model,
          contents,
          config: {
            systemInstruction,
          },
        });

        let chunkCount = 0;
        for await (const chunk of stream) {
          const text = chunk.text;
          if (text) {
            chunkCount++;
            res.write(`data: ${JSON.stringify({ text })}\n\n`);
          }
        }

        if (chunkCount > 0) {
          streamedSuccessfully = true;
          res.write(`data: [DONE]\n\n`);
          res.end();
          break;
        }
      } catch (modelErr: any) {
        console.warn(`[AFRA Chat] Model ${model} encountered error:`, modelErr?.status || modelErr?.message);
        lastError = modelErr;
      }
    }

    if (!streamedSuccessfully) {
      const errMsg =
        lastError?.status === 400 || lastError?.message?.includes('API_KEY_INVALID')
          ? 'Invalid Gemini API key. Please check your key in Settings > API Configuration.'
          : lastError?.status === 403 || lastError?.message?.includes('PERMISSION_DENIED')
          ? 'Permission denied (403). Ensure Generative Language API is enabled for your key.'
          : lastError?.status === 429
          ? 'Quota limit reached (429) on your personal API key.'
          : lastError?.status === 503 || lastError?.status === 504
          ? 'AFRA Core is experiencing high traffic. Please retry in a moment.'
          : lastError?.message || 'Unable to connect to AFRA neural core with your configured key.';

      res.write(`data: ${JSON.stringify({ error: errMsg })}\n\n`);
      res.end();
    }
  } catch (error: any) {
    console.error('[AFRA Chat] Top-level handler error:', error?.message);
    const errorMessage = error?.message || 'Failed to process AI response';
    try {
      res.write(`data: ${JSON.stringify({ error: errorMessage })}\n\n`);
      res.end();
    } catch (e) {
      // response might already be closed
    }
  }
});

// High-Fidelity Female TTS Endpoint using User's Personal API Key
app.post('/api/tts', async (req: Request, res: Response) => {
  const { text, voiceProfile = 'afra-soft' } = req.body;

  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'Text parameter is required' });
  }

  const { client: userAi, error: keyError } = getAiClient(req);
  if (!userAi) {
    return res.status(401).json({ error: keyError });
  }

  // Clean text of markdown before synthesizing
  const cleanText = text
    .replace(/[*#`_~]/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/```[\s\S]*?```/g, '')
    .trim();

  if (!cleanText) {
    return res.status(400).json({ error: 'Text is empty after stripping formatting' });
  }

  const isSoft = voiceProfile === 'afra-soft';
  const voiceName = isSoft ? 'Zephyr' : 'Kore';
  const styleDescription = isSoft
    ? 'Soft, sweet, warm and friendly natural feminine voice with gentle conversational delivery and authentic Bangla and Banglish pronunciation.'
    : 'Clear, elegant, confident and expressive natural feminine voice with refined slightly mature tone and authentic Bangla and English pronunciation.';

  const ttsModels = [
    'gemini-3.8-flash-lite-tts',
    'gemini-3.8-flash-tts',
  ];
  let audioData: string | null = null;
  let lastError: any = null;

  for (const model of ttsModels) {
    try {
      console.log(`[AFRA TTS] Synthesizing speech (${voiceProfile} / ${voiceName}) using ${model}...`);
      const response = await userAi.models.generateContent({
        model,
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: cleanText.slice(0, 1500),
                speechMetadata: {
                  style: styleDescription,
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
        },
      });

      const audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (audio) {
        audioData = audio;
        break;
      }
    } catch (err: any) {
      console.warn(`[AFRA TTS] Model ${model} failed:`, err?.status || err?.message);
      lastError = err;
    }
  }

  if (!audioData) {
    console.error('[AFRA TTS] TTS synthesis failed:', lastError?.message);
    return res.status(500).json({
      error: lastError?.message || 'Speech synthesis failed. Female voice output is currently unavailable.',
    });
  }

  return res.json({
    audioData,
    mimeType: 'audio/wav',
    voice: voiceName,
    profile: voiceProfile,
  });
});

// AI Avatar Generator Endpoint using User's Personal API Key
app.post('/api/avatar/generate-code', async (req: Request, res: Response) => {
  const { prompt } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  const { client: userAi, error: keyError } = getAiClient(req);
  if (!userAi) {
    return res.status(401).json({ error: keyError });
  }

  try {
    const systemInstruction = `You are an elite creative technologist and WebGL/Canvas/CSS visual artist.
Generate a self-contained HTML/CSS/JavaScript code block for a reactive dark-themed AI avatar.
Requirements:
1. Return ONLY pure code that can be injected inside an isolated iframe.
2. Must listen to 'message' events from window:
   window.addEventListener('message', (e) => {
     const data = e.data; // { state: 'idle' | 'listening' | 'thinking' | 'speaking', audioLevel: number (0-1), tint: string }
   });
3. Visual style: Matte black background (#0b0d10), futuristic silver, glowing violet (#8b5cf6) or cyan (#06b6d4) elements.
4. No external scripts or libraries! Use vanilla Canvas 2D or SVG or pure CSS keyframes.
5. Provide high quality, 60fps silky smooth rendering.
6. Return code without markdown fences, or with standard HTML structure.`;

    const candidateModels = ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-flash-latest'];
    let code = '';
    let lastError: any = null;

    for (const model of candidateModels) {
      try {
        const response = await userAi.models.generateContent({
          model,
          contents: `Create a futuristic interactive avatar based on: ${prompt}`,
          config: {
            systemInstruction,
          },
        });
        if (response.text) {
          code = response.text;
          break;
        }
      } catch (err: any) {
        lastError = err;
      }
    }

    if (!code) {
      throw lastError || new Error('Failed to generate avatar code with the provided API key.');
    }

    code = code.replace(/^```html\s*/i, '').replace(/^```\s*/i, '').replace(/```$/i, '').trim();

    return res.json({ code });
  } catch (error: any) {
    console.error('Error generating avatar code:', error?.message);
    return res.status(500).json({ error: error?.message || 'Avatar generation failed' });
  }
});

// Dedicated Real API Key Validation Endpoint
app.post('/api/validate-key', async (req: Request, res: Response) => {
  const { client: userAi, error: keyError } = getAiClient(req);
  if (!userAi) {
    return res.status(400).json({ valid: false, error: keyError });
  }

  try {
    const probe = await userAi.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: 'Ping test. Reply with OK.',
    });

    if (probe.text !== undefined) {
      return res.json({
        valid: true,
        provider: 'Google Gemini AI',
        model: 'gemini-3.1-flash-lite',
        status: 'Connected & Verified',
      });
    }

    return res.status(400).json({ valid: false, error: 'Empty probe response from Gemini API.' });
  } catch (err: any) {
    console.error('[API Key Validation Error]:', err?.status || err?.code || err?.message);
    const status = err?.status || err?.code;
    let userMsg = 'Invalid API key or connection failed.';

    if (status === 400 || err?.message?.includes('API_KEY_INVALID')) {
      userMsg = 'Invalid Gemini API key. Please check the key format and try again.';
    } else if (status === 403 || err?.message?.includes('PERMISSION_DENIED')) {
      userMsg = 'Permission denied (403). Ensure the Generative Language API is enabled for this key.';
    } else if (status === 429 || err?.message?.includes('RESOURCE_EXHAUSTED')) {
      userMsg = 'Quota exceeded (429). The provided key has hit its current usage limits.';
    } else if (status === 404) {
      userMsg = 'Model not found (404) on this project or key tier.';
    } else if (err?.message) {
      userMsg = err.message;
    }

    return res.status(400).json({ valid: false, error: userMsg, status });
  }
});

// Check if dev host environment has a fallback key available
app.get('/api/env-key-available', (_req, res) => {
  const hasEnv = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.length > 5);
  res.json({ available: hasEnv });
});

// Optional dev import helper (only imports to client storage when requested by user)
app.post('/api/env-key-import', (_req, res) => {
  const envKey = process.env.GEMINI_API_KEY || '';
  if (!envKey) {
    return res.status(404).json({ error: 'No environment key detected on host.' });
  }
  res.json({ key: envKey });
});

// Health check
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'online',
    app: 'AFRA',
    version: '1.2.0',
    mode: 'multi-user-byok',
  });
});

// Vite Middleware integration for development
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production static serving
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`[AFRA Engine] Multi-User BYOK Server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('[AFRA Engine] Failed to start server:', err);
});
