import React from 'react';
import { useAvatarEngine } from '../../context/AvatarEngineContext';
import { StateSimulationController } from '../avatar/StateSimulationController';
import { AvatarRenderer } from '../avatar/AvatarRenderer';
import { Activity, Radio, Cpu, RefreshCw, Terminal, Smartphone } from 'lucide-react';

export const AvatarStateManager: React.FC = () => {
  const {
    activeAvatar,
    avatarState,
    audioLevel,
    setAvatarState,
    setAudioLevel,
    recentBridgeEvents,
  } = useAvatarEngine();

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div>
        <h2 className="text-xl sm:text-2xl font-semibold text-white font-display tracking-tight">
          Avatar State Manager
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Real-time animation state machine, audio level telemetry, and Android Kotlin bridge event dispatcher.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Visual Telemetry & State Control (6 cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/70 border border-slate-800/80 shadow-2xl flex flex-col items-center">
            <div className="w-full flex items-center justify-between mb-4">
              <span className="text-xs uppercase tracking-wider text-slate-400 font-medium">
                Active Avatar Viewport
              </span>
              <div className="flex items-center gap-1.5 text-xs text-violet-400 font-mono">
                <span className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />
                <span className="uppercase">{avatarState}</span>
              </div>
            </div>

            <div className="py-4">
              <AvatarRenderer
                avatar={activeAvatar}
                state={avatarState}
                audioLevel={audioLevel}
                size="lg"
                showHalo={true}
              />
            </div>

            {/* State Simulation Dock */}
            <div className="w-full mt-4">
              <StateSimulationController
                currentState={avatarState}
                audioLevel={audioLevel}
                onStateChange={setAvatarState}
                onAudioLevelChange={setAudioLevel}
              />
            </div>
          </div>

          {/* Decoupled Architecture Invariants */}
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-200 font-display">
              <Cpu className="w-4 h-4 text-violet-400" />
              <span>Decoupled Engine Architecture</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              AFRA’s avatar rendering engine runs independently from LLM conversation threads. The
              state machine consumes events through standard postMessage boundaries for web sandboxes
              and JavascriptInterface callbacks for native Android applications.
            </p>
            <div className="grid grid-cols-2 gap-2 pt-2 text-xs text-slate-300">
              <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/60">
                <span className="text-slate-500 block text-[10px] uppercase">State Model</span>
                <span className="font-mono text-violet-300">Finite State Machine (FSM)</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/60">
                <span className="text-slate-500 block text-[10px] uppercase">Audio Latency</span>
                <span className="font-mono text-cyan-300">~12ms WebAudio</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Android Native Bridge Event Logger (6 cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="p-5 rounded-3xl bg-slate-950 border border-slate-800 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-semibold text-white font-display">
                  Android Kotlin Bridge Event Stream
                </span>
              </div>
              <span className="text-[10px] font-mono text-slate-500">Live JSON Dispatches</span>
            </div>

            <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
              {recentBridgeEvents.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-500">
                  Interact with the state buttons or send a chat message to witness live bridge dispatches.
                </div>
              ) : (
                recentBridgeEvents.map((evt, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-900/80 border border-slate-800/70 font-mono text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span className="text-cyan-400 font-semibold">{evt.action}</span>
                      <span className="tabular-nums">
                        {new Date(evt.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                          second: '2-digit',
                        })}
                      </span>
                    </div>
                    <pre className="text-slate-300 overflow-x-auto text-[11px] leading-tight">
                      {JSON.stringify(evt.payload, null, 2)}
                    </pre>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
