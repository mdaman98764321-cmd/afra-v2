import React, { useState } from 'react';
import { useAvatarEngine } from '../../context/AvatarEngineContext';
import { AvatarItem, AvatarType } from '../../types';
import { AvatarRenderer } from '../avatar/AvatarRenderer';
import { Check, Sparkles, Code, Image as ImageIcon, Trash2, Plus } from 'lucide-react';

interface AvatarGalleryProps {
  onOpenImporter: () => void;
  onOpenEditor: (avatarToEdit?: AvatarItem) => void;
}

export const AvatarGallery: React.FC<AvatarGalleryProps> = ({ onOpenImporter, onOpenEditor }) => {
  const { avatars, activeAvatar, selectAvatar, deleteCustomAvatar, avatarState, audioLevel } =
    useAvatarEngine();
  const [filterType, setFilterType] = useState<'all' | 'image' | 'code'>('all');

  const filteredAvatars = avatars.filter((a) => {
    if (filterType === 'all') return true;
    return a.type === filterType;
  });

  return (
    <div className="space-y-6">
      {/* Top Header & Action Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-semibold text-white font-display tracking-tight">
            Avatar Gallery
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Select, inspect, or manage photorealistic humanoid and code-driven interactive avatars.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenImporter}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl border border-slate-700 transition-colors shadow-sm"
          >
            <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
            <span>Import Image</span>
          </button>

          <button
            onClick={() => onOpenEditor()}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-violet-600 hover:bg-violet-500 text-white rounded-xl transition-colors shadow-sm shadow-violet-600/30"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Code Avatar</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs (Interactive segmented buttons allowed by Constitution §1.A) */}
      <div className="flex items-center gap-1 p-1 bg-slate-900/80 rounded-xl border border-slate-800/80 w-fit">
        <button
          onClick={() => setFilterType('all')}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
            filterType === 'all'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          All Avatars ({avatars.length})
        </button>
        <button
          onClick={() => setFilterType('image')}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
            filterType === 'image'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Photorealistic Renders
        </button>
        <button
          onClick={() => setFilterType('code')}
          className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
            filterType === 'code'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Sandbox Code Avatars
        </button>
      </div>

      {/* Grid of Avatars */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAvatars.map((avatar) => {
          const isActive = avatar.id === activeAvatar.id;

          return (
            <div
              key={avatar.id}
              className={`relative flex flex-col justify-between p-4 rounded-2xl bg-slate-900/70 border transition-all duration-200 ${
                isActive
                  ? 'border-violet-500/80 shadow-lg shadow-violet-500/10 bg-slate-900/90'
                  : 'border-slate-800/80 hover:border-slate-700/80 hover:bg-slate-900/80'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-start justify-between gap-3 mb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-semibold text-white font-display">
                      {avatar.name}
                    </h3>
                    {isActive && (
                      <span className="text-[10px] text-violet-400 font-medium bg-violet-950/60 border border-violet-800/60 px-2 py-0.5 rounded-full">
                        Active
                      </span>
                    )}
                  </div>
                  {/* Clean unboxed metadata with bullet separators (Constitution §1.A) */}
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1">
                    <span>{avatar.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{avatar.type === 'code' ? 'HTML/CSS/JS' : 'High-Res Render'}</span>
                  </div>
                </div>

                {avatar.type === 'code' ? (
                  <Code className="w-4 h-4 text-cyan-400 shrink-0" />
                ) : (
                  <Sparkles className="w-4 h-4 text-violet-400 shrink-0" />
                )}
              </div>

              {/* Avatar Center Preview Area */}
              <div className="py-4 flex items-center justify-center">
                <AvatarRenderer
                  avatar={avatar}
                  state={isActive ? avatarState : 'idle'}
                  audioLevel={isActive ? audioLevel : 0}
                  size="md"
                  showHalo={isActive}
                />
              </div>

              {/* Tagline Description */}
              <p className="text-xs text-slate-400 line-clamp-2 my-2 leading-relaxed">
                {avatar.tagline}
              </p>

              {/* Card Action Footer */}
              <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-800/80 mt-2">
                <div className="flex items-center gap-1">
                  {avatar.type === 'code' && (
                    <button
                      onClick={() => onOpenEditor(avatar)}
                      className="px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                    >
                      Inspect Code
                    </button>
                  )}
                  {!avatar.isBuiltIn && (
                    <button
                      onClick={() => deleteCustomAvatar(avatar.id)}
                      title="Delete avatar"
                      className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-rose-500/10 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <button
                  onClick={() => selectAvatar(avatar.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-violet-600/30 text-violet-300 border border-violet-500/50 cursor-default'
                      : 'bg-slate-800 hover:bg-slate-700 text-white'
                  }`}
                >
                  {isActive ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-violet-400" />
                      <span>Selected</span>
                    </>
                  ) : (
                    <span>Set Active</span>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
