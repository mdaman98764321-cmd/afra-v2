import React, { useState } from 'react';
import { useAvatarEngine } from '../../context/AvatarEngineContext';
import { AvatarItem } from '../../types';
import { AvatarRenderer } from '../avatar/AvatarRenderer';
import { Upload, ArrowLeft, Check, Sparkles, Sliders } from 'lucide-react';

interface ImageAvatarImporterProps {
  onBack: () => void;
}

const COLOR_PRESETS = [
  { label: 'Violet', hex: '#8b5cf6' },
  { label: 'Cyan', hex: '#06b6d4' },
  { label: 'Silver', hex: '#e2e8f0' },
  { label: 'Emerald', hex: '#10b981' },
  { label: 'Amber', hex: '#f59e0b' },
  { label: 'Rose', hex: '#f43f5e' },
];

export const ImageAvatarImporter: React.FC<ImageAvatarImporterProps> = ({ onBack }) => {
  const { saveCustomAvatar } = useAvatarEngine();

  const [name, setName] = useState('Obsidian Persona');
  const [tagline, setTagline] = useState('Custom visual persona with kinetic silver and violet illumination');
  const [imageUrl, setImageUrl] = useState('/src/assets/images/afra_core_portrait_1793966609177.jpg');
  const [tintColor, setTintColor] = useState('#8b5cf6');
  const [glowIntensity, setGlowIntensity] = useState(0.85);
  const [breathingSpeed, setBreathingSpeed] = useState(1.0);
  const [scaleFactor, setScaleFactor] = useState(1.0);

  const previewAvatar: AvatarItem = {
    id: `temp-preview-${Date.now()}`,
    name: name || 'Untitled Avatar',
    tagline,
    type: 'image',
    category: 'Custom',
    imageUrl,
    tintColor,
    glowIntensity,
    breathingSpeed,
    scaleFactor,
    isBuiltIn: false,
    createdAt: Date.now(),
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (loadEvt) => {
        if (loadEvt.target?.result) {
          setImageUrl(loadEvt.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    const newAvatar: AvatarItem = {
      ...previewAvatar,
      id: `custom-img-${Date.now()}`,
    };
    saveCustomAvatar(newAvatar);
    onBack();
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Gallery</span>
        </button>

        <button
          onClick={handleSave}
          className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium bg-violet-600 hover:bg-violet-500 text-white rounded-xl shadow-md shadow-violet-600/30 transition-all active:scale-95"
        >
          <Check className="w-3.5 h-3.5" />
          <span>Save & Set Active</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* Left Column: Live Interactive Preview */}
        <div className="flex flex-col items-center justify-center p-8 rounded-3xl bg-slate-900/60 border border-slate-800/80 shadow-2xl">
          <div className="text-center mb-6">
            <span className="text-xs uppercase tracking-wider text-slate-500 font-medium">
              Live Preview
            </span>
            <h3 className="text-lg font-semibold text-white font-display mt-1">{previewAvatar.name}</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xs">{previewAvatar.tagline}</p>
          </div>

          <div className="py-6">
            <AvatarRenderer
              avatar={previewAvatar}
              state="idle"
              audioLevel={0}
              size="lg"
              showHalo={true}
            />
          </div>

          <div className="flex items-center gap-2 mt-4 text-[11px] text-slate-500">
            <span>Dynamic Rim Glow</span>
            <span aria-hidden="true">·</span>
            <span>{Math.round(glowIntensity * 100)}% Intensity</span>
          </div>
        </div>

        {/* Right Column: Configuration & Upload Options */}
        <div className="space-y-5 p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80">
          <div>
            <h3 className="text-base font-semibold text-white font-display mb-1">
              Avatar Identity & Asset
            </h3>
            <p className="text-xs text-slate-400">
              Provide an image file or direct image link to craft your custom assistant persona.
            </p>
          </div>

          {/* Image Input Options */}
          <div className="space-y-3">
            <label className="block text-xs font-medium text-slate-300">Image Source</label>
            <div className="flex items-center gap-2">
              <label className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-dashed border-slate-700 hover:border-slate-500 bg-slate-950/50 hover:bg-slate-900 cursor-pointer text-xs font-medium text-slate-300 transition-colors">
                <Upload className="w-4 h-4 text-violet-400" />
                <span>Upload File from Device</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            <div className="text-center text-[10px] text-slate-500 uppercase tracking-widest">
              or specify image URL
            </div>

            <input
              type="text"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="https://..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-violet-500 transition-colors"
            />
          </div>

          {/* Name & Tagline */}
          <div className="space-y-3 pt-2 border-t border-slate-800/70">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Avatar Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Valkyrie Prime"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-violet-500 transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Description / Role
              </label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                placeholder="e.g. High-performance executive strategist"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-violet-500 transition-colors"
              />
            </div>
          </div>

          {/* Tint Color Selector */}
          <div className="space-y-2 pt-2 border-t border-slate-800/70">
            <label className="block text-xs font-medium text-slate-300">
              Luminous Halo Accent
            </label>
            <div className="flex items-center gap-2.5 flex-wrap">
              {COLOR_PRESETS.map((color) => {
                const isSelected = tintColor === color.hex;
                return (
                  <button
                    key={color.hex}
                    type="button"
                    onClick={() => setTintColor(color.hex)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                      isSelected
                        ? 'border-white text-white bg-slate-800'
                        : 'border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span>{color.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sliders: Glow Intensity & Scale */}
          <div className="space-y-4 pt-2 border-t border-slate-800/70">
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Glow Intensity</span>
                <span className="font-mono tabular-nums text-slate-200">
                  {Math.round(glowIntensity * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.2"
                max="1.0"
                step="0.05"
                value={glowIntensity}
                onChange={(e) => setGlowIntensity(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-violet-400"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Scale Multiplier</span>
                <span className="font-mono tabular-nums text-slate-200">
                  {scaleFactor.toFixed(2)}x
                </span>
              </div>
              <input
                type="range"
                min="0.8"
                max="1.25"
                step="0.05"
                value={scaleFactor}
                onChange={(e) => setScaleFactor(parseFloat(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-violet-400"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
