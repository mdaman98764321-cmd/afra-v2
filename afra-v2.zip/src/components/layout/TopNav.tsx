import React from 'react';
import { Sparkles, Mic } from 'lucide-react';

interface TopNavProps {
  activeView: 'chat' | 'studio' | 'overlay' | 'settings';
  onSelectView: (view: 'chat' | 'studio' | 'overlay' | 'settings') => void;
  onOpenVoice: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({ activeView, onSelectView, onOpenVoice }) => {
  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 border-b border-slate-800/80 bg-[#0b0d10]/90 backdrop-blur-md sticky top-0 z-30">
      {/* Zone 1: Single text element wordmark */}
      <button
        onClick={() => onSelectView('chat')}
        className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 font-display flex items-center gap-2 text-left"
      >
        <span className="bg-gradient-to-r from-white via-slate-200 to-violet-400 bg-clip-text text-transparent">
          AFRA
        </span>
      </button>

      {/* Zone 2: Clean single-line text navigation links */}
      <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400">
        <button
          onClick={() => onSelectView('chat')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeView === 'chat' ? 'text-white font-semibold' : ''
          }`}
        >
          AI Chat
        </button>

        <button
          onClick={() => onSelectView('studio')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeView === 'studio' ? 'text-white font-semibold' : ''
          }`}
        >
          Avatar Studio
        </button>

        <button
          onClick={() => onSelectView('overlay')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeView === 'overlay' ? 'text-white font-semibold' : ''
          }`}
        >
          Floating Overlay
        </button>

        <button
          onClick={() => onSelectView('settings')}
          className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
            activeView === 'settings' ? 'text-white font-semibold' : ''
          }`}
        >
          Settings
        </button>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onOpenVoice}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-violet-600 hover:bg-violet-500 rounded-xl shadow-md shadow-violet-600/30 active:scale-95 transition-all whitespace-nowrap shrink-0"
        >
          <Mic className="w-3.5 h-3.5" />
          <span>Launch Voice</span>
        </button>
      </div>
    </header>
  );
};
