import React, { useState } from 'react';
import { MoreVertical, Mic, Layers, Radio, Sparkles, Settings, Trash2, Volume2 } from 'lucide-react';

interface CleanHeaderProps {
  overlayOn: boolean;
  wakeOn: boolean;
  voiceSource: 'gemini' | 'cartesia';
  onToggleVoiceSource: () => void;
  onVoice: () => void;
  onToggleOverlay: () => void;
  onToggleWake: () => void;
  onStudio: () => void;
  onSettings: () => void;
  onClear: () => void;
}

const Row: React.FC<{
  icon: React.ReactNode;
  label: string;
  hint?: string;
  on?: boolean;
  onClick: () => void;
}> = ({ icon, label, hint, on, onClick }) => (
  <button
    onClick={onClick}
    className="flex items-center gap-3 w-full px-4 py-3 text-left hover:bg-slate-800/80 active:bg-slate-800 transition-colors"
  >
    <span className="text-violet-400 shrink-0">{icon}</span>
    <span className="flex-1 min-w-0">
      <span className="block text-sm text-slate-100">{label}</span>
      {hint && <span className="block text-[11px] text-slate-500">{hint}</span>}
    </span>
    {on !== undefined && (
      <span
        className={`shrink-0 w-9 h-5 rounded-full p-0.5 transition-colors ${on ? 'bg-violet-600' : 'bg-slate-700'}`}
      >
        <span
          className={`block w-4 h-4 rounded-full bg-white transition-transform ${on ? 'translate-x-4' : 'translate-x-0'}`}
        />
      </span>
    )}
  </button>
);

export const CleanHeader: React.FC<CleanHeaderProps> = (p) => {
  const [open, setOpen] = useState(false);
  const run = (fn: () => void) => () => {
    setOpen(false);
    fn();
  };

  return (
    <header className="relative shrink-0 flex items-center justify-between px-4 py-3 bg-[#0b0d10] z-30">
      <span className="text-lg font-bold tracking-tight font-display bg-gradient-to-r from-white via-slate-200 to-violet-400 bg-clip-text text-transparent">
        AFRA
      </span>

      <button
        onClick={() => setOpen((o) => !o)}
        className="p-2 -mr-2 rounded-full text-slate-300 hover:bg-slate-800/70 active:bg-slate-800"
        aria-label="মেনু"
      >
        <MoreVertical className="w-5 h-5" />
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-3 top-12 z-50 w-72 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl shadow-black/60 overflow-hidden py-1">
            <Row icon={<Mic className="w-4 h-4" />} label="ভয়েস মোড" hint="কথা বলে কথোপকথন" onClick={run(p.onVoice)} />
            <Row
              icon={<Layers className="w-4 h-4" />}
              label="স্ক্রিনে ভাসমান অবতার"
              hint="সবসময় সামনে থাকবে"
              on={p.overlayOn}
              onClick={run(p.onToggleOverlay)}
            />
            <Row
              icon={<Radio className="w-4 h-4" />}
              label="“হ্যালো আফরা” শোনা"
              hint="ব্যাকগ্রাউন্ডে নাম ডাকলে জাগবে"
              on={p.wakeOn}
              onClick={run(p.onToggleWake)}
            />
            <Row
              icon={<Volume2 className="w-4 h-4" />}
              label={`ভয়েস: ${p.voiceSource === 'cartesia' ? 'Cartesia' : 'Google (Gemini)'}`}
              hint="বদলাতে চাপুন"
              onClick={run(p.onToggleVoiceSource)}
            />
            <div className="my-1 border-t border-slate-800" />
            <Row icon={<Sparkles className="w-4 h-4" />} label="অবতার বদলান" onClick={run(p.onStudio)} />
            <Row icon={<Settings className="w-4 h-4" />} label="সেটিংস" hint="API Key, ভয়েস, ডাক-নাম" onClick={run(p.onSettings)} />
            <Row icon={<Trash2 className="w-4 h-4" />} label="চ্যাট মুছুন" onClick={run(p.onClear)} />
          </div>
        </>
      )}
    </header>
  );
};
