import { MessageSquare, Grid, Mic, Sliders, Layers } from 'lucide-react';

interface MobileTabBarProps {
  activeView: 'chat' | 'studio' | 'overlay' | 'settings';
  onSelectView: (view: 'chat' | 'studio' | 'overlay' | 'settings') => void;
  onOpenVoice: () => void;
}

export const MobileTabBar: React.FC<MobileTabBarProps> = ({
  activeView,
  onSelectView,
  onOpenVoice,
}) => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#07090c]/90 backdrop-blur-xl border-t border-slate-800/80 px-4 py-2 pb-safe">
      <div className="flex items-center justify-around max-w-md mx-auto h-14">
        {/* Chat Tab */}
        <button
          onClick={() => onSelectView('chat')}
          className={`min-h-[44px] min-w-[44px] flex flex-col items-center justify-center transition-colors ${
            activeView === 'chat' ? 'text-violet-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <MessageSquare className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Chat</span>
        </button>

        {/* Studio Tab */}
        <button
          onClick={() => onSelectView('studio')}
          className={`min-h-[44px] min-w-[44px] flex flex-col items-center justify-center transition-colors ${
            activeView === 'studio' ? 'text-violet-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Grid className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Studio</span>
        </button>

        {/* Center Floating Voice Action */}
        <button
          onClick={onOpenVoice}
          className="min-h-[48px] min-w-[48px] -mt-5 flex items-center justify-center rounded-full bg-violet-600 text-white shadow-lg shadow-violet-600/40 border-2 border-[#07090c] active:scale-95 transition-transform"
          title="Voice Assistant"
        >
          <Mic className="w-5 h-5" />
        </button>

        {/* Overlay Tab */}
        <button
          onClick={() => onSelectView('overlay')}
          className={`min-h-[44px] min-w-[44px] flex flex-col items-center justify-center transition-colors ${
            activeView === 'overlay' ? 'text-violet-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Overlay</span>
        </button>

        {/* Settings Tab */}
        <button
          onClick={() => onSelectView('settings')}
          className={`min-h-[44px] min-w-[44px] flex flex-col items-center justify-center transition-colors ${
            activeView === 'settings' ? 'text-violet-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sliders className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1">Settings</span>
        </button>
      </div>
    </div>
  );
};
