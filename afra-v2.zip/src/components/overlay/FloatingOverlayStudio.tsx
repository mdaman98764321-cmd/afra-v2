import React, { useState, useEffect, useRef } from 'react';
import { useAvatarEngine } from '../../context/AvatarEngineContext';
import { useConversation } from '../../context/ConversationContext';
import { useSettings } from '../../context/SettingsContext';
import { AvatarRenderer } from '../avatar/AvatarRenderer';
import { ChatApiService } from '../../services/chatApi';
import { ApiKeyStorage } from '../../services/apiKeyStorage';
import {
  KOTLIN_OVERLAY_SERVICE_CODE,
  KOTLIN_OVERLAY_VIEW_CODE,
  KOTLIN_QUICK_ACTION_MENU_CODE,
  KOTLIN_PERMISSION_HELPER_CODE,
  KOTLIN_BRIDGE_CODE,
  ANDROID_MANIFEST_SNIPPET,
  PACKAGING_INSTRUCTIONS,
} from '../../services/androidBridgeSpec';
import {
  Layers,
  Smartphone,
  Check,
  Copy,
  ExternalLink,
  ShieldCheck,
  Mic,
  MicOff,
  MessageSquare,
  X,
  Send,
  RefreshCw,
  Sparkles,
  Sliders,
  AlertCircle,
  Eye,
  EyeOff,
  Minimize2,
  Maximize2,
  Volume2,
} from 'lucide-react';
import { AvatarState } from '../../types';

interface FloatingOverlayStudioProps {
  onNavigateToChat: () => void;
}

export const FloatingOverlayStudio: React.FC<FloatingOverlayStudioProps> = ({
  onNavigateToChat,
}) => {
  const { activeAvatar, avatarState, audioLevel, setAvatarState, setAudioLevel } = useAvatarEngine();
  const { startVoiceListening, stopVoiceListening, isListening } = useConversation();
  const { settings } = useSettings();

  // Overlay state
  const [isOverlayActive, setIsOverlayActive] = useState<boolean>(true);
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
  const [isQuickInputOpen, setIsQuickInputOpen] = useState<boolean>(false);
  const [quickQueryText, setQuickQueryText] = useState<string>('');
  const [quickQueryResponse, setQuickQueryResponse] = useState<string>('');
  const [isStreamingQuickQuery, setIsStreamingQuickQuery] = useState<boolean>(false);
  const [quickQueryError, setQuickQueryError] = useState<string | null>(null);

  // Position state (within 360x640 mobile preview container)
  const [overlayPos, setOverlayPos] = useState<{ x: number; y: number }>(() => {
    try {
      const saved = localStorage.getItem('afra_overlay_pos_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return { x: 290, y: 220 };
  });

  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragStartRef = useRef<{ startX: number; startY: number; initialX: number; initialY: number; moved: boolean }>({
    startX: 0,
    startY: 0,
    initialX: 0,
    initialY: 0,
    moved: false,
  });

  // Simulated background app
  const [simulatedBackground, setSimulatedBackground] = useState<'home' | 'browser' | 'maps' | 'notes'>('home');

  // Simulated permissions
  const [systemAlertGranted, setSystemAlertGranted] = useState<boolean>(true);
  const [notificationGranted, setNotificationGranted] = useState<boolean>(true);

  // Code inspection tab
  const [activeCodeTab, setActiveCodeTab] = useState<
    'service' | 'view' | 'menu' | 'permission' | 'bridge' | 'manifest' | 'packaging'
  >('service');
  const [copiedTab, setCopiedTab] = useState<string | null>(null);

  // Save pos
  useEffect(() => {
    localStorage.setItem('afra_overlay_pos_v1', JSON.stringify(overlayPos));
  }, [overlayPos]);

  const handlePointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    setIsDragging(true);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialX: overlayPos.x,
      initialY: overlayPos.y,
      moved: false,
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const deltaX = e.clientX - dragStartRef.current.startX;
    const deltaY = e.clientY - dragStartRef.current.startY;

    if (Math.abs(deltaX) > 4 || Math.abs(deltaY) > 4) {
      dragStartRef.current.moved = true;
      setIsMenuOpen(false);
    }

    // Boundary constraints within simulated 360x600 phone viewport
    const newX = Math.max(8, Math.min(296, dragStartRef.current.initialX + deltaX));
    const newY = Math.max(36, Math.min(530, dragStartRef.current.initialY + deltaY));

    setOverlayPos({ x: newX, y: newY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setIsDragging(false);
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch (err) {}

    // If moved very little, treat as tap
    if (!dragStartRef.current.moved) {
      setIsMenuOpen((prev) => !prev);
    } else {
      // Snap to nearest edge (left or right)
      const targetX = overlayPos.x < 150 ? 12 : 292;
      setOverlayPos((prev) => ({ ...prev, x: targetX }));
    }
  };

  const handleSendQuickQuery = async () => {
    const q = quickQueryText.trim();
    if (!q || isStreamingQuickQuery) return;

    setIsStreamingQuickQuery(true);
    setQuickQueryError(null);
    setQuickQueryResponse('');
    setAvatarState('thinking');

    try {
      await ChatApiService.sendMessageStream({
        message: q,
        history: [],
        persona: settings.customPersona,
        mode: settings.personaMode,
        onChunk: (chunk) => {
          setAvatarState('speaking');
          setQuickQueryResponse((prev) => prev + chunk);
        },
        onComplete: (full) => {
          setAvatarState('idle');
          setIsStreamingQuickQuery(false);
          setQuickQueryResponse(full);
        },
        onError: (err) => {
          setAvatarState('error');
          setIsStreamingQuickQuery(false);
          setQuickQueryError(err);
        },
      });
    } catch (err: any) {
      setAvatarState('error');
      setIsStreamingQuickQuery(false);
      setQuickQueryError(err?.message || 'Quick query failed');
    }
  };

  const handleCopyCode = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTab(key);
    setTimeout(() => setCopiedTab(null), 2000);
  };

  const getActiveCode = () => {
    switch (activeCodeTab) {
      case 'service':
        return KOTLIN_OVERLAY_SERVICE_CODE;
      case 'view':
        return KOTLIN_OVERLAY_VIEW_CODE;
      case 'menu':
        return KOTLIN_QUICK_ACTION_MENU_CODE;
      case 'permission':
        return KOTLIN_PERMISSION_HELPER_CODE;
      case 'bridge':
        return KOTLIN_BRIDGE_CODE;
      case 'manifest':
        return ANDROID_MANIFEST_SNIPPET;
      case 'packaging':
        return PACKAGING_INSTRUCTIONS;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-8 max-w-6xl mx-auto w-full">
      {/* Studio Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-semibold text-white font-display tracking-tight">
              Native Android Floating Overlay Studio
            </h2>
            <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/40 px-2 py-0.5 rounded-full">
              WindowManager TYPE_APPLICATION_OVERLAY
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Test and inspect AFRA's native Android foreground service overlay with edge-snapping physics, quick actions menu, mic privacy indicators, and Kotlin sources.
          </p>
        </div>

        {/* Start / Stop Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsOverlayActive(!isOverlayActive)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all shadow-md ${
              isOverlayActive
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/20'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{isOverlayActive ? 'Overlay Service Running' : 'Start Overlay Service'}</span>
          </button>
        </div>
      </div>

      {/* Main Split: Interactive Phone Simulator vs Configuration & Code */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Simulated Android Device Viewport (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="w-full max-w-[360px] flex flex-col items-center">
            {/* Phone Frame */}
            <div className="w-full h-[640px] rounded-[36px] bg-black p-3 shadow-2xl border-4 border-slate-700/80 relative flex flex-col overflow-hidden select-none">
              {/* Speaker Notch */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-4 bg-slate-900 rounded-full z-30 flex items-center justify-center">
                <div className="w-10 h-1 bg-slate-700 rounded-full" />
              </div>

              {/* Screen Area */}
              <div className="relative w-full h-full rounded-[28px] overflow-hidden bg-[#0a0d14] flex flex-col">
                {/* Android Status Bar */}
                <div className="shrink-0 h-7 bg-black/60 backdrop-blur-sm px-4 flex items-center justify-between text-[10px] text-slate-300 font-mono z-20">
                  <span>10:42</span>
                  <div className="flex items-center gap-1.5">
                    {isListening && (
                      <span className="flex items-center gap-1 text-emerald-400 font-sans text-[9px] bg-emerald-950/80 px-1.5 py-0.2 rounded-full border border-emerald-600/40">
                        <Mic className="w-2.5 h-2.5 animate-pulse" />
                        <span>Mic</span>
                      </span>
                    )}
                    <span>5G</span>
                    <span>94%</span>
                  </div>
                </div>

                {/* Persistent Android Foreground Notification Banner */}
                {isOverlayActive && notificationGranted && (
                  <div className="shrink-0 bg-slate-900/90 border-b border-slate-800 px-3 py-1.5 flex items-center justify-between text-[11px] text-slate-300 z-20">
                    <div className="flex items-center gap-2 truncate">
                      <div className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />
                      <span className="truncate">
                        {isListening ? (
                          <strong className="text-cyan-400">AFRA Listening (Mic Active)</strong>
                        ) : (
                          'AFRA Floating Overlay Active'
                        )}
                      </span>
                    </div>
                    <button
                      onClick={() => setIsOverlayActive(false)}
                      className="text-[10px] text-rose-400 hover:text-rose-300 ml-2 shrink-0 font-medium"
                    >
                      Stop
                    </button>
                  </div>
                )}

                {/* Background App Content Layer */}
                <div className="flex-1 relative overflow-hidden flex flex-col">
                  {simulatedBackground === 'home' && (
                    <div className="w-full h-full flex flex-col justify-between p-6 bg-gradient-to-b from-slate-950 via-[#101520] to-[#0a0d14]">
                      <div className="pt-8 text-center">
                        <div className="text-4xl font-light text-slate-100 font-mono">10:42</div>
                        <div className="text-xs text-slate-400 mt-1">Thursday, Nov 6 • 24°C</div>
                      </div>

                      {/* App Grid */}
                      <div className="grid grid-cols-4 gap-4 mb-4">
                        {['Browser', 'Maps', 'Notes', 'Settings'].map((app, i) => (
                          <button
                            key={app}
                            onClick={() =>
                              setSimulatedBackground(
                                app === 'Browser' ? 'browser' : app === 'Maps' ? 'maps' : 'notes'
                              )
                            }
                            className="flex flex-col items-center gap-1.5"
                          >
                            <div className="w-12 h-12 rounded-2xl bg-slate-800/80 border border-slate-700/60 flex items-center justify-center text-xs text-slate-300 font-semibold shadow-md active:scale-95 transition-transform">
                              {app[0]}
                            </div>
                            <span className="text-[10px] text-slate-400">{app}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {simulatedBackground === 'browser' && (
                    <div className="w-full h-full p-4 bg-slate-950 text-slate-300 flex flex-col">
                      <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-[10px] text-slate-400 flex items-center justify-between mb-3 font-mono">
                        <span>https://wikipedia.org/wiki/Quantum_computing</span>
                        <X
                          className="w-3 h-3 cursor-pointer"
                          onClick={() => setSimulatedBackground('home')}
                        />
                      </div>
                      <div className="space-y-2 text-xs text-slate-400 leading-relaxed overflow-y-auto">
                        <h4 className="text-sm font-semibold text-white">Quantum Computing</h4>
                        <p>
                          A quantum computer is a computer that exploits quantum mechanical phenomena such as superposition and entanglement...
                        </p>
                        <p>
                          Notice that AFRA's floating avatar remains effortlessly operable on top of this browser viewport!
                        </p>
                      </div>
                    </div>
                  )}

                  {simulatedBackground === 'maps' && (
                    <div className="w-full h-full bg-[#111923] p-4 text-slate-300 flex flex-col justify-between">
                      <div className="flex items-center justify-between p-2 rounded-xl bg-slate-900/90 border border-slate-800 text-xs">
                        <span>Navigation: Downtown Route</span>
                        <X
                          className="w-3.5 h-3.5 cursor-pointer"
                          onClick={() => setSimulatedBackground('home')}
                        />
                      </div>
                      <div className="text-center text-slate-500 text-xs">
                        [ Simulated Live Map Surface ]
                      </div>
                      <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 text-xs">
                        In 300 meters, turn right on Grand Avenue
                      </div>
                    </div>
                  )}

                  {simulatedBackground === 'notes' && (
                    <div className="w-full h-full bg-[#0c0e12] p-4 text-slate-300 flex flex-col">
                      <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs mb-3">
                        <span className="font-semibold text-white">Executive Project Brief</span>
                        <X
                          className="w-3.5 h-3.5 cursor-pointer"
                          onClick={() => setSimulatedBackground('home')}
                        />
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        1. Deploy AFRA Floating Overlay Service<br />
                        2. Verify WindowManager TYPE_APPLICATION_OVERLAY<br />
                        3. Review edge-snapping and microphone privacy.
                      </p>
                    </div>
                  )}

                  {/* FLOATING OVERLAY AVATAR (56dp WindowManager Layer) */}
                  {isOverlayActive && (
                    <div
                      className="absolute z-40 touch-none cursor-grab active:cursor-grabbing"
                      style={{
                        left: `${overlayPos.x}px`,
                        top: `${overlayPos.y}px`,
                        transition: isDragging ? 'none' : 'left 0.25s cubic-bezier(0.16, 1, 0.3, 1)',
                      }}
                      onPointerDown={handlePointerDown}
                      onPointerMove={handlePointerMove}
                      onPointerUp={handlePointerUp}
                    >
                      {/* 56dp Circular Avatar */}
                      <div className="relative">
                        <AvatarRenderer
                          avatar={activeAvatar}
                          state={avatarState}
                          audioLevel={audioLevel}
                          size="sm"
                          showHalo={true}
                        />

                        {/* Mic Privacy Badge */}
                        {isListening && (
                          <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan-500 border-2 border-black flex items-center justify-center animate-pulse">
                            <Mic className="w-2.5 h-2.5 text-black" />
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* QUICK ACTION MENU POPUP (Adjacent to Avatar) */}
                  {isOverlayActive && isMenuOpen && (
                    <div
                      className="absolute z-50 w-52 p-3 rounded-2xl bg-[#0e1217]/95 border border-slate-800 shadow-2xl backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150"
                      style={{
                        left: overlayPos.x > 150 ? `${Math.max(12, overlayPos.x - 216)}px` : `${overlayPos.x + 64}px`,
                        top: `${Math.max(48, Math.min(380, overlayPos.y - 40))}px`,
                      }}
                    >
                      <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                        <span className="text-xs font-semibold text-white font-display">
                          AFRA Quick Menu
                        </span>
                        <button
                          onClick={() => setIsMenuOpen(false)}
                          className="p-1 text-slate-500 hover:text-slate-300"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>

                      <div className="space-y-1 text-xs">
                        <button
                          onClick={() => {
                            setIsMenuOpen(false);
                            onNavigateToChat();
                          }}
                          className="w-full flex items-center gap-2 p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-violet-300 font-medium transition-colors text-left"
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-violet-400" />
                          <span>Open Afra Chat</span>
                        </button>

                        <button
                          onClick={() => {
                            setIsMenuOpen(false);
                            if (isListening) {
                              stopVoiceListening();
                              setAvatarState('idle');
                            } else {
                              startVoiceListening();
                              setAvatarState('listening');
                            }
                          }}
                          className="w-full flex items-center gap-2 p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-cyan-300 font-medium transition-colors text-left"
                        >
                          <Mic className="w-3.5 h-3.5 text-cyan-400" />
                          <span>{isListening ? 'Stop Voice Mode' : 'Start Voice Mode'}</span>
                        </button>

                        <button
                          onClick={() => {
                            setIsMenuOpen(false);
                            setIsQuickInputOpen(true);
                          }}
                          className="w-full flex items-center gap-2 p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-200 font-medium transition-colors text-left"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-slate-400" />
                          <span>Quick Message</span>
                        </button>

                        <button
                          onClick={() => {
                            setIsMenuOpen(false);
                            onNavigateToChat();
                          }}
                          className="w-full flex items-center gap-2 p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors text-left"
                        >
                          <Maximize2 className="w-3.5 h-3.5" />
                          <span>Return to Full App</span>
                        </button>

                        <button
                          onClick={() => {
                            setIsMenuOpen(false);
                            setIsOverlayActive(false);
                          }}
                          className="w-full flex items-center gap-2 p-2 rounded-xl bg-slate-900/80 hover:bg-rose-950/40 text-rose-400 transition-colors text-left"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>Close Floating Assistant</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* QUICK MESSAGE INLINE MODAL OVERLAY */}
                  {isQuickInputOpen && (
                    <div className="absolute inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
                      <div className="w-full max-w-[280px] p-4 rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-white font-display">
                            Quick Query to AFRA
                          </span>
                          <button
                            onClick={() => {
                              setIsQuickInputOpen(false);
                              setQuickQueryResponse('');
                              setQuickQueryError(null);
                            }}
                            className="text-slate-400 hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="relative">
                          <input
                            type="text"
                            value={quickQueryText}
                            onChange={(e) => setQuickQueryText(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSendQuickQuery()}
                            placeholder="Ask a quick question..."
                            className="w-full pl-3 pr-8 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-violet-500"
                          />
                          <button
                            onClick={handleSendQuickQuery}
                            disabled={!quickQueryText.trim() || isStreamingQuickQuery}
                            className="absolute right-2 top-2 text-violet-400 disabled:opacity-40"
                          >
                            <Send className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Streamed response */}
                        {quickQueryResponse && (
                          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-300 max-h-36 overflow-y-auto leading-relaxed">
                            {quickQueryResponse}
                          </div>
                        )}

                        {quickQueryError && (
                          <div className="p-2 rounded-xl bg-rose-950/40 border border-rose-900/50 text-[11px] text-rose-300">
                            {quickQueryError}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Simulated Android Navigation Bar */}
                <div className="shrink-0 h-6 bg-black flex items-center justify-center gap-8">
                  <div className="w-3 h-3 border-2 border-slate-600 rounded-sm" />
                  <div className="w-3 h-3 rounded-full border-2 border-slate-600" />
                  <div className="w-0 h-0 border-y-4 border-y-transparent border-r-6 border-r-slate-600" />
                </div>
              </div>
            </div>

            {/* Background App Switcher Controls */}
            <div className="w-full flex items-center justify-center gap-1.5 mt-3">
              <span className="text-[11px] text-slate-500">Test Background App:</span>
              {(['home', 'browser', 'maps', 'notes'] as const).map((app) => (
                <button
                  key={app}
                  onClick={() => setSimulatedBackground(app)}
                  className={`px-2 py-0.5 rounded-md text-[10px] font-medium capitalize transition-colors ${
                    simulatedBackground === app
                      ? 'bg-slate-700 text-white'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {app}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Technical Architecture, Permissions & Code Inspector (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Permission & Android Compliance Card */}
          <div className="p-5 rounded-3xl bg-slate-900/60 border border-slate-800/80 space-y-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-semibold text-slate-200 font-display">
                Android System Overlay & Privacy Compliance
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-white">SYSTEM_ALERT_WINDOW</span>
                  <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-2 py-0.5 rounded-full">
                    Granted
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Allows drawing the 56dp floating avatar above all third-party applications via WindowManager.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-white">Android 14+ FGS Compliance</span>
                  <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/40 px-2 py-0.5 rounded-full">
                    specialUse
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Foreground service with persistent notification preventing Android 12+ background execution termination.
                </p>
              </div>
            </div>

            {/* Privacy Guarantee */}
            <div className="p-3 rounded-2xl bg-slate-950/40 border border-slate-800/70 text-xs text-slate-400 space-y-1">
              <div className="flex items-center gap-1.5 text-slate-300 font-medium">
                <Mic className="w-3.5 h-3.5 text-cyan-400" />
                <span>Zero Background Microphone Access</span>
              </div>
              <p className="text-[11px] leading-relaxed">
                Microphone sessions are never started automatically. Audio recording is strictly initiated when the user explicitly triggers "Start Voice Mode", and immediately ceased upon finishing.
              </p>
            </div>
          </div>

          {/* Native Kotlin Code Inspector */}
          <div className="p-5 rounded-3xl bg-slate-900/60 border border-slate-800/80 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-violet-400" />
                <h3 className="text-sm font-semibold text-slate-200 font-display">
                  Native Android Kotlin Sources & APK Packaging
                </h3>
              </div>

              <button
                onClick={() => handleCopyCode(activeCodeTab, getActiveCode())}
                className="flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors w-fit"
              >
                {copiedTab === activeCodeTab ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy File</span>
                  </>
                )}
              </button>
            </div>

            {/* Tab Bar */}
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                { id: 'service', label: 'AfraOverlayService.kt' },
                { id: 'view', label: 'AfraOverlayView.kt' },
                { id: 'menu', label: 'QuickActionMenu.kt' },
                { id: 'permission', label: 'OverlayPermissionHelper.kt' },
                { id: 'bridge', label: 'AfraNativeBridge.kt' },
                { id: 'manifest', label: 'AndroidManifest.xml' },
                { id: 'packaging', label: 'Packaging Guide' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveCodeTab(tab.id as any)}
                  className={`px-2.5 py-1 text-xs rounded-lg transition-colors font-mono ${
                    activeCodeTab === tab.id
                      ? 'bg-slate-800 text-white border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Code Viewer */}
            <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed max-h-96">
              {getActiveCode()}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
