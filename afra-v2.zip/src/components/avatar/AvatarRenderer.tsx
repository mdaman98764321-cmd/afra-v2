import React, { useEffect, useRef, useState } from 'react';
import { AvatarItem, AvatarState } from '../../types';
import { SandboxIframe } from './SandboxIframe';
import { Sparkles, Activity } from 'lucide-react';

interface AvatarRendererProps {
  avatar: AvatarItem;
  state: AvatarState;
  audioLevel?: number;
  size?: 'sm' | 'md' | 'lg' | 'hero' | 'fullscreen';
  showHalo?: boolean;
  className?: string;
}

export const AvatarRenderer: React.FC<AvatarRendererProps> = ({
  avatar,
  state,
  audioLevel = 0,
  size = 'md',
  showHalo = true,
  className = '',
}) => {
  const [imageError, setImageError] = useState(false);
  const [chibiMode, setChibiMode] = useState<'idle' | 'drag' | 'tap'>('idle');
  const [chibiFrame, setChibiFrame] = useState(0);
  const pointerStart = useRef<{x:number;y:number}|null>(null);

  useEffect(() => {
    if (avatar.id !== 'afra-red-chibi') return;
    const delays = chibiMode === 'idle' ? 650 : chibiMode === 'drag' ? 170 : 190;
    const timer = window.setInterval(() => {
      setChibiFrame((frame) => (frame + 1) % 4);
    }, delays);
    return () => window.clearInterval(timer);
  }, [avatar.id, chibiMode]);

  const handleChibiPointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (avatar.id !== 'afra-red-chibi') return;
    pointerStart.current = { x: event.clientX, y: event.clientY };
    setChibiMode('drag');
    setChibiFrame(0);
  };
  const handleChibiPointerUp = (event: React.PointerEvent<HTMLDivElement>) => {
    if (avatar.id !== 'afra-red-chibi' || !pointerStart.current) return;
    const dx = event.clientX - pointerStart.current.x;
    const dy = event.clientY - pointerStart.current.y;
    const wasTap = Math.hypot(dx, dy) < 9;
    pointerStart.current = null;
    if (wasTap) {
      setChibiMode('tap');
      setChibiFrame(0);
      window.setTimeout(() => setChibiMode('idle'), 850);
    } else {
      setChibiMode('idle');
      setChibiFrame(0);
    }
  };


  // Dimension classes based on size variant
  let dimensionClass = 'w-36 h-36';
  let innerSize = 'w-36 h-36';
  if (size === 'sm') {
    dimensionClass = 'w-14 h-14';
    innerSize = 'w-14 h-14';
  } else if (size === 'md') {
    dimensionClass = 'w-44 h-44 sm:w-52 sm:h-52';
    innerSize = 'w-44 h-44 sm:w-52 sm:h-52';
  } else if (size === 'lg') {
    dimensionClass = 'w-64 h-64 sm:w-72 sm:h-72';
    innerSize = 'w-64 h-64 sm:w-72 sm:h-72';
  } else if (size === 'hero') {
    dimensionClass = 'w-72 h-72 sm:w-88 sm:h-88 md:w-96 md:h-96';
    innerSize = 'w-72 h-72 sm:w-88 sm:h-88 md:w-96 md:h-96';
  } else if (size === 'fullscreen') {
    dimensionClass = 'w-72 h-72 sm:w-96 sm:h-96 md:w-[420px] md:h-[420px]';
    innerSize = 'w-72 h-72 sm:w-96 sm:h-96 md:w-[420px] md:h-[420px]';
  }

  // Dynamic state styles
  const isSpeaking = state === 'speaking';
  const isListening = state === 'listening';
  const isThinking = state === 'thinking';
  const isHappy = state === 'happy';
  const isError = state === 'error';

  // Calculate dynamic scale factor based on speech amplitude
  const dynamicScale = isSpeaking
    ? 1 + audioLevel * 0.12
    : isListening
    ? 1 + audioLevel * 0.08
    : isHappy
    ? 1.06
    : 1;

  // State halo colors
  let haloGlowColor = avatar.tintColor || '#8b5cf6';
  if (isListening) haloGlowColor = '#06b6d4'; // Cyan for listening
  if (isThinking) haloGlowColor = '#a855f7'; // Deep violet for thinking
  if (isHappy) haloGlowColor = '#10b981'; // Emerald for happy
  if (isError) haloGlowColor = '#f43f5e'; // Rose for error

  return (
    <div
      className={`relative flex items-center justify-center select-none ${dimensionClass} ${className}`}
      onPointerDown={handleChibiPointerDown}
      onPointerUp={handleChibiPointerUp}
      onPointerCancel={() => { pointerStart.current = null; setChibiMode('idle'); }}
      style={{
        transform: `scale(${dynamicScale * (avatar.scaleFactor || 1)})`,
        transition: 'transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)',
      }}
    >
      {/* Outer Glow Halo */}
      {showHalo && (
        <div
          className="absolute inset-0 rounded-full pointer-events-none transition-all duration-300"
          style={{
            background: `radial-gradient(circle, ${haloGlowColor}33 0%, ${haloGlowColor}00 70%)`,
            transform: `scale(${1.25 + (isSpeaking ? audioLevel * 0.35 : 0)})`,
            filter: 'blur(16px)',
          }}
        />
      )}

      {/* Orbiting Thinking Ring */}
      {isThinking && (
        <div
          className="absolute -inset-3 rounded-full border border-violet-400/40 pointer-events-none animate-spin"
          style={{
            borderTopColor: '#c084fc',
            borderRightColor: 'transparent',
            animationDuration: '1.4s',
          }}
        />
      )}

      {/* Listening Pulse Waves */}
      {isListening && (
        <>
          <div
            className="absolute -inset-2 rounded-full border border-cyan-400/50 pointer-events-none animate-ping"
            style={{ animationDuration: '2s' }}
          />
          <div
            className="absolute -inset-4 rounded-full border border-cyan-500/20 pointer-events-none"
            style={{
              transform: `scale(${1 + audioLevel * 0.25})`,
              transition: 'transform 0.1s ease-out',
            }}
          />
        </>
      )}

      {/* Main Avatar Container */}
      <div
        className={`relative ${innerSize} rounded-full overflow-hidden border border-slate-700/60 shadow-2xl bg-[#0b0d10] flex items-center justify-center transition-all duration-300`}
        style={{
          boxShadow: `0 0 ${20 * (avatar.glowIntensity || 0.8)}px ${haloGlowColor}40`,
        }}
      >
        {avatar.id === 'afra-red-chibi' ? (
          <div className="w-full h-full flex items-center justify-center overflow-visible bg-transparent">
            <img
              key={`${chibiMode}-${chibiFrame}`}
              src={`/src/assets/images/afra_red_chibi_${chibiMode}_${chibiFrame + 1}.png`}
              alt="Afra red-haired chibi avatar"
              draggable={false}
              className="w-full h-full object-contain pointer-events-none"
              style={{ filter: isThinking ? 'brightness(1.04)' : 'none', transform: chibiMode === 'drag' ? 'rotate(-5deg)' : 'none', transition: 'transform 160ms ease-out' }}
            />
          </div>
        ) : avatar.type === 'code' ? (
          <SandboxIframe
            codeHtml={avatar.codeHtml}
            codeCss={avatar.codeCss}
            codeJs={avatar.codeJs}
            bundledCode={avatar.bundledCode}
            state={state}
            audioLevel={audioLevel}
            tintColor={avatar.tintColor}
            className="w-full h-full"
          />
        ) : !imageError && avatar.imageUrl ? (
          <div className="relative w-full h-full">
            <img
              src={avatar.imageUrl}
              alt={avatar.name}
              referrerPolicy="no-referrer"
              onError={() => setImageError(true)}
              className="w-full h-full object-cover object-center transition-transform duration-500"
              style={{
                filter: isThinking
                  ? 'brightness(1.08) contrast(1.05)'
                  : isSpeaking
                  ? `brightness(${1 + audioLevel * 0.2}) contrast(1.04)`
                  : 'none',
              }}
            />
            {/* Gloss Rim Gradient Overlay */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-t from-black/50 via-transparent to-white/10 pointer-events-none" />
          </div>
        ) : (
          /* Zero-Broken-Image Policy Fallback Container */
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 to-[#0e1217] text-slate-300 p-4 text-center">
            <Activity className="w-8 h-8 text-violet-400 mb-2 animate-pulse" />
            <span className="text-xs font-semibold tracking-wide text-white font-display">
              {avatar.name}
            </span>
            <span className="text-[10px] text-slate-500 mt-0.5">Synthetic Core</span>
          </div>
        )}
      </div>
    </div>
  );
};
