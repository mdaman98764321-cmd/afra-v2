import React, { useState } from 'react';
import { AvatarItem, AvatarState } from '../../types';
import { SandboxIframe } from './SandboxIframe';
import { Sparkles, Activity } from 'lucide-react';

interface AvatarRendererProps {
  avatar: AvatarItem;
  state: AvatarState;
  audioLevel?: number;
  size?: 'sm' | 'md' | 'lg' | 'hero' | 'fullscreen';
  showHalo?: boolean;
  className?: string;
  interaction?: 'idle' | 'dragging' | 'tapped';
}

export const AvatarRenderer: React.FC<AvatarRendererProps> = ({
  avatar,
  state,
  audioLevel = 0,
  size = 'md',
  showHalo = true,
  className = '',
  interaction = 'idle',
}) => {
  const [imageError, setImageError] = useState(false);

  // Dimension classes based on size variant
  let dimensionClass = 'w-36 h-36';
  let innerSize = 'w-36 h-36';
  if (size === 'sm') {
    dimensionClass = 'w-14 h-14';
    innerSize = 'w-14 h-14';
  } else if (size === 'md') {
    dimensionClass = 'w-44 h-44 sm:w-52 sm:h-52';
    innerSize = 'w-44 h-44 sm:w-52 sm:h-52';
  } else if (size === 'lg') {
    dimensionClass = 'w-64 h-64 sm:w-72 sm:h-72';
    innerSize = 'w-64 h-64 sm:w-72 sm:h-72';
  } else if (size === 'hero') {
    dimensionClass = 'w-72 h-72 sm:w-88 sm:h-88 md:w-96 md:h-96';
    innerSize = 'w-72 h-72 sm:w-88 sm:h-88 md:w-96 md:h-96';
  } else if (size === 'fullscreen') {
    dimensionClass = 'w-72 h-72 sm:w-96 sm:h-96 md:w-[420px] md:h-[420px]';
    innerSize = 'w-72 h-72 sm:w-96 sm:h-96 md:w-[420px] md:h-[420px]';
  }

  // Dynamic state styles
  const isSpeaking = state === 'speaking';
  const isListening = state === 'listening';
  const isThinking = state === 'thinking';
  const isHappy = state === 'happy';
  const isError = state === 'error';
  const isRedChibi = avatar.id === 'afra-red-chibi';
  const spriteMode = interaction === 'dragging' ? 'drag' : interaction === 'tapped' || isHappy ? 'tap' : 'idle';

  // Calculate dynamic scale factor based on speech amplitude
  const dynamicScale = isSpeaking
    ? 1 + audioLevel * 0.12
    : isListening
    ? 1 + audioLevel * 0.08
    : isHappy
    ? 1.06
    : 1;

  // State halo colors
  let haloGlowColor = avatar.tintColor || '#8b5cf6';
  if (isListening) haloGlowColor = '#06b6d4'; // Cyan for listening
  if (isThinking) haloGlowColor = '#a855f7'; // Deep violet for thinking
  if (isHappy) haloGlowColor = '#10b981'; // Emerald for happy
  if (isError) haloGlowColor = '#f43f5e'; // Rose for error

  return (
    <div
      className={`relative flex items-center justify-center select-none ${dimensionClass} ${className}`}
      style={{
        transform: `scale(${dynamicScale * (avatar.scaleFactor || 1)})`,
        transition: 'transform 0.12s cubic-bezier(0.16, 1, 0.3, 1)',
      }}
    >
      {/* Outer Glow Halo */}
      {showHalo && (
        <div
          className="absolute inset-0 rounded-full pointer-events-none transition-all duration-300"
          style={{
            background: `radial-gradient(circle, ${haloGlowColor}33 0%, ${haloGlowColor}00 70%)`,
            transform: `scale(${1.25 + (isSpeaking ? audioLevel * 0.35 : 0)})`,
            filter: 'blur(16px)',
          }}
        />
      )}

      {/* Orbiting Thinking Ring */}
      {isThinking && (
        <div
          className="absolute -inset-3 rounded-full border border-violet-400/40 pointer-events-none animate-spin"
          style={{
            borderTopColor: '#c084fc',
            borderRightColor: 'transparent',
            animationDuration: '1.4s',
          }}
        />
      )}

      {/* Listening Pulse Waves */}
      {isListening && (
        <>
          <div
            className="absolute -inset-2 rounded-full border border-cyan-400/50 pointer-events-none animate-ping"
            style={{ animationDuration: '2s' }}
          />
          <div
            className="absolute -inset-4 rounded-full border border-cyan-500/20 pointer-events-none"
            style={{
              transform: `scale(${1 + audioLevel * 0.25})`,
              transition: 'transform 0.1s ease-out',
            }}
          />
        </>
      )}

      {/* Main Avatar Container */}
      <div
        className={`relative ${innerSize} ${isRedChibi ? 'overflow-visible border-0 bg-transparent shadow-none' : 'rounded-full overflow-hidden border border-slate-700/60 shadow-2xl bg-[#0b0d10]'} flex items-center justify-center transition-all duration-300`}
        style={{
          boxShadow: `0 0 ${20 * (avatar.glowIntensity || 0.8)}px ${haloGlowColor}40`,
        }}
      >
        {isRedChibi ? (
          <div className={`red-chibi-sprite red-chibi-${spriteMode}`} role="img" aria-label="Afra red-haired anime avatar" />
        ) : avatar.type === 'code' ? (
          <SandboxIframe
            codeHtml={avatar.codeHtml}
            codeCss={avatar.codeCss}
            codeJs={avatar.codeJs}
            bundledCode={avatar.bundledCode}
            state={state}
            audioLevel={audioLevel}
            tintColor={avatar.tintColor}
            className="w-full h-full"
          />
        ) : !imageError && avatar.imageUrl ? (
          <div className="relative w-full h-full">
            <img
              src={avatar.imageUrl}
              alt={avatar.name}
              referrerPolicy="no-referrer"
              onError={() => setImageError(true)}
              className="w-full h-full object-cover object-center transition-transform duration-500"
              style={{
                filter: isThinking
                  ? 'brightness(1.08) contrast(1.05)'
                  : isSpeaking
                  ? `brightness(${1 + audioLevel * 0.2}) contrast(1.04)`
                  : 'none',
              }}
            />
            {/* Gloss Rim Gradient Overlay */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-t from-black/50 via-transparent to-white/10 pointer-events-none" />
          </div>
        ) : (
          /* Zero-Broken-Image Policy Fallback Container */
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 to-[#0e1217] text-slate-300 p-4 text-center">
            <Activity className="w-8 h-8 text-violet-400 mb-2 animate-pulse" />
            <span className="text-xs font-semibold tracking-wide text-white font-display">
              {avatar.name}
            </span>
            <span className="text-[10px] text-slate-500 mt-0.5">Synthetic Core</span>
          </div>
        )}
      </div>
    </div>
  );
};
