import React, { useEffect, useState } from 'react';
import { Cartesia, CartesiaVoice } from '../../services/cartesia';
import { SpeechAudioService } from '../../services/speech';
import { Native } from '../../services/nativeBridge';
import { Volume2 } from 'lucide-react';

const PROFILES: Array<{ id: 'afra-soft' | 'afra-elegant' | 'afra-male'; label: string; want: 'f' | 'm' }> = [
  { id: 'afra-soft', label: 'কোমল নারী কণ্ঠ', want: 'f' },
  { id: 'afra-elegant', label: 'আত্মবিশ্বাসী নারী কণ্ঠ', want: 'f' },
  { id: 'afra-male', label: 'পুরুষ কণ্ঠ', want: 'm' },
];

const isFemale = (g: string) => /fem/i.test(g);
const isMale = (g: string) => !/fem/i.test(g) && /mas|male|man/i.test(g);

export const CartesiaVoiceSection: React.FC = () => {
  const [key, setKey] = useState<string>(() => Cartesia.getKey());
  const [voices, setVoices] = useState<CartesiaVoice[]>([]);
  const [chosen, setChosen] = useState<Record<string, string>>(() => ({
    'afra-soft': Cartesia.getVoice('afra-soft'),
    'afra-elegant': Cartesia.getVoice('afra-elegant'),
    'afra-male': Cartesia.getVoice('afra-male'),
  }));
  const [status, setStatus] = useState<string>('');
  const [busy, setBusy] = useState(false);

  const load = async () => {
    setBusy(true);
    setStatus('ভয়েসের তালিকা আনছি...');
    Cartesia.setKey(key);
    const r = await Cartesia.listVoices();
    setBusy(false);
    if (r.error || !r.voices) {
      setStatus(r.error || 'তালিকা আনা গেল না।');
      return;
    }
    setVoices(r.voices);
    setStatus(`${r.voices.length}টি ভয়েস পাওয়া গেছে। প্রতিটা কণ্ঠের জন্য একটা বেছে নিন।`);
    // sensible first choice if nothing was picked yet
    const next: Record<string, string> = { ...chosen };
    const females = r.voices.filter((v) => isFemale(v.gender));
    const males = r.voices.filter((v) => isMale(v.gender));
    if (!next['afra-soft'] && females[0]) next['afra-soft'] = females[0].id;
    if (!next['afra-elegant'] && (females[1] || females[0])) next['afra-elegant'] = (females[1] || females[0]).id;
    if (!next['afra-male'] && males[0]) next['afra-male'] = males[0].id;
    setChosen(next);
    Object.keys(next).forEach((p) => {
      const id = next[p];
      if (id) Cartesia.setVoice(p, id);
    });
  };

  useEffect(() => {
    if (Cartesia.getKey()) void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pick = (profile: string, id: string) => {
    setChosen((c) => ({ ...c, [profile]: id }));
    Cartesia.setVoice(profile, id);
  };

  const test = (profile: 'afra-soft' | 'afra-elegant' | 'afra-male') => {
    Cartesia.setKey(key);
    setStatus('শোনাচ্ছি...');
    SpeechAudioService.speak('হ্যালো, আমি আফরা। আপনার সাথে কথা বলতে পেরে ভালো লাগছে।', {
      voiceProfile: profile,
      onEnd: () => setStatus('শেষ।'),
      onError: (m: string) => setStatus(m),
    } as any);
  };

  const opts = (want: 'f' | 'm') => {
    const first = voices.filter((v) => (want === 'f' ? isFemale(v.gender) : isMale(v.gender)));
    const rest = voices.filter((v) => !first.includes(v));
    return [...first, ...rest];
  };

  return (
    <section className="space-y-4">
      <div className="flex items-center gap-2">
        <Volume2 className="w-4 h-4 text-violet-400" />
        <h3 className="text-sm font-semibold text-slate-200 font-display">Cartesia ভয়েস (দ্রুত ও স্বাভাবিক)</h3>
      </div>

      <div className="p-4 rounded-2xl bg-slate-950/50 border border-slate-800/80 space-y-3">
        <p className="text-xs text-slate-400">
          Cartesia-র নিজের একটা Key লাগবে (cartesia.ai-তে ফ্রি অ্যাকাউন্ট খুলে)। চালু থাকলে প্রতিটা কথা প্রথমে এই ভয়েসে বলবে, সীমা শেষ হলে আগের ভয়েসে চলে যাবে।
        </p>

        <input
          type="password"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          placeholder="Cartesia API Key এখানে বসান"
          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-violet-600"
        />
        <button
          onClick={load}
          disabled={busy || !key.trim()}
          className="w-full px-4 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-sm text-white"
        >
          সংরক্ষণ করুন ও ভয়েস তালিকা আনুন
        </button>

        {voices.length > 0 &&
          PROFILES.map((p) => (
            <div key={p.id} className="space-y-1.5">
              <label className="text-xs text-slate-400">{p.label}</label>
              <div className="flex gap-2">
                <select
                  value={chosen[p.id] || ''}
                  onChange={(e) => pick(p.id, e.target.value)}
                  className="flex-1 min-w-0 px-2 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-100"
                >
                  <option value="">— বাছুন —</option>
                  {opts(p.want).map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.name} {v.gender ? `· ${v.gender}` : ''} {v.language ? `· ${v.language}` : ''}
                    </option>
                  ))}
                </select>
                <button
                  onClick={() => test(p.id)}
                  disabled={!chosen[p.id] || !Native.available()}
                  className="px-3 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs text-slate-100"
                >
                  শুনুন
                </button>
              </div>
            </div>
          ))}

        {status && <p className="text-xs text-cyan-300 break-words">{status}</p>}
      </div>
    </section>
  );
};
