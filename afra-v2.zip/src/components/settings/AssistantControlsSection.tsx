import React, { useState } from 'react';
import { Native, loadWakePhrases, saveWakePhrases, DEFAULT_WAKE_PHRASES } from '../../services/nativeBridge';
import { Plus, X, Mic, Layers, Bell, BatteryCharging } from 'lucide-react';

const BTN =
  'flex items-center gap-2 w-full px-4 py-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-sm text-slate-200 text-left transition-colors';

export const AssistantControlsSection: React.FC = () => {
  const [phrases, setPhrases] = useState<string[]>(() => loadWakePhrases());
  const [draft, setDraft] = useState('');
  const [lastHeard, setLastHeard] = useState<string>('');
  const [lang, setLang] = useState<string>(() => localStorage.getItem('afra_wake_lang') || 'bn-BD');

  const update = (next: string[]) => {
    setPhrases(next);
    saveWakePhrases(next);
  };

  const add = () => {
    const v = draft.trim();
    if (!v || phrases.includes(v)) return;
    update([...phrases, v]);
    setDraft('');
  };

  const chooseLang = (l: string) => {
    setLang(l);
    localStorage.setItem('afra_wake_lang', l);
    Native.setWakeLanguage(l);
  };

  return (
    <section className="space-y-4">
      <div className="flex items-center gap-2">
        <Mic className="w-4 h-4 text-violet-400" />
        <h3 className="text-sm font-semibold text-slate-200 font-display">ডাক-নাম ও ফোনের অনুমতি</h3>
      </div>

      <div className="p-4 rounded-2xl bg-slate-950/50 border border-slate-800/80 space-y-3">
        <p className="text-xs text-slate-400">
          এই নামগুলোর যেকোনোটা বললে AFRA জেগে উঠবে। যত খুশি নাম যোগ করতে পারেন (যেমন: হ্যালো ফারদিন, হ্যালো বড় ভাই)।
        </p>

        <div className="flex flex-wrap gap-2">
          {phrases.map((p) => (
            <span
              key={p}
              className="flex items-center gap-1.5 pl-3 pr-1.5 py-1.5 rounded-full bg-violet-950/60 border border-violet-800/50 text-xs text-violet-100"
            >
              {p}
              <button
                onClick={() => update(phrases.filter((x) => x !== p))}
                className="p-0.5 rounded-full hover:bg-violet-800/60"
                aria-label="মুছুন"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
        </div>

        <div className="flex gap-2">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && add()}
            placeholder="নতুন নাম লিখুন, যেমন: হ্যালো ফারদিন"
            className="flex-1 min-w-0 px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-violet-600"
          />
          <button
            onClick={add}
            className="px-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white"
            aria-label="যোগ করুন"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        <button onClick={() => update(DEFAULT_WAKE_PHRASES)} className="text-xs text-slate-500 hover:text-slate-300 underline">
          আগের নামগুলো ফিরিয়ে আনুন
        </button>

        <div>
          <p className="text-xs text-slate-400 mb-2">নাম বলার ভাষা:</p>
          <div className="flex gap-2">
            {[
              ['bn-BD', 'বাংলা'],
              ['en-US', 'English'],
            ].map(([code, label]) => (
              <button
                key={code}
                onClick={() => chooseLang(code)}
                className={`px-4 py-1.5 rounded-lg text-xs font-medium border ${
                  lang === code
                    ? 'bg-violet-600 border-violet-500 text-white'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {Native.available() && (
        <div className="p-4 rounded-2xl bg-slate-950/50 border border-slate-800/80 space-y-2">
          <p className="text-xs text-slate-400">
            "হেই আফরা" বললে ব্যাকগ্রাউন্ডে ঠিক কী শুনেছে, এখানে দেখা যাবে (ঠিকমতো না খুললে এই লেখাটা আমাকে পাঠান):
          </p>
          <button
            onClick={() => setLastHeard(Native.getWakeLastEvent() || 'এখনো কিছু শোনেনি।')}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-100"
          >
            শেষ শোনা কথা দেখুন
          </button>
          {lastHeard && <p className="text-xs text-cyan-300 break-words">{lastHeard}</p>}
        </div>
      )}

      {Native.available() && (
        <div className="space-y-2">
          <button className={BTN} onClick={() => Native.requestOverlayPermission()}>
            <Layers className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>অন্য অ্যাপের উপরে ভাসার অনুমতি দিন</span>
          </button>
          <button className={BTN} onClick={() => Native.openNotificationAccessSettings()}>
            <Bell className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>নোটিফিকেশন পড়ার অনুমতি দিন</span>
          </button>
          <button className={BTN} onClick={() => Native.requestBatteryUnrestricted()}>
            <BatteryCharging className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>ব্যাকগ্রাউন্ডে চালু রাখতে ব্যাটারি সীমা তুলে দিন</span>
          </button>
        </div>
      )}
    </section>
  );
};
