import React, { useState, useEffect } from 'react';
import { ApiKeyStorage, ApiValidationResult } from '../../services/apiKeyStorage';
import {
  Key,
  Eye,
  EyeOff,
  Save,
  Trash2,
  Activity,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Cpu,
  ExternalLink,
  Lock,
  RefreshCw,
  Sparkles,
  Smartphone,
  Check,
} from 'lucide-react';

export const ApiConfigurationSection: React.FC = () => {
  const [apiKey, setApiKey] = useState<string>('');
  const [showKey, setShowKey] = useState<boolean>(false);
  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<ApiValidationResult | null>(null);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [envKeyAvailable, setEnvKeyAvailable] = useState<boolean>(false);
  const [isImportingEnv, setIsImportingEnv] = useState<boolean>(false);
  const [hasSavedKey, setHasSavedKey] = useState<boolean>(false);

  useEffect(() => {
    const existing = ApiKeyStorage.getApiKey();
    if (existing) {
      setApiKey(existing);
      setHasSavedKey(true);
    }

    // Check if host has an environment key for quick testing
    ApiKeyStorage.checkEnvironmentKeyAvailable().then((available) => {
      setEnvKeyAvailable(available);
    });
  }, []);

  const handleSave = () => {
    const trimmed = apiKey.trim();
    if (!trimmed) {
      handleRemove();
      return;
    }

    ApiKeyStorage.setApiKey(trimmed);
    setHasSavedKey(true);
    setSaveSuccess(true);
    setTestResult(null);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleRemove = () => {
    ApiKeyStorage.removeApiKey();
    setApiKey('');
    setHasSavedKey(false);
    setTestResult(null);
    setSaveSuccess(false);
  };

  const handleTestConnection = async () => {
    const keyToTest = apiKey.trim();
    if (!keyToTest) {
      setTestResult({
        valid: false,
        error: 'Please enter a Gemini API key before testing connection.',
      });
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    try {
      const result = await ApiKeyStorage.validateKey(keyToTest);
      setTestResult(result);
      if (result.valid) {
        // Automatically ensure it is saved
        ApiKeyStorage.setApiKey(keyToTest);
        setHasSavedKey(true);
      }
    } catch (err: any) {
      setTestResult({
        valid: false,
        error: err?.message || 'Connection test failed unexpectedly.',
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleImportEnvKey = async () => {
    setIsImportingEnv(true);
    try {
      const res = await fetch('/api/env-key-import', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        if (data.key) {
          setApiKey(data.key);
          ApiKeyStorage.setApiKey(data.key);
          setHasSavedKey(true);
          // Run test
          const testRes = await ApiKeyStorage.validateKey(data.key);
          setTestResult(testRes);
        }
      }
    } catch (e) {
      console.warn('Failed to import environment key:', e);
    } finally {
      setIsImportingEnv(false);
    }
  };

  return (
    <section className="space-y-6 p-6 rounded-3xl bg-slate-900/60 border border-slate-800/80 relative overflow-hidden">
      {/* Glow accent */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-violet-600/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-violet-950/60 border border-violet-800/50 text-violet-400">
            <Key className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white font-display flex items-center gap-2">
              API Configuration
              <span className="text-[10px] font-mono font-normal text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded-full">
                Multi-User BYOK
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Configure and test your personal Google Gemini API credentials. Each user maintains their own isolated key.
            </p>
          </div>
        </div>

        {/* Status Badge */}
        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          {testResult?.valid ? (
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium bg-emerald-950/50 border border-emerald-800/50 px-3 py-1 rounded-full">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Connected & Verified</span>
            </div>
          ) : hasSavedKey ? (
            <div className="flex items-center gap-1.5 text-xs text-violet-400 font-medium bg-violet-950/50 border border-violet-800/50 px-3 py-1 rounded-full">
              <Lock className="w-3.5 h-3.5" />
              <span>Key Configured</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-amber-400 font-medium bg-amber-950/50 border border-amber-800/50 px-3 py-1 rounded-full">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>Key Required</span>
            </div>
          )}
        </div>
      </div>

      {/* API Key Input Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
            <span>Gemini API Key</span>
            <span className="text-rose-400">*</span>
          </label>
          <a
            href="https://aistudio.google.com/app/apikey"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
          >
            <span>Get a free key from Google AI Studio</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        <div className="relative flex items-center">
          <input
            type={showKey ? 'text' : 'password'}
            value={apiKey}
            onChange={(e) => {
              setApiKey(e.target.value);
              setTestResult(null);
            }}
            placeholder="AIzaSy..."
            autoComplete="off"
            spellCheck={false}
            className="w-full pl-3.5 pr-24 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-slate-100 placeholder-slate-600 focus:outline-none focus:border-violet-500 transition-colors"
          />

          <div className="absolute right-2 flex items-center gap-1">
            <button
              type="button"
              onClick={() => setShowKey(!showKey)}
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 rounded-lg transition-colors"
              title={showKey ? 'Hide API Key' : 'Show API Key'}
            >
              {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Action Buttons Row */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSave}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
                saveSuccess
                  ? 'bg-emerald-600 text-white'
                  : 'bg-violet-600 hover:bg-violet-500 text-white shadow-md shadow-violet-600/20 active:scale-95'
              }`}
            >
              {saveSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Saved to Storage</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>Save API Key</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isTesting || !apiKey.trim()}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 disabled:opacity-50 disabled:pointer-events-none transition-all active:scale-95"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isTesting ? 'animate-spin' : ''}`} />
              <span>{isTesting ? 'Validating Connection...' : 'Test API Connection'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            {envKeyAvailable && (
              <button
                type="button"
                onClick={handleImportEnvKey}
                disabled={isImportingEnv}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-slate-300 hover:text-white bg-slate-950 hover:bg-slate-800 border border-slate-800 transition-colors"
                title="Quick-import detected environment key for local developer testing"
              >
                <Sparkles className="w-3 h-3 text-violet-400" />
                <span>{isImportingEnv ? 'Importing...' : 'Quick Import Detected Dev Key'}</span>
              </button>
            )}

            {hasSavedKey && (
              <button
                type="button"
                onClick={handleRemove}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-rose-400 hover:text-rose-300 hover:bg-rose-950/30 border border-rose-900/40 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remove Key</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Validation Result Feedback Banner */}
      {testResult && (
        <div
          className={`p-4 rounded-2xl border text-xs leading-relaxed transition-all ${
            testResult.valid
              ? 'bg-emerald-950/30 border-emerald-800/50 text-emerald-300'
              : 'bg-rose-950/30 border-rose-800/50 text-rose-300'
          }`}
        >
          <div className="flex items-start gap-2.5">
            {testResult.valid ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            )}
            <div className="space-y-1">
              <div className="font-semibold text-slate-100">
                {testResult.valid ? 'API Key Connection Successful' : 'Connection Test Failed'}
              </div>
              <p>
                {testResult.valid
                  ? `Successfully authenticated with ${testResult.provider} using model ${testResult.model}. AFRA chat, avatar generator, and female voice synthesis are fully operational.`
                  : testResult.error}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Active AI Engine & Model Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
        <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80">
          <div className="text-[10px] uppercase font-mono text-slate-500 tracking-wider">
            AI Provider
          </div>
          <div className="text-xs font-semibold text-white font-display mt-1">
            Google Gemini API
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Generative Language v1beta</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80">
          <div className="text-[10px] uppercase font-mono text-slate-500 tracking-wider">
            Primary Chat Model
          </div>
          <div className="text-xs font-semibold text-violet-400 font-display mt-1">
            gemini-3.1-flash-lite
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Ultra low latency streaming</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80">
          <div className="text-[10px] uppercase font-mono text-slate-500 tracking-wider">
            Failover Resilience
          </div>
          <div className="text-xs font-semibold text-cyan-400 font-display mt-1">
            3-Tier Fallback Chain
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">flash-lite → 3.8-flash → latest</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80">
          <div className="text-[10px] uppercase font-mono text-slate-500 tracking-wider">
            Female Voice TTS
          </div>
          <div className="text-xs font-semibold text-emerald-400 font-display mt-1">
            Zephyr & Kore
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">gemini-3.8-flash-lite-tts</div>
        </div>
      </div>

      {/* Security & Multi-User Architecture Notice */}
      <div className="p-4 rounded-2xl bg-slate-950/40 border border-slate-800/70 text-xs text-slate-400 space-y-2">
        <div className="flex items-center gap-2 text-slate-300 font-medium">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Multi-User Privacy & Independent Key Architecture</span>
        </div>
        <p className="leading-relaxed">
          AFRA is engineered for independent distribution: every friend or user stores their own Gemini API key privately on their device. Keys are never shared, never logged to server consoles, and never exposed in public configuration files.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-1 font-mono text-[11px]">
          <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/70">
            <span className="text-slate-200 block font-semibold mb-0.5">Web / PWA Storage:</span>
            <span>Origin-bound encrypted localStorage with per-request header isolation (<code className="text-cyan-400">x-gemini-api-key</code>).</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/70">
            <span className="text-slate-200 block font-semibold mb-0.5">Native Android Integration:</span>
            <span>Hardware-backed <code className="text-violet-400">Android Keystore</code> & <code className="text-violet-400">EncryptedSharedPreferences</code> bridge.</span>
          </div>
        </div>
      </div>
    </section>
  );
};
