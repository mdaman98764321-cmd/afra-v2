import React, { useRef, useEffect } from 'react';
import { useConversation } from '../../context/ConversationContext';
import { useAvatarEngine } from '../../context/AvatarEngineContext';
import { useSettings } from '../../context/SettingsContext';
import { MessageBubble } from './MessageBubble';
import { ChatInput } from './ChatInput';
import { AvatarRenderer } from '../avatar/AvatarRenderer';
import { ApiKeyStorage } from '../../services/apiKeyStorage';
import { Mic, Trash2, Sliders, Sparkles, Key, ArrowRight } from 'lucide-react';

const SUGGESTIONS = [
  'তুমি কেমন আছো?',
  'আজকের জন্য একটা মজার গল্প বলো',
  'ফেসবুক খোলো',
  'আমার মেসেজ পড়ো',
];

interface ChatInterfaceProps {
  onNavigateToSettings?: () => void;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ onNavigateToSettings }) => {
  const {
    messages,
    isThinking,
    isListening,
    isSpeaking,
    sendMessage,
    clearConversation,
    startVoiceListening,
    stopVoiceListening,
    speakMessage,
    setVoiceOverlayOpen,
  } = useConversation();

  const { activeAvatar, avatarState, audioLevel, setAvatarState, setAudioLevel } = useAvatarEngine();
  const { settings, updateSettings } = useSettings();
  const [hasApiKey, setHasApiKey] = React.useState<boolean>(() => ApiKeyStorage.hasApiKey());

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isThinking]);

  useEffect(() => {
    setHasApiKey(ApiKeyStorage.hasApiKey());
  }, [messages]);

  return (
    <div className="flex flex-col h-full bg-[#0b0d10] relative">
      {/* Missing Key Notification Banner */}
      {!hasApiKey && (
        <div className="shrink-0 bg-amber-950/40 border-b border-amber-900/50 px-4 py-2.5 flex items-center justify-between text-xs text-amber-200">
          <div className="flex items-center gap-2">
            <Key className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>
              <strong>Personal API Key Required:</strong> Add your Gemini key in Settings to activate AFRA AI.
            </span>
          </div>
          {onNavigateToSettings && (
            <button
              onClick={onNavigateToSettings}
              className="flex items-center gap-1 font-semibold text-amber-300 hover:text-white underline underline-offset-2 transition-colors ml-3 shrink-0"
            >
              <span>Configure Now</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          )}
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((msg) => (
          <MessageBubble
            key={msg.id}
            message={msg}
            onSpeak={speakMessage}
            isSpeakingThis={isSpeaking}
            avatarThumbUrl={activeAvatar.imageUrl}
            avatarName={activeAvatar.name}
          />
        ))}

        {/* Suggestion Prompts if conversation is short */}
        {messages.length <= 2 && (
          <div className="pt-4 max-w-2xl mx-auto">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-2 px-1">
              <Sparkles className="w-3.5 h-3.5 text-violet-400" />
              <span>এগুলো দিয়ে শুরু করতে পারেন</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SUGGESTIONS.map((suggestion, idx) => (
                <button
                  key={idx}
                  onClick={() => sendMessage(suggestion)}
                  className="text-left p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800/80 text-xs text-slate-300 hover:text-white transition-all duration-150 line-clamp-2"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <ChatInput
        onSendMessage={sendMessage}
        onVoiceTrigger={() => {
          if (isListening) {
            stopVoiceListening();
          } else {
            startVoiceListening();
          }
        }}
        isListening={isListening}
        isThinking={isThinking}
        personaMode={settings.personaMode}
        onPersonaChange={(mode) => updateSettings({ personaMode: mode })}
      />
    </div>
  );
};
