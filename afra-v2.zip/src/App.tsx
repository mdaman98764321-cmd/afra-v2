import React, { useEffect, useState } from 'react';
import { SettingsProvider } from './context/SettingsContext';
import { AvatarEngineProvider, useAvatarEngine } from './context/AvatarEngineContext';
import { ConversationProvider, useConversation } from './context/ConversationContext';
import { CleanHeader } from './components/layout/CleanHeader';
import { ChatInterface } from './components/chat/ChatInterface';
import { AvatarStudio } from './components/studio/AvatarStudio';
import { SettingsView } from './components/settings/SettingsView';
import { VoiceAssistantOverlay } from './components/voice/VoiceAssistantOverlay';
import { Native, pushOverlayAvatar } from './services/nativeBridge';
import { getVoiceSource, setVoiceSource, VoiceSource } from './services/voiceSource';
import { Cartesia } from './services/cartesia';
import { ArrowLeft } from 'lucide-react';

type View = 'chat' | 'studio' | 'settings';

function AppContent() {
  const [view, setView] = useState<View>('chat');
  const { setVoiceOverlayOpen, clearConversation } = useConversation();
  const [overlayOn, setOverlayOn] = useState<boolean>(() => Native.isOverlayRunning());
  const [wakeOn, setWakeOn] = useState<boolean>(() => Native.isWakeRunning());
  const [toast, setToast] = useState<string>('');
  const [voiceSource, setVoiceSourceState] = useState<VoiceSource>(() => getVoiceSource());
  const { activeAvatar } = useAvatarEngine();

  // A new picture added in the Avatar studio becomes the floating avatar (once).
  // Characters picked by tapping the floating avatar are never overridden.
  useEffect(() => {
    if (!Native.available()) return;
    if (activeAvatar.isBuiltIn || activeAvatar.type !== 'image' || !activeAvatar.imageUrl) return;
    const key = `${activeAvatar.id}:${activeAvatar.imageUrl.length}`;
    try {
      if (localStorage.getItem('afra_overlay_pushed') === key) return;
      localStorage.setItem('afra_overlay_pushed', key);
    } catch {
      /* ignore */
    }
    pushOverlayAvatar(activeAvatar.imageUrl);
  }, [activeAvatar.id, activeAvatar.imageUrl, activeAvatar.isBuiltIn, activeAvatar.type]);

  const showToast = (msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(''), 4500);
  };

  // Messages from the Android side (e.g. "Hey AFRA" heard in the background)
  useEffect(() => {
    const handle = (action: string) => {
      if (action === 'start_voice') {
        setView('chat');
        setVoiceOverlayOpen(true);
      }
    };
    const pending = (window as any).__afraPendingAction;
    if (pending) {
      (window as any).__afraPendingAction = '';
      handle(pending);
    }
    const onAction = (e: Event) => handle((e as CustomEvent).detail);
    const onToast = (e: Event) => showToast(String((e as CustomEvent).detail || ''));
    window.addEventListener('afra-native-action', onAction);
    window.addEventListener('afra-toast', onToast);
    return () => {
      window.removeEventListener('afra-native-action', onAction);
      window.removeEventListener('afra-toast', onToast);
    };
  }, [setVoiceOverlayOpen]);

  const refreshStatus = () => {
    window.setTimeout(() => {
      setOverlayOn(Native.isOverlayRunning());
      setWakeOn(Native.isWakeRunning());
    }, 900);
  };

  const toggleVoiceSource = () => {
    const next: VoiceSource = voiceSource === 'cartesia' ? 'gemini' : 'cartesia';
    if (next === 'cartesia' && !Cartesia.getKey()) {
      showToast('আগে সেটিংসে গিয়ে Cartesia Key বসান।');
      return;
    }
    setVoiceSource(next);
    setVoiceSourceState(next);
    showToast(next === 'cartesia' ? 'এখন Cartesia ভয়েসে কথা বলবে।' : 'এখন Google (Gemini) ভয়েসে কথা বলবে।');
  };

  const toggleOverlay = () => {
    if (!Native.available()) return showToast('এই সুবিধা শুধু অ্যান্ড্রয়েড অ্যাপে কাজ করে।');
    if (Native.isOverlayRunning()) {
      Native.stopOverlay();
    } else if (!Native.hasOverlayPermission()) {
      showToast('অনুমতি দিন, তারপর ফিরে এসে আবার চালু করুন।');
      Native.requestOverlayPermission();
      return;
    } else {
      Native.startOverlay();
    }
    refreshStatus();
  };

  const toggleWake = () => {
    if (!Native.available()) return showToast('এই সুবিধা শুধু অ্যান্ড্রয়েড অ্যাপে কাজ করে।');
    if (Native.isWakeRunning()) {
      Native.stopWake();
    } else {
      Native.startWake();
      showToast('মাইক্রোফোনের অনুমতি চাইলে “Allow” দিন। দরকার হলে আবার সুইচ চালু করুন।');
    }
    refreshStatus();
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0b0d10] text-[#e2e8f0] overflow-hidden">
      {view === 'chat' ? (
        <CleanHeader
          overlayOn={overlayOn}
          wakeOn={wakeOn}
          voiceSource={voiceSource}
          onToggleVoiceSource={toggleVoiceSource}
          onVoice={() => setVoiceOverlayOpen(true)}
          onToggleOverlay={toggleOverlay}
          onToggleWake={toggleWake}
          onStudio={() => setView('studio')}
          onSettings={() => setView('settings')}
          onClear={clearConversation}
        />
      ) : (
        <header className="shrink-0 flex items-center gap-2 px-3 py-3 border-b border-slate-800/80">
          <button
            onClick={() => setView('chat')}
            className="p-2 rounded-full text-slate-300 hover:bg-slate-800/70"
            aria-label="ফিরে যান"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <span className="text-sm font-semibold text-white">{view === 'settings' ? 'সেটিংস' : 'অবতার'}</span>
        </header>
      )}

      <main className="flex-1 flex overflow-hidden relative">
        {view === 'chat' && (
          <div className="flex-1 flex flex-col h-full w-full overflow-hidden">
            <ChatInterface onNavigateToSettings={() => setView('settings')} />
          </div>
        )}
        {view === 'studio' && <AvatarStudio />}
        {view === 'settings' && <SettingsView />}
      </main>

      <VoiceAssistantOverlay />

      {toast && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[100] max-w-[90%] px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-slate-100 shadow-xl text-center">
          {toast}
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <AvatarEngineProvider>
        <ConversationProvider>
          <AppContent />
        </ConversationProvider>
      </AvatarEngineProvider>
    </SettingsProvider>
  );
}
