import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppSettings, AppTheme } from '../types';
import { StorageService, DEFAULT_SETTINGS } from '../services/storage';

interface SettingsContextType {
  settings: AppSettings;
  updateSettings: (partial: Partial<AppSettings>) => void;
  resetSettings: () => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AppSettings>(() => StorageService.getSettings());

  useEffect(() => {
    // Sync theme class to documentElement
    const root = document.documentElement;
    root.classList.remove('theme-obsidian', 'theme-charcoal', 'theme-violet-noir', 'theme-silver-edge');
    root.classList.add(`theme-${settings.theme}`);
    root.classList.add('dark');
  }, [settings.theme]);

  const updateSettings = (partial: Partial<AppSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...partial };
      StorageService.saveSettings(updated);
      return updated;
    });
  };

  const resetSettings = () => {
    setSettings(DEFAULT_SETTINGS);
    StorageService.saveSettings(DEFAULT_SETTINGS);
  };

  return (
    <SettingsContext.Provider value={{ settings, updateSettings, resetSettings }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
