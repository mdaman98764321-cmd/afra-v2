import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { AvatarItem, AvatarState, AndroidBridgeEvent } from '../types';
import { StorageService } from '../services/storage';

interface AvatarEngineContextType {
  activeAvatar: AvatarItem;
  avatars: AvatarItem[];
  avatarState: AvatarState;
  audioLevel: number;
  setAvatarState: (state: AvatarState) => void;
  setAudioLevel: (level: number) => void;
  selectAvatar: (id: string) => void;
  saveCustomAvatar: (avatar: AvatarItem) => void;
  deleteCustomAvatar: (id: string) => void;
  recentBridgeEvents: AndroidBridgeEvent[];
}

const AvatarEngineContext = createContext<AvatarEngineContextType | undefined>(undefined);

export const AvatarEngineProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [avatars, setAvatars] = useState<AvatarItem[]>(() => StorageService.getAvatars());
  const [activeAvatarId, setActiveAvatarId] = useState<string>(() => StorageService.getActiveAvatarId());
  const [avatarState, setAvatarStateInternal] = useState<AvatarState>('idle');
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [recentBridgeEvents, setRecentBridgeEvents] = useState<AndroidBridgeEvent[]>([]);

  // Find active avatar or fallback to first
  const activeAvatar = avatars.find((a) => a.id === activeAvatarId) || avatars[0];

  const logBridgeEvent = useCallback((action: AndroidBridgeEvent['action'], payload: Record<string, any>) => {
    const event: AndroidBridgeEvent = {
      action,
      payload,
      timestamp: Date.now(),
    };
    setRecentBridgeEvents((prev) => [event, ...prev.slice(0, 19)]);

    // If running in an Android WebView with JavascriptInterface registered:
    if ((window as any).AndroidAfraBridge) {
      try {
        (window as any).AndroidAfraBridge[action]?.(JSON.stringify(payload));
      } catch (e) {
        console.warn('Native Android bridge call error:', e);
      }
    }
  }, []);

  const setAvatarState = useCallback((state: AvatarState) => {
    setAvatarStateInternal(state);
    logBridgeEvent('onStateChange', { state });
  }, [logBridgeEvent]);

  const selectAvatar = useCallback((id: string) => {
    setActiveAvatarId(id);
    StorageService.saveActiveAvatarId(id);
    logBridgeEvent('onAvatarSelected', { id });
  }, [logBridgeEvent]);

  const saveCustomAvatar = useCallback((newAvatar: AvatarItem) => {
    setAvatars((prev) => {
      const existingIdx = prev.findIndex((a) => a.id === newAvatar.id);
      let updated: AvatarItem[];
      if (existingIdx >= 0) {
        updated = [...prev];
        updated[existingIdx] = newAvatar;
      } else {
        updated = [newAvatar, ...prev];
      }
      StorageService.saveAvatars(updated);
      return updated;
    });
    // Automatically select the saved avatar
    setActiveAvatarId(newAvatar.id);
    StorageService.saveActiveAvatarId(newAvatar.id);
  }, []);

  const deleteCustomAvatar = useCallback((id: string) => {
    setAvatars((prev) => {
      const updated = prev.filter((a) => a.id !== id);
      StorageService.saveAvatars(updated);
      return updated;
    });
    // If active avatar was deleted, fallback to default
    if (activeAvatarId === id) {
      setActiveAvatarId('afra-core');
      StorageService.saveActiveAvatarId('afra-core');
    }
  }, [activeAvatarId]);

  return (
    <AvatarEngineContext.Provider
      value={{
        activeAvatar,
        avatars,
        avatarState,
        audioLevel,
        setAvatarState,
        setAudioLevel,
        selectAvatar,
        saveCustomAvatar,
        deleteCustomAvatar,
        recentBridgeEvents,
      }}
    >
      {children}
    </AvatarEngineContext.Provider>
  );
};

export const useAvatarEngine = () => {
  const context = useContext(AvatarEngineContext);
  if (!context) {
    throw new Error('useAvatarEngine must be used within an AvatarEngineProvider');
  }
  return context;
};
