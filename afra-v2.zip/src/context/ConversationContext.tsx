import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { ChatMessage } from '../types';
import { StorageService } from '../services/storage';
import { ChatApiService } from '../services/chatApi';
import { tryLocalCommand } from '../services/voiceCommands';
import { SpeechAudioService } from '../services/speech';
import { useAvatarEngine } from './AvatarEngineContext';
import { useSettings } from './SettingsContext';

interface ConversationContextType {
  messages: ChatMessage[];
  isThinking: boolean;
  isSpeaking: boolean;
  isListening: boolean;
  transcript: string;
  isVoiceOverlayOpen: boolean;
  setVoiceOverlayOpen: (open: boolean) => void;
  sendMessage: (content: string) => Promise<void>;
  clearConversation: () => void;
  startVoiceListening: () => Promise<boolean>;
  stopVoiceListening: () => void;
  speakMessage: (text: string) => void;
  stopSpeaking: () => void;
}

const ConversationContext = createContext<ConversationContextType | undefined>(undefined);

export const ConversationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => StorageService.getChatHistory());
  const [isThinking, setIsThinking] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [transcript, setTranscript] = useState<string>('');
  const [isVoiceOverlayOpen, setVoiceOverlayOpen] = useState<boolean>(false);

  const { setAvatarState, setAudioLevel } = useAvatarEngine();
  const { settings } = useSettings();

  const isThinkingRef = useRef(isThinking);
  isThinkingRef.current = isThinking;

  useEffect(() => {
    StorageService.saveChatHistory(messages);
  }, [messages]);

  const speakMessage = useCallback(
    (text: string) => {
      setIsSpeaking(true);
      setAvatarState('speaking');

      SpeechAudioService.speak(text, {
        voiceProfile: settings.voiceProfile,
        rate: settings.speechRate,
        pitch: settings.speechPitch,
        onStart: () => {
          setIsSpeaking(true);
          setAvatarState('speaking');
        },
        onAudioLevel: (level) => {
          setAudioLevel(level);
        },
        onEnd: () => {
          setIsSpeaking(false);
          setAvatarState('idle');
          setAudioLevel(0);
        },
        onError: (errMsg) => {
          console.warn('[ConversationContext] Voice synthesis issue:', errMsg);
          window.dispatchEvent(new CustomEvent('afra-toast', { detail: errMsg }));
          setIsSpeaking(false);
          setAvatarState('idle');
          setAudioLevel(0);
        },
      });
    },
    [settings.voiceProfile, settings.speechRate, settings.speechPitch, setAvatarState, setAudioLevel]
  );

  const stopSpeaking = useCallback(() => {
    SpeechAudioService.stopSpeaking();
    setIsSpeaking(false);
    setAvatarState('idle');
    setAudioLevel(0);
  }, [setAvatarState, setAudioLevel]);

  const sendMessage = useCallback(
    async (content: string) => {
      if (!content.trim() || isThinkingRef.current) return;

      if (settings.soundEffects) {
        SpeechAudioService.playSound('chirp');
      }

      // Stop any current speech
      stopSpeaking();

      const userMsg: ChatMessage = {
        id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        role: 'user',
        content: content.trim(),
        timestamp: Date.now(),
      };

      const assistantMsgId = `asst-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
      const placeholderAssistantMsg: ChatMessage = {
        id: assistantMsgId,
        role: 'assistant',
        content: '',
        timestamp: Date.now(),
        isStreaming: true,
      };

      const updatedHistory = [...messages, userMsg];

      // Phone commands ("open Facebook", "read my messages") are handled on the phone itself.
      const localReply = await tryLocalCommand(content.trim());
      if (localReply !== null) {
        setMessages([
          ...updatedHistory,
          { id: assistantMsgId, role: 'assistant', content: localReply, timestamp: Date.now() },
        ]);
        if (isVoiceOverlayOpen || settings.autoSpeakResponse) speakMessage(localReply);
        return;
      }

      setMessages([...updatedHistory, placeholderAssistantMsg]);
      setIsThinking(true);
      setAvatarState('thinking');

      let accumulatedText = '';

      try {
        await ChatApiService.sendMessageStream({
          message: content,
          history: updatedHistory,
          persona: settings.customPersona,
          mode: settings.personaMode,
          onChunk: (chunk) => {
            accumulatedText += chunk;
            setAvatarState('speaking');
            setMessages((prev) =>
              prev.map((m) => (m.id === assistantMsgId ? { ...m, content: accumulatedText } : m))
            );
          },
          onComplete: (fullText) => {
            setIsThinking(false);
            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantMsgId
                  ? { ...m, content: fullText || accumulatedText, isStreaming: false }
                  : m
              )
            );

            if (settings.soundEffects) {
              SpeechAudioService.playSound('complete');
            }

            // If in Voice overlay or autoSpeak is on, synthesize speech
            if (isVoiceOverlayOpen || settings.autoSpeakResponse) {
              speakMessage(fullText || accumulatedText);
            } else {
              setAvatarState('idle');
              setAudioLevel(0);
            }
          },
          onError: (err) => {
            setIsThinking(false);
            setAvatarState('idle');
            setAudioLevel(0);
            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantMsgId
                  ? {
                      ...m,
                      content: `*AFRA Core Notice*: ${err}\n\nPlease try again or verify connection.`,
                      isStreaming: false,
                    }
                  : m
              )
            );
          },
        });
      } catch (fatalErr: any) {
        console.error('[ConversationContext] Fatal dispatch error:', fatalErr);
        setIsThinking(false);
        setAvatarState('idle');
        setAudioLevel(0);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  content: `*AFRA System Error*: ${fatalErr?.message || 'Unexpected connection interruption.'}`,
                  isStreaming: false,
                }
              : m
          )
        );
      } finally {
        setIsThinking(false);
      }
    },
    [
      messages,
      settings.soundEffects,
      settings.customPersona,
      settings.personaMode,
      settings.autoSpeakResponse,
      isVoiceOverlayOpen,
      stopSpeaking,
      setAvatarState,
      setAudioLevel,
      speakMessage,
    ]
  );

  const startVoiceListening = useCallback(async (): Promise<boolean> => {
    stopSpeaking();
    setIsListening(true);
    setAvatarState('listening');
    setTranscript('');

    if (settings.soundEffects) {
      SpeechAudioService.playSound('activate');
    }

    const success = await SpeechAudioService.startListening(
      (text, isFinal) => {
        setTranscript(text);
        if (isFinal && text.trim().length > 1) {
          stopVoiceListening();
          sendMessage(text.trim());
        }
      },
      (level) => {
        setAudioLevel(level);
      },
      (err) => {
        console.warn('Speech recognition error:', err);
        setIsListening(false);
        setAvatarState('idle');
        setAudioLevel(0);
      }
    );

    if (!success) {
      setIsListening(false);
      setAvatarState('idle');
      setAudioLevel(0);
    }

    return success;
  }, [stopSpeaking, setAvatarState, setAudioLevel, settings.soundEffects, sendMessage]);

  const stopVoiceListening = useCallback(() => {
    SpeechAudioService.stopListening();
    setIsListening(false);
    if (!isThinking && !isSpeaking) {
      setAvatarState('idle');
      setAudioLevel(0);
    }
  }, [isThinking, isSpeaking, setAvatarState, setAudioLevel]);

  const clearConversation = useCallback(() => {
    StorageService.clearChatHistory();
    setMessages(StorageService.getChatHistory());
  }, []);

  return (
    <ConversationContext.Provider
      value={{
        messages,
        isThinking,
        isSpeaking,
        isListening,
        transcript,
        isVoiceOverlayOpen,
        setVoiceOverlayOpen,
        sendMessage,
        clearConversation,
        startVoiceListening,
        stopVoiceListening,
        speakMessage,
        stopSpeaking,
      }}
    >
      {children}
    </ConversationContext.Provider>
  );
};

export const useConversation = () => {
  const context = useContext(ConversationContext);
  if (!context) {
    throw new Error('useConversation must be used within a ConversationProvider');
  }
  return context;
};
