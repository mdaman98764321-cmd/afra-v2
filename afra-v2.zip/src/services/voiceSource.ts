import { Cartesia } from './cartesia';

export type VoiceSource = 'gemini' | 'cartesia' | 'free';
const KEY = 'afra_voice_source';

/** Which voice speaks first: Google (Gemini) or Cartesia. The person can switch any time. */
export function getVoiceSource(): VoiceSource {
  try {
    const v = localStorage.getItem(KEY);
    if (v === 'gemini' || v === 'cartesia' || v === 'free') return v;
  } catch {
    /* ignore */
  }
  return Cartesia.getKey() ? 'cartesia' : 'gemini';
}

export function setVoiceSource(v: VoiceSource): void {
  try {
    localStorage.setItem(KEY, v);
  } catch {
    /* ignore */
  }
}
