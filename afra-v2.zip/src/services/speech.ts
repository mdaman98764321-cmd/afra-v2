import { VoiceProfileId } from '../types';
import { VOICE_PROFILES } from './voiceProfiles';
import { edgeSpeak, simpleSpeak } from './nativeBridge';
import { Cartesia } from './cartesia';
import { GeminiListener } from './geminiListener';
import { Native } from './nativeBridge';
import { getVoiceSource } from './voiceSource';
import { ApiKeyStorage } from './apiKeyStorage';

export interface SpeechVoiceOption {
  name: string;
  lang: string;
  isDefault: boolean;
  isFemale: boolean;
}

// Known female voice name substrings for strict Web Speech API filtering
const FEMALE_VOICE_KEYWORDS = [
  'female',
  'woman',
  'girl',
  'samantha',
  'victoria',
  'karen',
  'moira',
  'tessa',
  'fiona',
  'veena',
  'zira',
  'hazel',
  'susan',
  'catherine',
  'heera',
  'ananya',
  'bangla',
  'bangladesh',
  'bengali',
  'shrabani',
  'mitu',
  'monica',
  'paulina',
  'helena',
  'ioana',
  'milena',
  'luciana',
  'kyoko',
  'yuna',
  'sin-ji',
  'ting-ting',
  'mei-jia',
  'google uk english female',
  'google us english',
  'microsoft zira',
  'natural female',
];

class AudioController {
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private mediaStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private currentAudioElement: HTMLAudioElement | null = null;
  private audioSourceNode: MediaElementAudioSourceNode | null = null;
  private levelAnimationId: number | null = null;
  private synthInterval: number | null = null;
  private recognition: any = null;

  public initAudioContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  // Play subtle futuristic UI sound effects using Web Audio API
  public playSound(type: 'activate' | 'state' | 'chirp' | 'complete'): void {
    try {
      const ctx = this.initAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;

      if (type === 'activate') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        osc.start(now);
        osc.stop(now + 0.18);
      } else if (type === 'state') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(600, now);
        osc.frequency.exponentialRampToValueAtTime(750, now + 0.08);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        osc.start(now);
        osc.stop(now + 0.1);
      } else if (type === 'chirp') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.exponentialRampToValueAtTime(1320, now + 0.09);
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.start(now);
        osc.stop(now + 0.15);
      } else if (type === 'complete') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(520, now);
        osc.frequency.setValueAtTime(660, now + 0.08);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
        osc.start(now);
        osc.stop(now + 0.22);
      }
    } catch (e) {
      // Audio might be blocked by autoplay policy until user gesture
    }
  }

  // Get strictly filtered female voices from Web Speech API
  public getVoices(): SpeechVoiceOption[] {
    if (!('speechSynthesis' in window)) return [];
    const voices = window.speechSynthesis.getVoices();
    return voices.map((v) => {
      const lower = (v.name + ' ' + v.lang).toLowerCase();
      const isFemale = FEMALE_VOICE_KEYWORDS.some((kw) => lower.includes(kw));
      return {
        name: v.name,
        lang: v.lang,
        isDefault: v.default,
        isFemale,
      };
    });
  }

  // Find a verified female voice from Web Speech API
  private findVerifiedFemaleVoice(preferredVoiceName?: string): SpeechSynthesisVoice | null {
    if (!('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices();

    if (preferredVoiceName) {
      const exactMatch = voices.find((v) => v.name === preferredVoiceName);
      if (exactMatch) {
        const lower = (exactMatch.name + ' ' + exactMatch.lang).toLowerCase();
        // If explicitly named female or safe
        if (FEMALE_VOICE_KEYWORDS.some((kw) => lower.includes(kw))) {
          return exactMatch;
        }
      }
    }

    // Search for any verified female voice
    for (const kw of FEMALE_VOICE_KEYWORDS) {
      const match = voices.find((v) => (v.name + ' ' + v.lang).toLowerCase().includes(kw));
      if (match) return match;
    }

    return null;
  }

  // Stop any active speech (Gemini audio or SpeechSynthesis)
  public stopSpeaking(): void {
    this.speakToken++;
    if (this.currentAudioElement) {
      try {
        this.currentAudioElement.pause();
        this.currentAudioElement.currentTime = 0;
      } catch (e) {}
      this.currentAudioElement = null;
    }

    if (this.levelAnimationId) {
      cancelAnimationFrame(this.levelAnimationId);
      this.levelAnimationId = null;
    }

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  // High-fidelity speech pipeline with Gemini TTS (Female Zephyr & Kore) and strict female fallback
  public async speak(
    text: string,
    options: {
      voiceProfile?: VoiceProfileId;
      rate?: number;
      pitch?: number;
      onStart?: () => void;
      onAudioLevel?: (level: number) => void;
      onEnd?: () => void;
      onError?: (errMsg: string) => void;
    }
  ): Promise<void> {
    this.stopSpeaking();

    const cleanText = text
      .replace(/[*#`_~]/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/```[\s\S]*?```/g, '')
      .trim();

    if (!cleanText) {
      options.onEnd?.();
      return;
    }

    const voiceProfile = options.voiceProfile || 'afra-soft';
    const apiKey = ApiKeyStorage.getApiKey();
    if (!apiKey) {
      options.onError?.('Gemini API key is missing. Add it in Settings to hear AFRA speak.');
      return;
    }

    // Split into short pieces: the first one is tiny so speech starts quickly,
    // while the next piece is already being prepared during playback.
    const chunks = this.splitForSpeech(cleanText);
    const token = ++this.speakToken;
    let started = false;
    let failed = false;

    let nextAudio = this.fetchTtsAudio(chunks[0], voiceProfile, apiKey);
    for (let i = 0; i < chunks.length; i++) {
      const result = await nextAudio;
      if (token !== this.speakToken) return; // stopped or replaced by a newer request
      if (i + 1 < chunks.length) nextAudio = this.fetchTtsAudio(chunks[i + 1], voiceProfile, apiKey);
      if (result.error || !result.audio) {
        options.onError?.(result.error || 'Voice could not be generated.');
        return;
      }
      await new Promise<void>((resolve) => {
        this.playGeminiAudio(result.audio as string, {
          mime: result.mime,
          onStart: () => {
            if (!started) {
              started = true;
              options.onStart?.();
            }
          },
          onAudioLevel: options.onAudioLevel,
          onEnd: () => resolve(),
          onError: (m) => {
            failed = true;
            options.onError?.(m);
            resolve();
          },
        });
      });
      if (failed || token !== this.speakToken) return;
    }
    options.onEnd?.();
  }

  private speakToken = 0;

  private splitForSpeech(text: string): string[] {
    // The whole answer is spoken. The first piece is short so speech starts quickly;
    // the later pieces are bigger so fewer requests are needed.
    const t = text.replace(/\s+/g, ' ').trim();
    if (t.length <= 130) return [t];
    const sentences = t.match(/[^.!?।]+[.!?।]*\s*/g) || [t];
    const chunks: string[] = [];
    let cur = '';
    for (const sentence of sentences) {
      const limit = chunks.length === 0 ? 130 : 450;
      if (cur && (cur + sentence).length > limit) {
        chunks.push(cur.trim());
        cur = sentence;
      } else {
        cur += sentence;
      }
    }
    if (cur.trim()) chunks.push(cur.trim());
    // a single very long sentence: cut it at spaces
    const out: string[] = [];
    for (const c of chunks) {
      if (c.length <= 520) {
        out.push(c);
        continue;
      }
      let rest = c;
      while (rest.length > 520) {
        let cut = rest.lastIndexOf(' ', 480);
        if (cut < 200) cut = 480;
        out.push(rest.slice(0, cut).trim());
        rest = rest.slice(cut).trim();
      }
      if (rest) out.push(rest);
    }
    return out;
  }

  private ttsBlockedUntil = 0;

  private async fetchTtsAudio(
    text: string,
    voiceProfile: VoiceProfileId,
    apiKey: string
  ): Promise<{ audio?: string; mime?: string; error?: string }> {
    let geminiError = '';
    let cartesiaError = '';

    // 0) Cartesia voice, if the person has set it up in Settings
    if (getVoiceSource() === 'cartesia' && Cartesia.isReady(voiceProfile)) {
      const c = await Cartesia.speak(text, voiceProfile);
      if (c.audio) return { audio: c.audio, mime: 'audio/wav' };
      cartesiaError = c.error || '';
    }

    // 1) Gemini voice (best quality), unless it is resting after a quota error or the person chose the free voice
    if (getVoiceSource() !== 'free' && Date.now() >= this.ttsBlockedUntil) {
      try {
        const res = await fetch('/api/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-gemini-api-key': apiKey },
          body: JSON.stringify({ text, voiceProfile }),
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.audioData) return { audio: data.audioData, mime: 'audio/wav' };
        geminiError = data.error || `Voice request failed (${res.status}).`;
      } catch (e: any) {
        geminiError = e?.message || 'Voice request failed.';
      }
      if (/quota|429|সীমা/i.test(geminiError)) this.ttsBlockedUntil = Date.now() + 60000;
    }

    // 2) Free neural voice (Gemini allowance used up, or Gemini voice not working)
    const free = await edgeSpeak(text, voiceProfile);
    if (free.audio) {
      if (getVoiceSource() !== 'free') this.tellFallback('বিকল্প ফ্রি ভয়েসে কথা বলছি (Gemini ভয়েসের সীমা শেষ)।');
      return { audio: free.audio, mime: 'audio/mpeg' };
    }

    // 3) Simple voice (one female voice) so AFRA never goes silent
    const simple = await simpleSpeak(text);
    if (simple.audio) {
      this.tellFallback('সাধারণ বিকল্প ভয়েসে কথা বলছি। (সব ভয়েসের মধ্যে এটার মান সবচেয়ে সাধারণ)');
      return { audio: simple.audio, mime: 'audio/mpeg' };
    }

    return {
      error: `ভয়েস তৈরি হয়নি। ${cartesiaError ? 'Cartesia: ' + cartesiaError + ' | ' : ''}Gemini: ${geminiError || 'ব্যবহার হয়নি'} | ফ্রি ভয়েস: ${free.error || '-'} | সাধারণ ভয়েস: ${simple.error || '-'}`,
    };
  }

  private tellFallback(msg: string): void {
    if (this.announcedFallback) return;
    this.announcedFallback = true;
    window.dispatchEvent(new CustomEvent('afra-toast', { detail: msg }));
    window.setTimeout(() => (this.announcedFallback = false), 120000);
  }

  private announcedFallback = false;

  // Play Gemini WAV audio with real-time AnalyserNode level modulation for avatars
  private async playGeminiAudio(
    base64Data: string,
    options: {
      mime?: string;
      onStart?: () => void;
      onAudioLevel?: (level: number) => void;
      onEnd?: () => void;
      onError?: (errMsg: string) => void;
    }
  ): Promise<void> {
    const audio = new Audio(`data:${options.mime || 'audio/wav'};base64,${base64Data}`);
    this.currentAudioElement = audio;

    // Connect to Web Audio Analyser so the avatar pulses with the actual female voice waveform
    try {
      const ctx = this.initAudioContext();
      const source = ctx.createMediaElementSource(audio);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analyser.connect(ctx.destination);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const updateLevel = () => {
        if (!this.currentAudioElement || this.currentAudioElement.paused) return;
        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        const normalized = Math.min(1, avg / 70);
        options.onAudioLevel?.(normalized);
        this.levelAnimationId = requestAnimationFrame(updateLevel);
      };

      audio.onplay = () => {
        options.onStart?.();
        updateLevel();
      };
    } catch (e) {
      // If CORS or media element source already connected, simulate envelope
      let phase = 0;
      const interval = setInterval(() => {
        if (!this.currentAudioElement || this.currentAudioElement.paused) {
          clearInterval(interval);
          return;
        }
        phase += 0.3;
        const level = (Math.abs(Math.sin(phase)) * 0.6 + 0.2) * 0.9;
        options.onAudioLevel?.(level);
      }, 50);

      audio.onplay = () => {
        options.onStart?.();
      };
    }

    audio.onended = () => {
      this.currentAudioElement = null;
      if (this.levelAnimationId) {
        cancelAnimationFrame(this.levelAnimationId);
        this.levelAnimationId = null;
      }
      options.onAudioLevel?.(0);
      options.onEnd?.();
    };

    audio.onerror = () => {
      this.currentAudioElement = null;
      options.onAudioLevel?.(0);
      options.onError?.('Audio playback failed for the selected female voice.');
    };

    await audio.play().catch((err) => {
      options.onError?.(err?.message || 'Playback blocked by browser autoplay policy.');
    });
  }

  // Play Web Speech API with strict female voice and simulated speech envelope
  private playWebSpeechFallback(
    text: string,
    voice: SpeechSynthesisVoice,
    profile: VoiceProfileId,
    options: {
      onStart?: () => void;
      onAudioLevel?: (level: number) => void;
      onEnd?: () => void;
      onError?: (errMsg: string) => void;
    }
  ): void {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = voice;

    // Profile acoustic tuning:
    // AFRA Soft: slightly higher pitch, gentle pacing
    // AFRA Elegant: poised pitch, steady articulate cadence
    if (profile === 'afra-soft') {
      utterance.pitch = 1.15;
      utterance.rate = 0.95;
    } else {
      utterance.pitch = 1.05;
      utterance.rate = 1.0;
    }

    let ticker: any = null;

    utterance.onstart = () => {
      options.onStart?.();
      let phase = 0;
      ticker = setInterval(() => {
        phase += 0.28;
        const level = Math.abs(Math.sin(phase) * 0.5 + Math.cos(phase * 2.1) * 0.3) * 0.8;
        options.onAudioLevel?.(Math.min(1, Math.max(0.1, level)));
      }, 50);
    };

    const cleanup = () => {
      if (ticker) {
        clearInterval(ticker);
        ticker = null;
      }
      options.onAudioLevel?.(0);
    };

    utterance.onend = () => {
      cleanup();
      options.onEnd?.();
    };

    utterance.onerror = () => {
      cleanup();
      options.onError?.('SpeechSynthesis failed for female voice.');
    };

    window.speechSynthesis.speak(utterance);
  }

  // Test Voice Profile with real audio output
  public async testVoiceProfile(
    profileId: VoiceProfileId,
    isBangla: boolean = false,
    onAudioLevel?: (level: number) => void
  ): Promise<void> {
    const profile = VOICE_PROFILES[profileId];
    if (!profile) return;

    const sample = isBangla ? profile.testSampleBn : profile.testSampleEn;

    return new Promise((resolve, reject) => {
      this.speak(sample, {
        voiceProfile: profileId,
        onAudioLevel,
        onEnd: () => resolve(),
        onError: (err) => reject(new Error(err)),
      });
    });
  }

  private geminiListener: GeminiListener | null = null;
  private phoneListenFailed = false;

  private listenMode(): 'auto' | 'phone' | 'gemini' {
    try {
      const v = localStorage.getItem('afra_listen_mode');
      if (v === 'phone' || v === 'gemini') return v;
    } catch {
      /* ignore */
    }
    return 'auto';
  }

  private async startGeminiListening(
    onResult: (transcript: string, isFinal: boolean) => void,
    onAudioLevel: (level: number) => void,
    onError: (err: string) => void
  ): Promise<boolean> {
    this.geminiListener?.stop();
    this.geminiListener = new GeminiListener();
    return this.geminiListener.start(onResult, onAudioLevel, (e) => {
      this.explainListenError(e);
      onError(e);
    });
  }

  private explainListenError(code: string, n?: number): void {
    const map: Record<string, string> = {
      'not-allowed': 'মাইক্রোফোনের অনুমতি দেওয়া নেই। ফোনের সেটিংসে AFRA-কে মাইক ব্যবহারের অনুমতি দিন।',
      network: 'ইন্টারনেট সমস্যায় আপনার কথা বোঝা যায়নি।',
      'audio-capture': 'মাইক্রোফোন ব্যবহার করা যাচ্ছে না। অন্য কোনো অ্যাপ মাইক ব্যবহার করছে কিনা দেখুন।',
      'service-not-allowed': 'ফোনে কথা-বোঝার সার্ভিস নেই বা বন্ধ আছে।',
      'language-not-supported': 'ফোনের কথা-বোঝার সার্ভিস বাংলা সমর্থন করছে না।',
    };
    const msg = map[code] || `কথা শোনায় সমস্যা (${code})`;
    window.dispatchEvent(new CustomEvent('afra-toast', { detail: n ? `${msg} [কোড ${n}]` : msg }));
  }

  // Real Microphone Listening
  public async startListening(
    onResult: (transcript: string, isFinal: boolean) => void,
    onAudioLevel: (level: number) => void,
    onError: (err: string) => void
  ): Promise<boolean> {
    const mode = this.listenMode();
    if (mode === 'gemini' || (mode === 'auto' && this.phoneListenFailed)) {
      return this.startGeminiListening(onResult, onAudioLevel, onError);
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      return this.startGeminiListening(onResult, onAudioLevel, onError);
    }

    try {
      if (Native.available()) {
        // The phone's own listener reports the real microphone level.
        (window as any).__afraLevelCb = (v: number) => onAudioLevel(v);
      } else if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          this.mediaStream = stream;
          const ctx = this.initAudioContext();
          this.sourceNode = ctx.createMediaStreamSource(stream);
          this.analyser = ctx.createAnalyser();
          this.analyser.fftSize = 256;
          this.sourceNode.connect(this.analyser);

          const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
          const trackLevel = () => {
            if (!this.analyser) return;
            this.analyser.getByteFrequencyData(dataArray);
            let sum = 0;
            for (let i = 0; i < dataArray.length; i++) {
              sum += dataArray[i];
            }
            const average = sum / dataArray.length;
            const normalized = Math.min(1, average / 80);
            onAudioLevel(normalized);

            if (this.mediaStream) {
              requestAnimationFrame(trackLevel);
            }
          };
          requestAnimationFrame(trackLevel);
        } catch (micErr) {
          console.warn('Microphone stream access for visualizer optional or denied:', micErr);
          this.synthInterval = window.setInterval(() => {
            onAudioLevel(0.3 + Math.random() * 0.4);
          }, 80);
        }
      }

      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'bn-BD';

      this.recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        if (final) {
          onResult(final.trim(), true);
        } else if (interim) {
          onResult(interim.trim(), false);
        }
      };

      this.recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'no-speech' || event.error === 'aborted') return;
        const hard = ['service-not-allowed', 'audio-capture', 'network', 'language-not-supported', 'not-allowed'];
        if (mode === 'auto' && hard.includes(event.error)) {
          // The phone's listener does not work here: switch to Gemini listening and carry on.
          this.phoneListenFailed = true;
          this.explainListenError(event.error, event.code);
          window.dispatchEvent(
            new CustomEvent('afra-toast', { detail: 'ফোনের শোনা কাজ করছে না, তাই এখন Gemini দিয়ে শুনছি।' })
          );
          this.stopListening();
          void this.startGeminiListening(onResult, onAudioLevel, onError);
          return;
        }
        this.explainListenError(event.error, event.code);
        onError(event.error);
      };

      this.recognition.start();
      return true;
    } catch (err: any) {
      onError(err?.message || 'Failed to start microphone');
      return false;
    }
  }

  public stopListening(): void {
    (window as any).__afraLevelCb = null;
    if (this.geminiListener) {
      this.geminiListener.stop();
      this.geminiListener = null;
    }
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (e) {}
      this.recognition = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((t) => t.stop());
      this.mediaStream = null;
    }

    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }

    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
  }
}

export const SpeechAudioService = new AudioController();
