import { ChatMessage, PersonaMode } from '../types';
import { ApiKeyStorage } from './apiKeyStorage';

export interface SendMessageOptions {
  message: string;
  history: ChatMessage[];
  persona?: string;
  mode: PersonaMode;
  onChunk: (chunk: string) => void;
  onComplete: (fullText: string) => void;
  onError: (error: string) => void;
}

export const ChatApiService = {
  async sendMessageStream(options: SendMessageOptions): Promise<void> {
    const { message, history, persona, mode, onChunk, onComplete, onError } = options;

    const apiKey = ApiKeyStorage.getApiKey();
    if (!apiKey) {
      onError(
        'Personal Gemini API key is not configured. Please open Settings > API Configuration to set up your personal API key.'
      );
      return;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 45000);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-gemini-api-key': apiKey,
        },
        body: JSON.stringify({
          message,
          history: history.map((m) => ({ role: m.role, content: m.content })),
          persona,
          mode,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${response.status}`);
      }

      if (!response.body) {
        throw new Error('ReadableStream not supported by browser or empty body returned');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let fullText = '';
      let buffer = '';
      let streamError: string | null = null;

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || !trimmed.startsWith('data:')) continue;

          const dataStr = trimmed.slice(5).trim();
          if (dataStr === '[DONE]') {
            break;
          }

          try {
            const parsed = JSON.parse(dataStr);
            if (parsed.error) {
              streamError = parsed.error;
              break;
            }
            if (parsed.text) {
              fullText += parsed.text;
              onChunk(parsed.text);
            }
          } catch (jsonErr: any) {
            // Ignore partial chunk JSON errors
          }
        }

        if (streamError) break;
      }

      if (streamError) {
        throw new Error(streamError);
      }

      if (!fullText.trim()) {
        throw new Error('AFRA did not return any tokens. Please check connection and try again.');
      }

      onComplete(fullText);
    } catch (err: any) {
      clearTimeout(timeoutId);
      const isAbort = err?.name === 'AbortError';
      const msg = isAbort
        ? 'Response timed out (45s). AFRA neural core may be under high traffic. Please retry in a moment.'
        : err?.message || 'Connection to AFRA core interrupted';

      console.error('[ChatApiService] Stream error:', msg);
      onError(msg);
    }
  },

  async generateAvatarCode(prompt: string): Promise<string> {
    const apiKey = ApiKeyStorage.getApiKey();
    if (!apiKey) {
      throw new Error(
        'Personal Gemini API key is not configured. Please open Settings > API Configuration to save your key.'
      );
    }

    const response = await fetch('/api/avatar/generate-code', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-gemini-api-key': apiKey,
      },
      body: JSON.stringify({ prompt }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'Avatar code generation failed');
    }

    const data = await response.json();
    return data.code;
  },
};
