/**
 * Direct Gemini connector.
 * The original app talked to a Node server (/api/...). Inside the Android app there is
 * no server, so this file answers those same /api/... calls directly from the phone
 * by talking to Google's Gemini REST API with the user's own API key.
 */

const BASE = 'https://generativelanguage.googleapis.com/v1beta';
const CHAT_MODELS = ['gemini-2.5-flash-lite', 'gemini-2.5-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];

/** Turn off "thinking" on 2.5 flash models: replies start in about a second instead of many seconds. */
function fastConfig(model: string): any {
  return /gemini-2\.5-flash/.test(model) ? { generationConfig: { thinkingConfig: { thinkingBudget: 0 } } } : {};
}
const TTS_MODELS = ['gemini-2.5-flash-preview-tts', 'gemini-2.5-flash-tts', 'gemini-3.1-flash-tts-preview', 'gemini-2.5-pro-preview-tts'];

// Remember which model worked last, and try it first next time (saves time).
const goodModel: Record<string, string> = {};
function ordered(kind: string, models: string[]): string[] {
  const g = goodModel[kind];
  return g && models.includes(g) ? [g, ...models.filter((m) => m !== g)] : models;
}

type UpstreamError = { status: number; message: string };

/** fetch with a time limit, so the app never waits forever. */
async function timedFetch(url: string, init: RequestInit, ms = 25000, outer?: AbortSignal | null): Promise<Response> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  if (outer) outer.addEventListener('abort', () => ctrl.abort());
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } catch (e: any) {
    if (e?.name === 'AbortError' && !(outer && outer.aborted)) {
      throw new Error(`Could not reach Google within ${Math.round(ms / 1000)} seconds. Check your internet connection, or turn off any VPN/DNS blocker, then try again.`);
    }
    if (e instanceof TypeError) {
      throw new Error(`Cannot connect to Google servers (${e.message}). Check your internet connection or VPN.`);
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

function buildSystemInstruction(persona?: string, mode?: string): string {
  const base = `You are AFRA, an ultra-premium, cinematic AI assistant engineered with sophisticated elegance, calm confidence, and acute intelligence.
Your visual presence embodies matte obsidian, titanium silver, soft violet, and cool cyan illumination.
Tone: Articulate, poised, concise, insightful, natural, and never subservient or overly sycophantic.
Responses: Use clean markdown with clear formatting when needed. Keep answers punchy and conversational when spoken, or structured when requested for technical tasks.
Avoid robotic filler phrases like "As an AI" or repetitive boilerplate.
If the user writes in Bangla, reply in natural Bangla.`;
  let directive = 'Mode: Balanced Executive Companion.';
  if (mode === 'creative') directive = "Mode: Creative Synthesis. Be evocative, expressive, and imaginative while maintaining AFRA's refined dignity.";
  else if (mode === 'precise') directive = 'Mode: Precision & Logic. Prioritize high-density facts, mathematical accuracy, and zero ambiguity.';
  else if (mode === 'technical') directive = 'Mode: Technical Architect. Provide elegant code architectures, clean implementations, and system designs.';
  const p = persona ? `Custom Persona Modifier: ${persona}` : '';
  return `${base}\n\n${directive}\n${p}`.trim();
}

function json(obj: unknown, status = 200): Response {
  return new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json' } });
}

function friendlyError(e: UpstreamError | null): string {
  if (!e) return 'Unable to connect to AFRA with your configured key.';
  const m = e.message || '';
  if (e.status === 400 && /API key|API_KEY_INVALID/i.test(m)) return 'Invalid Gemini API key. Please check your key in Settings > API Configuration.';
  if (e.status === 403 || /PERMISSION_DENIED/i.test(m)) return 'Permission denied (403). Make sure the Generative Language API is enabled for your key.';
  if (e.status === 429) return 'ফ্রি ব্যবহারের সীমা শেষ (quota 429)। কিছুক্ষণ অপেক্ষা করে আবার চেষ্টা করুন। ভয়েস বেশি ব্যবহার করলে এটা দ্রুত শেষ হয়।';
  if (e.status === 503 || e.status === 504) return 'AFRA is experiencing high traffic. Please retry in a moment.';
  return m ? `${m} (code ${e.status})` : `Request failed (code ${e.status}).`;
}

async function readUpstreamError(res: Response): Promise<UpstreamError> {
  let message = '';
  try {
    const data = await res.json();
    message = data?.error?.message || '';
  } catch {
    /* ignore */
  }
  return { status: res.status, message };
}

function getKey(init: RequestInit | undefined, body: any): string {
  let headerKey = '';
  try {
    headerKey = new Headers(init?.headers as HeadersInit).get('x-gemini-api-key') || '';
  } catch {
    /* ignore */
  }
  return (headerKey || body?.apiKey || '').toString().trim();
}

function upstreamHeaders(key: string): HeadersInit {
  return { 'Content-Type': 'application/json', 'x-goog-api-key': key };
}

/* ---------------- /api/chat (streaming) ---------------- */
function handleChat(key: string, body: any, signal?: AbortSignal | null): Response {
  const { message, history = [], persona, mode } = body || {};
  if (!message || typeof message !== 'string') return json({ error: 'Message is required' }, 400);
  if (!key) return json({ error: 'Personal Gemini API key required. Please configure your key in Settings > API Configuration.' }, 401);

  const contents: any[] = [];
  if (Array.isArray(history)) {
    for (const item of history.slice(-8)) {
      if (item.role === 'user') contents.push({ role: 'user', parts: [{ text: item.content }] });
      else if (item.role === 'assistant') contents.push({ role: 'model', parts: [{ text: item.content }] });
    }
  }
  contents.push({ role: 'user', parts: [{ text: message }] });
  const systemInstruction = { parts: [{ text: buildSystemInstruction(persona, mode) }] };

  const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: unknown) => controller.enqueue(enc.encode(`data: ${typeof obj === 'string' ? obj : JSON.stringify(obj)}\n\n`));
      let lastError: UpstreamError | null = null;
      try {
        for (const model of ordered('chat', CHAT_MODELS)) {
          // Each model gets 12 seconds to start answering, otherwise we move on to the next one.
          const ctrl = new AbortController();
          let timedOut = false;
          const startTimer = setTimeout(() => {
            timedOut = true;
            ctrl.abort();
          }, 12000);
          const onOuterAbort = () => ctrl.abort();
          if (signal) signal.addEventListener('abort', onOuterAbort);
          try {
            const res = await fetch(`${BASE}/models/${model}:streamGenerateContent?alt=sse`, {
              method: 'POST',
              headers: upstreamHeaders(key),
              body: JSON.stringify({ systemInstruction, contents, ...fastConfig(model) }),
              signal: ctrl.signal,
            });
            if (!res.ok || !res.body) {
              const err = await readUpstreamError(res);
              if (err.status !== 404 || !lastError) lastError = err;
              clearTimeout(startTimer);
              continue;
            }
            const reader = res.body.getReader();
            const dec = new TextDecoder('utf-8');
            let buf = '';
            let chunks = 0;
            while (true) {
              const { value, done } = await reader.read();
              if (done) break;
              buf += dec.decode(value, { stream: true });
              const lines = buf.split('\n');
              buf = lines.pop() || '';
              for (const line of lines) {
                const t = line.trim();
                if (!t.startsWith('data:')) continue;
                try {
                  const parsed = JSON.parse(t.slice(5).trim());
                  const parts = parsed?.candidates?.[0]?.content?.parts || [];
                  const text = parts.filter((p: any) => p.text && !p.thought).map((p: any) => p.text).join('');
                  if (text) {
                    if (chunks === 0) clearTimeout(startTimer);
                    chunks++;
                    send({ text });
                  }
                } catch {
                  /* partial json */
                }
              }
            }
            clearTimeout(startTimer);
            if (chunks > 0) {
              goodModel['chat'] = model;
              send('[DONE]');
              controller.close();
              return;
            }
          } catch (e: any) {
            clearTimeout(startTimer);
            if (timedOut) {
              lastError = { status: 0, message: `Google did not respond within 12 seconds (model ${model}). Your internet may be slow, or a VPN may be interfering.` };
              continue; // try the next model
            }
            if (e?.name === 'AbortError') throw e;
            lastError = { status: 0, message: e?.message || 'Network error. Please check your internet connection.' };
            break;
          } finally {
            clearTimeout(startTimer);
            if (signal) signal.removeEventListener('abort', onOuterAbort);
          }
        }
        send({ error: friendlyError(lastError) });
        controller.close();
      } catch (e: any) {
        try {
          send({ error: e?.name === 'AbortError' ? 'Request timed out.' : e?.message || 'Failed to process AI response' });
          controller.close();
        } catch {
          /* closed */
        }
      }
    },
  });
  return new Response(stream, { status: 200, headers: { 'Content-Type': 'text/event-stream' } });
}

/* ---------------- one-shot generateContent helper ---------------- */
async function generateOnce(key: string, models: string[], payload: any, kind = 'misc'): Promise<{ data?: any; model?: string; error?: UpstreamError }> {
  let lastError: UpstreamError | null = null;
  for (const model of ordered(kind, models)) {
    try {
      const res = await timedFetch(`${BASE}/models/${model}:generateContent`, {
        method: 'POST',
        headers: upstreamHeaders(key),
        body: JSON.stringify({ ...payload, ...(payload.generationConfig ? {} : fastConfig(model)) }),
      }, 20000);
      if (res.ok) {
        goodModel[kind] = model;
        return { data: await res.json(), model };
      }
      const err = await readUpstreamError(res);
      if (err.status !== 404 || !lastError) lastError = err;
    } catch (e: any) {
      lastError = { status: 0, message: e?.message || 'Network error. Please check your internet connection.' };
      break; // no point trying other models if Google cannot be reached
    }
  }
  return { error: lastError || { status: 0, message: 'Unknown error' } };
}

/* ---------------- /api/avatar/generate-code ---------------- */
async function handleAvatarCode(key: string, body: any): Promise<Response> {
  if (!body?.prompt) return json({ error: 'Prompt is required' }, 400);
  if (!key) return json({ error: 'Personal Gemini API key required.' }, 401);
  const systemInstruction = `You are an elite creative technologist and WebGL/Canvas/CSS visual artist.
Generate a self-contained HTML/CSS/JavaScript code block for a reactive dark-themed AI avatar.
Requirements:
1. Return ONLY pure code that can be injected inside an isolated iframe.
2. Must listen to 'message' events from window:
   window.addEventListener('message', (e) => {
     const data = e.data; // { state: 'idle' | 'listening' | 'thinking' | 'speaking', audioLevel: number (0-1), tint: string }
   });
3. Visual style: Matte black background (#0b0d10), futuristic silver, glowing violet (#8b5cf6) or cyan (#06b6d4) elements.
4. No external scripts or libraries! Use vanilla Canvas 2D or SVG or pure CSS keyframes.
5. Provide high quality, 60fps silky smooth rendering.
6. Return code without markdown fences, or with standard HTML structure.`;
  const r = await generateOnce(key, CHAT_MODELS, {
    systemInstruction: { parts: [{ text: systemInstruction }] },
    contents: [{ role: 'user', parts: [{ text: `Create a futuristic interactive avatar based on: ${body.prompt}` }] }],
  });
  if (r.error) return json({ error: friendlyError(r.error) }, 500);
  const parts = r.data?.candidates?.[0]?.content?.parts || [];
  let code = parts.filter((p: any) => p.text && !p.thought).map((p: any) => p.text).join('');
  code = code.replace(/^```html\s*/i, '').replace(/^```\s*/i, '').replace(/```$/i, '').trim();
  if (!code) return json({ error: 'Failed to generate avatar code.' }, 500);
  return json({ code });
}

/* ---------------- /api/validate-key ---------------- */
async function handleValidate(key: string): Promise<Response> {
  if (!key) return json({ valid: false, error: 'Please enter a Gemini API key to validate.' }, 400);
  const r = await generateOnce(key, CHAT_MODELS, { contents: [{ role: 'user', parts: [{ text: 'Ping test. Reply with OK.' }] }] });
  if (r.error) return json({ valid: false, error: friendlyError(r.error), status: r.error.status }, 400);
  return json({ valid: true, provider: 'Google Gemini AI', model: r.model, status: 'Connected & Verified' });
}

/* ---------------- /api/tts ---------------- */
function pcmToWavBase64(b64: string, mimeType: string): string {
  const rateMatch = /rate=(\d+)/.exec(mimeType || '');
  const sampleRate = rateMatch ? parseInt(rateMatch[1], 10) : 24000;
  const bin = atob(b64);
  const pcm = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) pcm[i] = bin.charCodeAt(i);
  const header = new ArrayBuffer(44);
  const v = new DataView(header);
  const w = (o: number, s: string) => {
    for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i));
  };
  w(0, 'RIFF');
  v.setUint32(4, 36 + pcm.length, true);
  w(8, 'WAVE');
  w(12, 'fmt ');
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true);
  v.setUint16(22, 1, true);
  v.setUint32(24, sampleRate, true);
  v.setUint32(28, sampleRate * 2, true);
  v.setUint16(32, 2, true);
  v.setUint16(34, 16, true);
  w(36, 'data');
  v.setUint32(40, pcm.length, true);
  const wav = new Uint8Array(44 + pcm.length);
  wav.set(new Uint8Array(header), 0);
  wav.set(pcm, 44);
  let out = '';
  const CH = 0x8000;
  for (let i = 0; i < wav.length; i += CH) out += String.fromCharCode.apply(null, Array.from(wav.subarray(i, i + CH)));
  return btoa(out);
}

async function handleTts(key: string, body: any): Promise<Response> {
  const { text, voiceProfile = 'afra-soft' } = body || {};
  if (!text || typeof text !== 'string') return json({ error: 'Text parameter is required' }, 400);
  if (!key) return json({ error: 'Personal Gemini API key required.' }, 401);
  const clean = text.replace(/```[\s\S]*?```/g, '').replace(/\[([^\]]+)\]\([^)]+\)/g, '$1').replace(/[*#`_~]/g, '').trim();
  if (!clean) return json({ error: 'Text is empty after stripping formatting' }, 400);
  const profiles: Record<string, { voice: string; style: string }> = {
    'afra-soft': { voice: 'Achernar', style: 'Say in a very soft, sweet, gentle and warm feminine voice' },
    'afra-elegant': { voice: 'Kore', style: 'Say in a clear, confident, poised and expressive feminine voice' },
    'afra-male': { voice: 'Charon', style: 'Say in a normal, calm and friendly male voice' },
  };
  const prof = profiles[voiceProfile] || profiles['afra-soft'];
  const voiceName = prof.voice;
  const r = await generateOnce(
    key,
    TTS_MODELS,
    {
      contents: [{ parts: [{ text: `${prof.style}: ${clean.slice(0, 600)}` }] }],
      generationConfig: {
        responseModalities: ['AUDIO'],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName } } },
      },
    },
    'tts'
  );
  if (r.error) return json({ error: friendlyError(r.error) }, 500);
  const inline = r.data?.candidates?.[0]?.content?.parts?.find((p: any) => p.inlineData)?.inlineData;
  if (!inline?.data) return json({ error: 'Speech synthesis returned no audio.' }, 500);
  return json({ audioData: pcmToWavBase64(inline.data, inline.mimeType || ''), mimeType: 'audio/wav', voice: voiceName, profile: voiceProfile });
}

/* ---------------- fetch interceptor ---------------- */
export function installDirectGemini(): void {
  if (typeof window === 'undefined' || (window as any).__afraDirectInstalled) return;
  (window as any).__afraDirectInstalled = true;
  const originalFetch = window.fetch.bind(window);

  window.fetch = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    let path = '';
    try {
      const raw = typeof input === 'string' ? input : input instanceof URL ? input.href : (input as Request).url;
      const u = new URL(raw, window.location.href);
      if (u.origin === window.location.origin && u.pathname.startsWith('/api/')) path = u.pathname;
    } catch {
      /* not a URL we understand */
    }
    if (!path) return originalFetch(input as any, init);

    let body: any = {};
    try {
      if (typeof init?.body === 'string') body = JSON.parse(init.body);
    } catch {
      /* ignore */
    }
    const key = getKey(init, body);

    switch (path) {
      case '/api/chat':
        return handleChat(key, body, init?.signal);
      case '/api/tts':
        return handleTts(key, body);
      case '/api/avatar/generate-code':
        return handleAvatarCode(key, body);
      case '/api/validate-key':
        return handleValidate(key);
      case '/api/env-key-available':
        return json({ available: false });
      case '/api/env-key-import':
        return json({ error: 'No environment key on this device.' }, 404);
      case '/api/health':
        return json({ status: 'online', app: 'AFRA', mode: 'on-device' });
      default:
        return json({ error: 'Not found' }, 404);
    }
  };
}
