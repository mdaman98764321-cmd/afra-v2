export const KOTLIN_OVERLAY_SERVICE_CODE = `// AfraOverlayService.kt
package com.afra.assistant.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.afra.assistant.MainActivity
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Android Foreground Service managing the AFRA Floating Avatar Overlay.
 * Uses WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY on Android 8.0+ (API 26+)
 * with touch-drag tracking, edge snapping, screen rotation safety, and a persistent
 * foreground notification respecting Android 12+ background limits & Android 13+ POST_NOTIFICATIONS.
 */
class AfraOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var preferences: SharedPreferences
    private var overlayView: AfraOverlayView? = null
    private var quickActionMenu: QuickActionMenu? = null
    private lateinit var layoutParams: WindowManager.LayoutParams

    private var screenWidth = 0
    private var screenHeight = 0
    private var avatarSizePx = 0

    // Touch physics & drag state tracking
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var touchStartTime = 0L
    private var isDragging = false

    private var currentState = "idle"
    private var isMicrophoneActive = false

    companion object {
        const val CHANNEL_ID = "afra_floating_overlay_channel"
        const val NOTIFICATION_ID = 4041
        const val PREFS_NAME = "afra_overlay_prefs"
        const val KEY_POS_X = "overlay_x"
        const val KEY_POS_Y = "overlay_y"

        const val ACTION_START_OVERLAY = "com.afra.assistant.action.START_OVERLAY"
        const val ACTION_STOP_OVERLAY = "com.afra.assistant.action.STOP_OVERLAY"
        const val ACTION_SET_STATE = "com.afra.assistant.action.SET_STATE"
        const val ACTION_START_VOICE = "com.afra.assistant.action.START_VOICE"
        const val ACTION_STOP_VOICE = "com.afra.assistant.action.STOP_VOICE"
        const val EXTRA_STATE = "extra_state"
        const val EXTRA_AUDIO_LEVEL = "extra_audio_level"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        preferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        updateScreenDimensions()
        val density = resources.displayMetrics.density
        avatarSizePx = (56 * density).toInt()

        createNotificationChannel()
        startForegroundWithNotification()

        initOverlayView()
        initQuickActionMenu()
    }

    private fun updateScreenDimensions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowMetrics = windowManager.currentWindowMetrics
            val insets = windowMetrics.windowInsets.getInsetsIgnoringVisibility(
                android.view.WindowInsets.Type.systemBars()
            )
            screenWidth = windowMetrics.bounds.width() - insets.left - insets.right
            screenHeight = windowMetrics.bounds.height() - insets.top - insets.bottom
        } else {
            val display = windowManager.defaultDisplay
            val size = Point()
            display.getSize(size)
            screenWidth = size.x
            screenHeight = size.y
        }
    }

    private fun initOverlayView() {
        if (!OverlayPermissionHelper.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val savedX = preferences.getInt(KEY_POS_X, screenWidth - avatarSizePx - 24)
        val savedY = preferences.getInt(KEY_POS_Y, (screenHeight * 0.35f).toInt())

        layoutParams = WindowManager.LayoutParams(
            avatarSizePx,
            avatarSizePx,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = clampX(savedX)
            y = clampY(savedY)
        }

        overlayView = AfraOverlayView(this).apply {
            setOnTouchListener(createTouchListener())
        }

        try {
            windowManager.addView(overlayView, layoutParams)
        } catch (e: Exception) {
            e.printStackTrace()
            stopSelf()
        }
    }

    private fun initQuickActionMenu() {
        quickActionMenu = QuickActionMenu(
            context = this,
            windowManager = windowManager,
            onOpenChat = {
                quickActionMenu?.dismiss()
                launchAppWithAction("open_chat")
            },
            onStartVoice = {
                quickActionMenu?.dismiss()
                startVoiceSession()
            },
            onQuickMessage = {
                quickActionMenu?.showQuickInputModal(
                    onSend = { query ->
                        handleQuickQuery(query)
                    }
                )
            },
            onReturnToApp = {
                quickActionMenu?.dismiss()
                launchAppWithAction("return_app")
            },
            onHide = {
                quickActionMenu?.dismiss()
                overlayView?.visibility = View.GONE
            },
            onClose = {
                quickActionMenu?.dismiss()
                stopSelf()
            }
        )
    }

    private fun createTouchListener(): View.OnTouchListener {
        val clickThresholdPx = 10 * resources.displayMetrics.density

        return View.OnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    touchStartTime = System.currentTimeMillis()
                    isDragging = false
                    overlayView?.setPressedScale(true)
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val deltaX = event.rawX - initialTouchX
                    val deltaY = event.rawY - initialTouchY

                    if (abs(deltaX) > clickThresholdPx || abs(deltaY) > clickThresholdPx) {
                        isDragging = true
                        quickActionMenu?.dismiss()
                    }

                    if (isDragging) {
                        layoutParams.x = clampX((initialX + deltaX).toInt())
                        layoutParams.y = clampY((initialY + deltaY).toInt())
                        windowManager.updateViewLayout(overlayView, layoutParams)
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    overlayView?.setPressedScale(false)
                    val duration = System.currentTimeMillis() - touchStartTime

                    if (!isDragging && duration < 300) {
                        toggleQuickActionMenu()
                    } else if (isDragging) {
                        snapToNearestEdge()
                    }
                    true
                }

                else -> false
            }
        }
    }

    private fun snapToNearestEdge() {
        val centerX = layoutParams.x + (avatarSizePx / 2)
        val targetX = if (centerX < screenWidth / 2) {
            16
        } else {
            screenWidth - avatarSizePx - 16
        }

        layoutParams.x = targetX
        layoutParams.y = clampY(layoutParams.y)
        windowManager.updateViewLayout(overlayView, layoutParams)

        preferences.edit()
            .putInt(KEY_POS_X, layoutParams.x)
            .putInt(KEY_POS_Y, layoutParams.y)
            .apply()
    }

    private fun toggleQuickActionMenu() {
        if (quickActionMenu?.isShowing() == true) {
            quickActionMenu?.dismiss()
        } else {
            val posX = layoutParams.x
            val posY = layoutParams.y
            val showOnLeft = posX > (screenWidth / 2)
            quickActionMenu?.show(posX, posY, showOnLeft)
        }
    }

    private fun clampX(x: Int): Int = max(0, min(x, screenWidth - avatarSizePx))
    private fun clampY(y: Int): Int = max(48, min(y, screenHeight - avatarSizePx - 80))

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateScreenDimensions()
        snapToNearestEdge()
    }

    private fun startVoiceSession() {
        isMicrophoneActive = true
        setAvatarAnimationState("listening")
        updateNotification()
        overlayView?.showMicrophoneIndicator(true)
    }

    private fun stopVoiceSession() {
        isMicrophoneActive = false
        setAvatarAnimationState("idle")
        updateNotification()
        overlayView?.showMicrophoneIndicator(false)
    }

    private fun handleQuickQuery(query: String) {
        setAvatarAnimationState("thinking")
        val intent = Intent("com.afra.assistant.QUICK_QUERY").apply {
            putExtra("query", query)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    private fun launchAppWithAction(action: String) {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("afra_action", action)
        }
        startActivity(launchIntent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AFRA Floating Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Status for AFRA Floating Avatar Overlay"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE)
        }
        val stopIntent = Intent(this, AfraOverlayService::class.java).apply {
            action = ACTION_STOP_OVERLAY
        }.let {
            PendingIntent.getService(this, 1, it, PendingIntent.FLAG_IMMUTABLE)
        }

        val contentText = if (isMicrophoneActive) {
            "Voice Mode Active • Listening (Mic On)"
        } else {
            "AFRA is floating above other apps • Tap to interact"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AFRA Floating Assistant")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Close Overlay", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun startForegroundWithNotification() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    override fun onDestroy() {
        super.onDestroy()
        quickActionMenu?.dismiss()
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {}
        }
        overlayView = null
    }
}
`;

export const KOTLIN_OVERLAY_VIEW_CODE = `// AfraOverlayView.kt
package com.afra.assistant.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator

class AfraOverlayView(context: Context) : View(context) {

    private var currentState = "idle"
    private var audioAmplitude = 0f
    private var isPressedScale = false
    private var showMicIndicator = false

    private val colorViolet = Color.parseColor("#8B5CF6")
    private val colorCyan = Color.parseColor("#06B6D4")
    private val colorEmerald = Color.parseColor("#10B981")
    private val colorRose = Color.parseColor("#F43F5E")
    private val colorBgDark = Color.parseColor("#0B0D10")
    private val colorBorder = Color.parseColor("#334155")

    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * resources.displayMetrics.density
        color = colorBorder
    }
    private val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
        color = colorViolet
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = colorBgDark
    }
    private val micBadgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = colorCyan
    }

    fun setAnimationState(state: String, level: Float = 0f) {
        currentState = state.lowercase()
        audioAmplitude = level
        invalidate()
    }

    fun setPressedScale(pressed: Boolean) {
        isPressedScale = pressed
        invalidate()
    }

    fun showMicrophoneIndicator(show: Boolean) {
        showMicIndicator = show
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = (width.coerceAtMost(height) / 2f) - (8f * resources.displayMetrics.density)

        val glowColor = when (currentState) {
            "listening" -> colorCyan
            "thinking" -> colorViolet
            "speaking" -> colorCyan
            "happy" -> colorEmerald
            "error" -> colorRose
            else -> colorViolet
        }

        // Draw outer reactive glow halo
        haloPaint.shader = RadialGradient(cx, cy, baseRadius + 12f, glowColor, Color.TRANSPARENT, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, baseRadius + 12f, haloPaint)

        // Draw core
        canvas.drawCircle(cx, cy, baseRadius, corePaint)
        borderPaint.color = glowColor
        canvas.drawCircle(cx, cy, baseRadius, borderPaint)

        // Mic privacy badge
        if (showMicIndicator || currentState == "listening") {
            canvas.drawCircle(cx + (baseRadius * 0.7f), cy - (baseRadius * 0.7f), 5f * resources.displayMetrics.density, micBadgePaint)
        }
    }
}
`;

export const KOTLIN_QUICK_ACTION_MENU_CODE = `// QuickActionMenu.kt
package com.afra.assistant.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class QuickActionMenu(
    private val context: Context,
    private val windowManager: WindowManager,
    private val onOpenChat: () -> Unit,
    private val onStartVoice: () -> Unit,
    private val onQuickMessage: () -> Unit,
    private val onReturnToApp: () -> Unit,
    private val onHide: () -> Unit,
    private val onClose: () -> Unit
) {
    private var menuView: View? = null
    private var isShowing = false

    fun isShowing(): Boolean = isShowing

    fun show(avatarX: Int, avatarY: Int, showOnLeft: Boolean) {
        if (isShowing) return
        val density = context.resources.displayMetrics.density
        val menuWidthPx = (220 * density).toInt()

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (12 * density).toInt()
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0E1217"))
                setStroke((1 * density).toInt(), Color.parseColor("#1E293B"))
                cornerRadius = 16 * density
            }
        }

        val actions = listOf(
            Triple("💬  Open Afra Chat", Color.parseColor("#8B5CF6"), onOpenChat),
            Triple("🎙️  Start Voice Mode", Color.parseColor("#06B6D4"), onStartVoice),
            Triple("⚡  Quick Message", Color.WHITE, onQuickMessage),
            Triple("📱  Return to Full App", Color.parseColor("#94A3B8"), onReturnToApp),
            Triple("👁️  Hide Avatar", Color.parseColor("#64748B"), onHide),
            Triple("✕  Close Assistant", Color.parseColor("#F43F5E"), onClose)
        )

        for ((title, color, onClick) in actions) {
            val btn = Button(context).apply {
                text = title
                setTextColor(color)
                textSize = 12f
                isAllCaps = false
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#161D26"))
                    cornerRadius = 10 * density
                }
                setOnClickListener { onClick() }
            }
            root.addView(btn)
        }

        val layoutParams = WindowManager.LayoutParams(
            menuWidthPx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (showOnLeft) avatarX - menuWidthPx - 16 else avatarX + 70
            y = avatarY
        }

        windowManager.addView(root, layoutParams)
        menuView = root
        isShowing = true
    }

    fun dismiss() {
        if (!isShowing) return
        menuView?.let { windowManager.removeView(it) }
        menuView = null
        isShowing = false
    }
}
`;

export const KOTLIN_PERMISSION_HELPER_CODE = `// OverlayPermissionHelper.kt
package com.afra.assistant.overlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

object OverlayPermissionHelper {
    fun canDrawOverlays(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else true
    }

    fun requestOverlayPermission(activity: Activity, requestCode: Int = 5001) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + activity.packageName)
            )
            activity.startActivityForResult(intent, requestCode)
        }
    }
}
`;

export const KOTLIN_BRIDGE_CODE = `// AfraNativeBridge.kt
package com.afra.assistant.bridge

import android.app.Activity
import android.content.Intent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.afra.assistant.overlay.AfraOverlayService
import com.afra.assistant.overlay.OverlayPermissionHelper

class AfraNativeBridge(private val activity: Activity, private val webView: WebView) {

    @JavascriptInterface
    fun isOverlayPermissionGranted(): Boolean = OverlayPermissionHelper.canDrawOverlays(activity)

    @JavascriptInterface
    fun requestOverlayPermission() {
        activity.runOnUiThread { OverlayPermissionHelper.requestOverlayPermission(activity) }
    }

    @JavascriptInterface
    fun startOverlayService() {
        activity.runOnUiThread {
            val intent = Intent(activity, AfraOverlayService::class.java).apply {
                action = AfraOverlayService.ACTION_START_OVERLAY
            }
            activity.startForegroundService(intent)
        }
    }

    @JavascriptInterface
    fun stopOverlayService() {
        activity.runOnUiThread {
            val intent = Intent(activity, AfraOverlayService::class.java).apply {
                action = AfraOverlayService.ACTION_STOP_OVERLAY
            }
            activity.stopService(intent)
        }
    }
}
`;

export const JETPACK_COMPOSE_SPEC = `// AfraScreen.kt
package com.afra.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import android.webkit.WebView
import com.afra.assistant.bridge.AfraNativeBridge

@Composable
fun AfraAssistantScreen(bridge: AfraNativeBridge) {
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0B0D10))) {
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    addJavascriptInterface(bridge, "AndroidAfraBridge")
                    loadUrl("https://afra.ai")
                }
            }
        )
    }
}
`;

export const ANDROID_MANIFEST_SNIPPET = `<!-- AndroidManifest.xml -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.afra.assistant">

    <!-- Permissions required for Floating WindowManager Overlay -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <!-- AI Voice and Core Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:label="AFRA"
        android:theme="@style/Theme.Afra.Dark">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Floating Avatar Overlay Foreground Service -->
        <service
            android:name=".overlay.AfraOverlayService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="specialUse" />

    </application>
</manifest>`;

export const PACKAGING_INSTRUCTIONS = `# Android Studio APK Packaging Guide for AFRA

1. Prerequisites:
   - Android Studio Ladybug or newer
   - Android SDK 35 (compileSdk = 35, minSdk = 26)
   - JDK 17+

2. Project Structure:
   - Place all Kotlin files under \`android/app/src/main/java/com/afra/assistant/\`
   - Copy \`AndroidManifest.xml\` to \`android/app/src/main/\`
   - Point the WebView to your hosted AFRA instance or bundle the web build into \`app/src/main/assets/\`

3. Permissions:
   - When the user first taps "Launch Floating Overlay", \`OverlayPermissionHelper.requestOverlayPermission()\` opens the Android Settings page "Display over other apps".
   - Once granted, \`AfraOverlayService\` runs as a Foreground Service with an un-dismissible notification while active.
   - Microphone access is strictly opt-in: only triggered when the user taps "Start Voice Mode".
`;
