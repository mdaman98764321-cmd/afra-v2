import { ApiKeyStorage } from './apiKeyStorage';

/**
 * Listens through the microphone, detects when the person finishes a sentence,
 * and asks Gemini to turn that recording into text.
 * Used when the phone's own speech recognition cannot be used.
 */
export class GeminiListener {
  private ctx: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private src: MediaStreamAudioSourceNode | null = null;
  private proc: ScriptProcessorNode | null = null;
  private active = false;
  private busy = false;

  private pre: Float32Array[] = [];
  private chunks: Float32Array[] = [];
  private speaking = false;
  private loudBlocks = 0;
  private silentMs = 0;
  private speechMs = 0;
  private floor = 0.004;

  async start(
    onResult: (text: string, isFinal: boolean) => void,
    onLevel: (level: number) => void,
    onError: (err: string) => void
  ): Promise<boolean> {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
    } catch (e: any) {
      onError('not-allowed');
      return false;
    }
    try {
      const AC = (window as any).AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AC();
      if (this.ctx!.state === 'suspended') await this.ctx!.resume();
      this.src = this.ctx!.createMediaStreamSource(this.stream);
      this.proc = this.ctx!.createScriptProcessor(4096, 1, 1);
      this.active = true;
      const sr = this.ctx!.sampleRate;
      const blockMs = (4096 / sr) * 1000;

      this.proc.onaudioprocess = (ev: AudioProcessingEvent) => {
        if (!this.active || this.busy) return;
        const input = ev.inputBuffer.getChannelData(0);
        const block = new Float32Array(input);
        let sum = 0;
        for (let i = 0; i < block.length; i++) sum += block[i] * block[i];
        const rms = Math.sqrt(sum / block.length);
        onLevel(Math.min(1, rms * 9));

        const thr = Math.max(0.02, this.floor * 3);
        if (!this.speaking) {
          this.floor = Math.max(0.003, this.floor * 0.97 + rms * 0.03);
          this.pre.push(block);
          if (this.pre.length > 4) this.pre.shift();
          this.loudBlocks = rms > thr ? this.loudBlocks + 1 : 0;
          if (this.loudBlocks >= 2) {
            this.speaking = true;
            this.chunks = [...this.pre];
            this.pre = [];
            this.silentMs = 0;
            this.speechMs = 0;
            onResult('শুনছি…', false);
          }
        } else {
          this.chunks.push(block);
          if (rms < thr * 0.8) this.silentMs += blockMs;
          else {
            this.silentMs = 0;
            this.speechMs += blockMs;
          }
          if (this.silentMs >= 1200 || this.chunks.length * blockMs > 25000) {
            void this.finish(sr, onResult, onError);
          }
        }
      };

      this.src.connect(this.proc);
      this.proc.connect(this.ctx!.destination);
      return true;
    } catch (e: any) {
      onError('audio-capture');
      return false;
    }
  }

  private async finish(
    sr: number,
    onResult: (text: string, isFinal: boolean) => void,
    onError: (err: string) => void
  ) {
    this.busy = true;
    const chunks = this.chunks;
    const enough = this.speechMs >= 350;
    this.chunks = [];
    this.pre = [];
    this.speaking = false;
    this.loudBlocks = 0;
    if (!enough) {
      this.busy = false;
      onResult('', false);
      return;
    }
    onResult('বুঝছি…', false);
    try {
      const wav = this.toWavBase64(chunks, sr);
      const res = await fetch('/api/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-gemini-api-key': ApiKeyStorage.getApiKey() || '' },
        body: JSON.stringify({ audio: wav, mime: 'audio/wav' }),
      });
      const data = await res.json().catch(() => ({}));
      if (!this.active) return;
      if (!res.ok) {
        this.busy = false;
        onError('network');
        window.dispatchEvent(new CustomEvent('afra-toast', { detail: data.error || 'কথা বোঝা গেল না।' }));
        return;
      }
      if (data.text) {
        onResult(String(data.text), true);
      } else {
        this.busy = false;
        onResult('', false);
      }
    } catch (e: any) {
      this.busy = false;
      onError('network');
    }
  }

  private toWavBase64(chunks: Float32Array[], sr: number): string {
    let total = 0;
    for (const c of chunks) total += c.length;
    const all = new Float32Array(total);
    let o = 0;
    for (const c of chunks) {
      all.set(c, o);
      o += c.length;
    }
    const target = 16000;
    const ratio = sr / target;
    const outLen = Math.floor(all.length / ratio);
    const pcm = new Int16Array(outLen);
    for (let i = 0; i < outLen; i++) {
      const a = Math.floor(i * ratio);
      const b = Math.min(all.length, Math.floor((i + 1) * ratio));
      let acc = 0;
      let n = 0;
      for (let j = a; j < b; j++) {
        acc += all[j];
        n++;
      }
      const v = Math.max(-1, Math.min(1, n ? acc / n : 0));
      pcm[i] = v < 0 ? v * 0x8000 : v * 0x7fff;
    }
    const buf = new ArrayBuffer(44 + pcm.length * 2);
    const dv = new DataView(buf);
    const w = (off: number, s: string) => {
      for (let i = 0; i < s.length; i++) dv.setUint8(off + i, s.charCodeAt(i));
    };
    w(0, 'RIFF');
    dv.setUint32(4, 36 + pcm.length * 2, true);
    w(8, 'WAVE');
    w(12, 'fmt ');
    dv.setUint32(16, 16, true);
    dv.setUint16(20, 1, true);
    dv.setUint16(22, 1, true);
    dv.setUint32(24, target, true);
    dv.setUint32(28, target * 2, true);
    dv.setUint16(32, 2, true);
    dv.setUint16(34, 16, true);
    w(36, 'data');
    dv.setUint32(40, pcm.length * 2, true);
    new Uint8Array(buf, 44).set(new Uint8Array(pcm.buffer));
    const bytes = new Uint8Array(buf);
    let bin = '';
    const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) bin += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + CH)));
    return btoa(bin);
  }

  stop(): void {
    this.active = false;
    this.busy = false;
    try {
      this.proc?.disconnect();
      this.src?.disconnect();
    } catch {
      /* ignore */
    }
    this.stream?.getTracks().forEach((t) => t.stop());
    try {
      void this.ctx?.close();
    } catch {
      /* ignore */
    }
    this.proc = null;
    this.src = null;
    this.stream = null;
    this.ctx = null;
    this.chunks = [];
    this.pre = [];
    this.speaking = false;
  }
}
