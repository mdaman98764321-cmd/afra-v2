/**
 * Thin wrapper around the Android side (window.AfraNative).
 * Every call is safe: in a normal browser (no Android) they simply return "off".
 */
const n = (): any => (typeof window !== 'undefined' ? (window as any).AfraNative : undefined);

function call<T>(fn: (b: any) => T, fallback: T): T {
  try {
    const b = n();
    return b ? fn(b) : fallback;
  } catch {
    return fallback;
  }
}

export interface NativeNotification {
  app: string;
  title: string;
  text: string;
  time: number;
}

export const Native = {
  available: (): boolean => !!n(),

  // floating avatar
  hasOverlayPermission: () => call((b) => !!b.hasOverlayPermission(), false),
  requestOverlayPermission: () => call((b) => b.requestOverlayPermission(), undefined),
  isOverlayRunning: () => call((b) => !!b.isOverlayRunning(), false),
  startOverlay: () => call((b) => b.startOverlay(), undefined),
  stopOverlay: () => call((b) => b.stopOverlay(), undefined),

  // "Hey AFRA" background listening
  isWakeRunning: () => call((b) => !!b.isWakeRunning(), false),
  startWake: () => call((b) => b.startWake(), undefined),
  stopWake: () => call((b) => b.stopWake(), undefined),
  setWakePhrases: (phrases: string[]) => call((b) => b.setWakePhrases(JSON.stringify(phrases)), undefined),
  setWakeLanguage: (lang: string) => call((b) => b.setWakeLanguage(lang), undefined),
  requestBatteryUnrestricted: () => call((b) => b.requestBatteryUnrestricted(), undefined),

  // phone control
  openApp: (name: string): string => call((b) => String(b.openApp(name) || ''), ''),
  hasNotificationAccess: () => call((b) => !!b.hasNotificationAccess(), false),
  openNotificationAccessSettings: () => call((b) => b.openNotificationAccessSettings(), undefined),
  getNotifications: (): NativeNotification[] =>
    call((b) => {
      try {
        return JSON.parse(b.getNotifications() || '[]');
      } catch {
        return [];
      }
    }, [] as NativeNotification[]),
};

const PHRASES_KEY = 'afra_wake_phrases_v1';
export const DEFAULT_WAKE_PHRASES = ['হ্যালো আফরা', 'hello afra', 'hey afra'];

export function loadWakePhrases(): string[] {
  try {
    const raw = localStorage.getItem(PHRASES_KEY);
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr) && arr.length) return arr;
    }
  } catch {
    /* ignore */
  }
  return DEFAULT_WAKE_PHRASES;
}

export function saveWakePhrases(phrases: string[]): void {
  try {
    localStorage.setItem(PHRASES_KEY, JSON.stringify(phrases));
  } catch {
    /* ignore */
  }
  Native.setWakePhrases(phrases);
}
