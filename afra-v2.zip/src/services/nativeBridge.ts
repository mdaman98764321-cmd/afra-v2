/**
 * Thin wrapper around the Android side (window.AfraNative).
 * Every call is safe: in a normal browser (no Android) they simply return "off".
 */
const n = (): any => (typeof window !== 'undefined' ? (window as any).AfraNative : undefined);

function call<T>(fn: (b: any) => T, fallback: T): T {
  try {
    const b = n();
    return b ? fn(b) : fallback;
  } catch {
    return fallback;
  }
}

export interface NativeNotification {
  app: string;
  title: string;
  text: string;
  time: number;
}

export const Native = {
  available: (): boolean => !!n(),

  // floating avatar
  hasOverlayPermission: () => call((b) => !!b.hasOverlayPermission(), false),
  requestOverlayPermission: () => call((b) => b.requestOverlayPermission(), undefined),
  isOverlayRunning: () => call((b) => !!b.isOverlayRunning(), false),
  startOverlay: () => call((b) => b.startOverlay(), undefined),
  stopOverlay: () => call((b) => b.stopOverlay(), undefined),

  setOverlayAvatar: (base64Png: string) => call((b) => b.setOverlayAvatar(base64Png), undefined),
  clearOverlayAvatar: () => call((b) => b.clearOverlayAvatar(), undefined),

  // "Hey AFRA" background listening
  isWakeRunning: () => call((b) => !!b.isWakeRunning(), false),
  startWake: () => call((b) => b.startWake(), undefined),
  stopWake: () => call((b) => b.stopWake(), undefined),
  setWakePhrases: (phrases: string[]) => call((b) => b.setWakePhrases(JSON.stringify(phrases)), undefined),
  setWakeLanguage: (lang: string) => call((b) => b.setWakeLanguage(lang), undefined),
  requestBatteryUnrestricted: () => call((b) => b.requestBatteryUnrestricted(), undefined),

  // phone control
  openApp: (name: string): string => call((b) => String(b.openApp(name) || ''), ''),
  hasNotificationAccess: () => call((b) => !!b.hasNotificationAccess(), false),
  openNotificationAccessSettings: () => call((b) => b.openNotificationAccessSettings(), undefined),
  getNotifications: (): NativeNotification[] =>
    call((b) => {
      try {
        return JSON.parse(b.getNotifications() || '[]');
      } catch {
        return [];
      }
    }, [] as NativeNotification[]),
};

const PHRASES_KEY = 'afra_wake_phrases_v1';
export const DEFAULT_WAKE_PHRASES = ['হ্যালো আফরা', 'hello afra', 'hey afra'];

export function loadWakePhrases(): string[] {
  try {
    const raw = localStorage.getItem(PHRASES_KEY);
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr) && arr.length) return arr;
    }
  } catch {
    /* ignore */
  }
  return DEFAULT_WAKE_PHRASES;
}

export function saveWakePhrases(phrases: string[]): void {
  try {
    localStorage.setItem(PHRASES_KEY, JSON.stringify(phrases));
  } catch {
    /* ignore */
  }
  Native.setWakePhrases(phrases);
}

/** Sends the chosen avatar picture to the floating avatar on the phone screen (or resets to the default). */
export function pushOverlayAvatar(url?: string): void {
  if (!Native.available()) return;
  if (!url) {
    Native.clearOverlayAvatar();
    return;
  }
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.onload = () => {
    try {
      const size = 256;
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const side = Math.min(img.width, img.height);
      ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, size, size);
      const data = canvas.toDataURL('image/png').split(',')[1];
      if (data) Native.setOverlayAvatar(data);
    } catch {
      /* ignore */
    }
  };
  img.src = url;
}

/* ---------- free back-up voice (used when the Gemini voice allowance is used up) ---------- */
const edgePending = new Map<string, (r: { audio?: string; error?: string }) => void>();
if (typeof window !== 'undefined') {
  (window as any).__afraEdgeResult = (id: string, b64: string, err: string) => {
    const cb = edgePending.get(id);
    if (!cb) return;
    edgePending.delete(id);
    cb(b64 ? { audio: b64 } : { error: err || 'Free voice failed.' });
  };
}

export function edgeVoiceFor(profile: string, text: string): { voice: string; rate: string } {
  const bangla = /[\u0980-\u09FF]/.test(text);
  if (bangla) {
    if (profile === 'afra-male') return { voice: 'bn-BD-PradeepNeural', rate: '+0%' };
    if (profile === 'afra-elegant') return { voice: 'bn-IN-TanishaaNeural', rate: '+3%' };
    return { voice: 'bn-BD-NabanitaNeural', rate: '-8%' };
  }
  if (profile === 'afra-male') return { voice: 'en-US-GuyNeural', rate: '+0%' };
  if (profile === 'afra-elegant') return { voice: 'en-US-AriaNeural', rate: '+3%' };
  return { voice: 'en-US-JennyNeural', rate: '-8%' };
}

export function edgeSpeak(text: string, profile: string): Promise<{ audio?: string; error?: string }> {
  return new Promise((resolve) => {
    const b = n();
    if (!b || typeof b.edgeTts !== 'function') {
      resolve({ error: 'Free voice is only available in the Android app.' });
      return;
    }
    const id = Math.random().toString(36).slice(2);
    const timer = setTimeout(() => {
      edgePending.delete(id);
      resolve({ error: 'Free voice timed out.' });
    }, 30000);
    edgePending.set(id, (r) => {
      clearTimeout(timer);
      resolve(r);
    });
    try {
      const v = edgeVoiceFor(profile, text);
      b.edgeTts(id, text, v.voice, v.rate);
    } catch (e: any) {
      clearTimeout(timer);
      edgePending.delete(id);
      resolve({ error: e?.message || 'Free voice failed.' });
    }
  });
}

export function simpleSpeak(text: string): Promise<{ audio?: string; error?: string }> {
  return new Promise((resolve) => {
    const b = n();
    if (!b || typeof b.simpleTts !== 'function') {
      resolve({ error: 'Back-up voice is only available in the Android app.' });
      return;
    }
    const id = Math.random().toString(36).slice(2);
    const timer = setTimeout(() => {
      edgePending.delete(id);
      resolve({ error: 'Back-up voice timed out.' });
    }, 30000);
    edgePending.set(id, (r) => {
      clearTimeout(timer);
      resolve(r);
    });
    try {
      const lang = /[\u0980-\u09FF]/.test(text) ? 'bn' : 'en';
      b.simpleTts(id, text, lang);
    } catch (e: any) {
      clearTimeout(timer);
      edgePending.delete(id);
      resolve({ error: e?.message || 'Back-up voice failed.' });
    }
  });
}

/* ---------- plain internet request made by the phone (no browser limits) ---------- */
const httpPending = new Map<string, (r: { status: number; b64: string; error: string }) => void>();
if (typeof window !== 'undefined') {
  (window as any).__afraHttpResult = (id: string, status: number, b64: string, err: string) => {
    const cb = httpPending.get(id);
    if (!cb) return;
    httpPending.delete(id);
    cb({ status, b64, error: err });
  };
}

export function nativeHttp(
  method: 'GET' | 'POST',
  url: string,
  headers: Record<string, string>,
  body?: string
): Promise<{ status: number; b64: string; error: string }> {
  return new Promise((resolve) => {
    const b = n();
    if (!b || typeof b.httpRequest !== 'function') {
      resolve({ status: 0, b64: '', error: 'Only available in the Android app.' });
      return;
    }
    const id = Math.random().toString(36).slice(2);
    const timer = setTimeout(() => {
      httpPending.delete(id);
      resolve({ status: 0, b64: '', error: 'Timed out.' });
    }, 45000);
    httpPending.set(id, (r) => {
      clearTimeout(timer);
      resolve(r);
    });
    try {
      b.httpRequest(id, method, url, JSON.stringify(headers), body || '');
    } catch (e: any) {
      clearTimeout(timer);
      httpPending.delete(id);
      resolve({ status: 0, b64: '', error: e?.message || 'Request failed.' });
    }
  });
}

export function b64ToText(b64: string): string {
  try {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder('utf-8').decode(bytes);
  } catch {
    return '';
  }
}
