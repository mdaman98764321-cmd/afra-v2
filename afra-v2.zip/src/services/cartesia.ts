import { nativeHttp, b64ToText } from './nativeBridge';

/**
 * Cartesia voices (very fast, natural, supports Bangla).
 * The person adds their own Cartesia key in Settings and picks a voice for each of the three AFRA voices.
 */

const API = 'https://api.cartesia.ai';
const KEY_STORE = 'afra_cartesia_key';
const VOICE_STORE = 'afra_cartesia_voices_v1';
const VERSIONS = ['2026-03-01', '2025-04-16'];
const MODELS = ['sonic-3.5', 'sonic-3'];

export interface CartesiaVoice {
  id: string;
  name: string;
  gender: string;
  language: string;
}

let blockedUntil = 0;

function read(key: string): string {
  try {
    return localStorage.getItem(key) || '';
  } catch {
    return '';
  }
}

function headers(key: string, version: string): Record<string, string> {
  return {
    Authorization: `Bearer ${key}`,
    'X-API-Key': key,
    'Cartesia-Version': version,
    'Content-Type': 'application/json',
  };
}

function friendly(status: number, detail: string): string {
  if (status === 401 || status === 403) return 'Cartesia Key ঠিক নয় বা অনুমতি নেই।';
  if (status === 402 || status === 429) return 'Cartesia-র ফ্রি সীমা শেষ।';
  return `Cartesia সমস্যা (${status}) ${detail}`.trim();
}

export const Cartesia = {
  getKey: (): string => read(KEY_STORE),
  setKey: (k: string): void => {
    try {
      localStorage.setItem(KEY_STORE, k.trim());
    } catch {
      /* ignore */
    }
  },
  getVoice: (profile: string): string => {
    try {
      return (JSON.parse(read(VOICE_STORE) || '{}') as Record<string, string>)[profile] || '';
    } catch {
      return '';
    }
  },
  setVoice: (profile: string, id: string): void => {
    try {
      const all = JSON.parse(read(VOICE_STORE) || '{}') as Record<string, string>;
      all[profile] = id;
      localStorage.setItem(VOICE_STORE, JSON.stringify(all));
    } catch {
      /* ignore */
    }
  },
  isReady: (profile: string): boolean => !!read(KEY_STORE) && !!Cartesia.getVoice(profile),

  async listVoices(): Promise<{ voices?: CartesiaVoice[]; error?: string }> {
    const key = read(KEY_STORE);
    if (!key) return { error: 'আগে Cartesia Key বসান।' };
    let last = '';
    for (const version of VERSIONS) {
      const r = await nativeHttp('GET', `${API}/voices?limit=100`, headers(key, version));
      if (r.error) return { error: r.error };
      const text = b64ToText(r.b64);
      if (r.status >= 200 && r.status < 300) {
        try {
          const parsed = JSON.parse(text);
          const arr: any[] = Array.isArray(parsed) ? parsed : parsed.data || parsed.voices || [];
          const voices = arr
            .filter((v) => v && v.id)
            .map((v) => ({
              id: String(v.id),
              name: String(v.name || v.id),
              gender: String(v.gender || ''),
              language: String(v.language || ''),
            }));
          return { voices };
        } catch {
          return { error: 'ভয়েসের তালিকা পড়া গেল না।' };
        }
      }
      last = friendly(r.status, text.slice(0, 120));
      if (r.status === 401 || r.status === 403) break;
    }
    return { error: last || 'ভয়েসের তালিকা আনা গেল না।' };
  },

  async speak(text: string, profile: string): Promise<{ audio?: string; error?: string }> {
    const key = read(KEY_STORE);
    const voiceId = Cartesia.getVoice(profile);
    if (!key || !voiceId) return { error: 'Cartesia ঠিক করা নেই।' };
    if (Date.now() < blockedUntil) return { error: 'Cartesia-র ফ্রি সীমা শেষ (একটু পরে আবার চেষ্টা হবে)।' };

    const language = /[\u0980-\u09FF]/.test(text) ? 'bn' : 'en';
    let lastError = '';
    const tries: Array<[string, string]> = [
      [VERSIONS[0], MODELS[0]],
      [VERSIONS[0], MODELS[1]],
      [VERSIONS[1], MODELS[1]],
    ];
    for (const [version, model] of tries) {
      const body = JSON.stringify({
        model_id: model,
        transcript: text,
        voice: { mode: 'id', id: voiceId },
        language,
        output_format: { container: 'wav', encoding: 'pcm_s16le', sample_rate: 24000 },
      });
      const r = await nativeHttp('POST', `${API}/tts/bytes`, headers(key, version), body);
      if (r.error) return { error: `Cartesia: ${r.error}` };
      if (r.status >= 200 && r.status < 300 && r.b64) return { audio: r.b64 };
      lastError = friendly(r.status, b64ToText(r.b64).slice(0, 160));
      if (r.status === 402 || r.status === 429) {
        blockedUntil = Date.now() + 5 * 60000;
        return { error: lastError };
      }
      if (r.status === 401 || r.status === 403) return { error: lastError };
      // other errors (wrong model / version name): try the next combination
    }
    return { error: lastError };
  },
};
