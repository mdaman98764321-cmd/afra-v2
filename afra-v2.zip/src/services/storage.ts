import { AvatarItem, AppSettings, ChatMessage } from '../types';
import { DEFAULT_AVATARS } from './defaultAvatars';

const AVATARS_KEY = 'afra_avatars_v1';
const ACTIVE_AVATAR_KEY = 'afra_active_avatar_v1';
const SETTINGS_KEY = 'afra_settings_v1';
const CHAT_KEY = 'afra_chat_history_v1';

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'obsidian',
  personaMode: 'balanced',
  customPersona: '',
  voiceProfile: 'afra-soft',
  speechVoiceName: '',
  speechRate: 1.0,
  speechPitch: 1.0,
  hapticFeedback: true,
  soundEffects: true,
  autoSpeakResponse: false,
  showStateControls: true,
};

export const StorageService = {
  getAvatars(): AvatarItem[] {
    try {
      const stored = localStorage.getItem(AVATARS_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as AvatarItem[];
        // Merge built-ins if missing
        const existingIds = new Set(parsed.map((a) => a.id));
        const merged = [...parsed];
        for (const builtin of DEFAULT_AVATARS) {
          if (!existingIds.has(builtin.id)) {
            merged.push(builtin);
          }
        }
        return merged;
      }
    } catch (e) {
      console.warn('Failed to load avatars from storage, falling back to defaults', e);
    }
    return DEFAULT_AVATARS;
  },

  saveAvatars(avatars: AvatarItem[]): void {
    try {
      localStorage.setItem(AVATARS_KEY, JSON.stringify(avatars));
    } catch (e) {
      console.error('Failed to save avatars', e);
    }
  },

  getActiveAvatarId(): string {
    const stored = localStorage.getItem(ACTIVE_AVATAR_KEY);
    // Upgrade the untouched legacy default to the newly added red chibi avatar.
    // Explicitly selected non-default avatars remain unchanged.
    if (!stored || stored === 'afra-core') return 'afra-red-chibi';
    return stored;
  },

  saveActiveAvatarId(id: string): void {
    localStorage.setItem(ACTIVE_AVATAR_KEY, id);
  },

  getSettings(): AppSettings {
    try {
      const stored = localStorage.getItem(SETTINGS_KEY);
      if (stored) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
      }
    } catch (e) {
      console.warn('Failed to load settings', e);
    }
    return DEFAULT_SETTINGS;
  },

  saveSettings(settings: AppSettings): void {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings', e);
    }
  },

  getChatHistory(): ChatMessage[] {
    try {
      const stored = localStorage.getItem(CHAT_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Failed to load chat history', e);
    }
    return [
      {
        id: 'msg-welcome',
        role: 'assistant',
        content: `Greetings. I am AFRA — your high-intelligence companion and kinetic avatar synthesis engine.

Explore my interactive Avatar Studio to test animation states (Idle, Listening, Thinking, Speaking), customize photorealistic or sandbox code avatars, or activate full-screen Voice Assistant mode. How may I assist your vision today?`,
        timestamp: Date.now(),
      },
    ];
  },

  saveChatHistory(messages: ChatMessage[]): void {
    try {
      // Keep recent 60 messages to preserve storage
      localStorage.setItem(CHAT_KEY, JSON.stringify(messages.slice(-60)));
    } catch (e) {
      console.error('Failed to save chat history', e);
    }
  },

  clearChatHistory(): void {
    localStorage.removeItem(CHAT_KEY);
  },
};
