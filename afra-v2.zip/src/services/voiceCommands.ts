import { Native } from './nativeBridge';

const hasBangla = (t: string) => /[\u0980-\u09FF]/.test(t);

const OPEN_WORDS = [
  'open', 'launch', 'start', 'run',
  'খোলো', 'খুলো', 'খোল', 'খুলুন', 'খুলে দাও', 'খুলে দিন', 'ওপেন', 'চালু করো', 'চালু কর', 'চালু করুন', 'চালাও', 'চালান',
];
const FILLER_WORDS = [
  'the', 'app', 'please', 'plz', 'my', 'for', 'me', 'to', 'now',
  'অ্যাপ', 'এ্যাপ', 'অ্যাপটি', 'এপ', 'এপটা', 'অ্যাপটা', 'টা', 'টি', 'দাও', 'দিন', 'করো', 'কর', 'করুন', 'প্লিজ', 'একটু', 'এখন',
  'আফরা', 'হ্যালো', 'হে', 'hey', 'hello', 'afra',
];

function stripWords(text: string, words: string[]): string {
  let out = ' ' + text.toLowerCase().replace(/[.,!?।"']/g, ' ') + ' ';
  const sorted = [...words].sort((a, b) => b.length - a.length);
  for (const w of sorted) {
    out = out.split(' ' + w + ' ').join('  ');
    out = out.split(' ' + w + ' ').join('  ');
  }
  return out.replace(/\s+/g, ' ').trim();
}

/**
 * Handles phone commands ("open Facebook", "read my messages") locally.
 * Returns the reply text, or null if this is a normal chat message for the AI.
 */
export async function tryLocalCommand(raw: string): Promise<string | null> {
  const text = raw.trim();
  if (!text || !Native.available()) return null;
  const bn = hasBangla(text);
  const lower = text.toLowerCase();
  const wordCount = lower.split(/\s+/).length;

  // ---- read messages / notifications
  const readVerb = /(পড়|শোনাও|শুনাও|দেখাও|বলো|বল |read|tell me|show|check|any new)/i.test(lower);
  const msgNoun = /(মেসেজ|মেসেজগুলো|নোটিফিকেশন|নোটিফিকেশনগুলো|message|messages|notification|notifications|sms)/i.test(lower);
  if (readVerb && msgNoun && wordCount <= 10) {
    if (!Native.hasNotificationAccess()) {
      Native.openNotificationAccessSettings();
      return bn
        ? 'নোটিফিকেশন পড়তে আপনাকে একবার অনুমতি দিতে হবে। সেটিংস খুলে দিয়েছি, সেখানে AFRA বেছে নিয়ে চালু করে দিন।'
        : 'I need notification access first. I opened the settings page — please switch AFRA on there.';
    }
    const items = Native.getNotifications().slice(0, 5);
    if (items.length === 0) return bn ? 'এখন কোনো নতুন নোটিফিকেশন নেই।' : 'You have no new notifications right now.';
    const lines = items.map((it) => {
      const who = it.title ? `${it.app}, ${it.title}` : it.app;
      return `${who}: ${it.text}`;
    });
    return (bn ? `আপনার ${items.length}টি নোটিফিকেশন আছে।\n` : `You have ${items.length} notifications.\n`) + lines.join('\n');
  }

  // ---- open an app
  const hasOpenWord = OPEN_WORDS.some((w) => (' ' + lower + ' ').includes(' ' + w + ' ') || lower.endsWith(w) || lower.startsWith(w + ' '));
  if (hasOpenWord && wordCount <= 6) {
    const name = stripWords(lower, [...OPEN_WORDS, ...FILLER_WORDS]);
    if (name.length >= 2) {
      const label = Native.openApp(name);
      if (label) return bn ? `${label} খুলছি।` : `Opening ${label}.`;
      return bn ? `"${name}" নামে কোনো অ্যাপ খুঁজে পেলাম না।` : `I couldn't find an app called "${name}".`;
    }
  }

  return null;
}
